<?php
/**
 * Sistema SEMA - Punto de Entrada Principal en PHP*/

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/auth.php';

iniciarSesionSegura();
$pdo = getPDO();
$estaLogueado = estaAutenticado();
$usuarioActual = obtenerUsuarioActual();
$esAdminActual = esAdmin();

require_once __DIR__ . '/includes/header.php';
?>

<!-- Datos de sesión inyectados por PHP para sincronización instantánea -->
<script>
  window.SEMA_SERVER = {
    logged: <?= json_encode($estaLogueado) ?>,
    user: <?= json_encode($usuarioActual) ?>,
    esAdmin: <?= json_encode($esAdminActual) ?>,
    termsVersion: <?= json_encode(SEMA_TERMS_VERSION) ?>
  };
</script>

<!-- Pantalla de Inicio de Sesión / Registro -->
<?php require_once __DIR__ . '/views/login.php'; ?>

<!-- Aplicación Principal SEMA -->
<section id="semaApp" class="sema-app" <?= $estaLogueado ? '' : 'hidden' ?>>
  <?php require_once __DIR__ . '/includes/nav.php'; ?>

  <main class="utn-body-container">
    <?php require_once __DIR__ . '/views/sema.php'; ?>
    <?php require_once __DIR__ . '/views/temas.php'; ?>
    <?php require_once __DIR__ . '/views/lista.php'; ?>
    <?php require_once __DIR__ . '/views/cron.php'; ?>
    <?php require_once __DIR__ . '/views/admin_panel.php'; ?>
  </main>

  <?php require_once __DIR__ . '/includes/footer.php'; ?>
  <?php require_once __DIR__ . '/includes/modals.php'; ?>
</section>

<script src="script.js?v=<?= file_exists(__DIR__ . '/script.js') ? filemtime(__DIR__ . '/script.js') : time() ?>" defer></script>
</body>
</html> |
