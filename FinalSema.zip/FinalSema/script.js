/**
 * SEMA - Sistema de Gestión Escolar (Cliente conectado a API PHP / WAMP / MySQL)
 */

let datosCursos = {};
let eventosGlobales = {};
let cursoActual = "";
let fechaCalendarioActual = new Date();
fechaCalendarioActual.setDate(1);
let diaSeleccionadoCronograma = "";
let unidadSeleccionadaParaEditar = "";
let alumnoSeleccionadoEmail = "";
let alumnoSeleccionadoId = 0;
let alumnosListaExpandida = false;
let notificacionesLeidas = false;
let usuarioLogueado = null;
let esUsuarioAdmin = false;
let esUsuarioAlumno = false;
let falloCargaCursos = false;

const nombresMeses = [
  "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
  "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"
];

document.addEventListener("DOMContentLoaded", iniciarSistema);

async function iniciarSistema() {
  configurarLogin();
  inicializarNotificaciones();

  // Escuchar el buscador en tiempo real
  const buscador = document.getElementById("inputBuscarFiltro");
  if (buscador) {
    buscador.addEventListener("input", (e) => filtrarAlumnosEnTabla(e.target.value));
  }

  // Verificar estado de sesión inicial inyectado o consultar API
  if (window.SEMA_SERVER && window.SEMA_SERVER.logged && window.SEMA_SERVER.user) {
    usuarioLogueado = window.SEMA_SERVER.user;
    esUsuarioAdmin = Boolean(window.SEMA_SERVER.esAdmin);
    esUsuarioAlumno = usuarioLogueado.rol === "alumno";
    await cargarDatosDesdeServidor();
    mostrarAplicacion();
  } else {
    try {
      const resp = await fetch("api/auth.php?action=check", { cache: "no-store" });
      const data = await resp.json();
      if (data.logged && data.user) {
        usuarioLogueado = data.user;
        esUsuarioAdmin = data.user.rol === "admin";
        esUsuarioAlumno = data.user.rol === "alumno";
        await cargarDatosDesdeServidor();
        mostrarAplicacion();
      } else {
        mostrarPantallaLogin();
      }
    } catch (e) {
      console.warn("No se pudo conectar a la API de sesión, mostrando login.", e);
      mostrarPantallaLogin();
    }
  }
}

// Carga inicial de cursos, unidades y calendario desde la base de datos MySQL
async function cargarDatosDesdeServidor() {
  const cursosAnteriores = datosCursos;
  const eventosAnteriores = eventosGlobales;
  const cursoAnterior = cursoActual;
  falloCargaCursos = false;
  try {
    const respCursos = await fetch("api/cursos.php?action=list", { cache: "no-store" });
    if (!respCursos.ok) {
      throw new Error("El servidor rechazó la carga de datos.");
    }

    const dataCursos = await respCursos.json();

    if (!dataCursos.success || !dataCursos.courses) {
      throw new Error("La API no devolvió los cursos del usuario.");
    }
    datosCursos = dataCursos.courses;
    esUsuarioAdmin = Boolean(dataCursos.es_admin);
    if (dataCursos.usuario) {
      usuarioLogueado = dataCursos.usuario;
      esUsuarioAlumno = usuarioLogueado.rol === "alumno";
    }

    poblarSelectorCursos();
    try {
      const queryCalendario = new URLSearchParams({ action: "list" });
      if (cursoActual) queryCalendario.set("curso_id", cursoActual);
      const respEventos = await fetch(`api/calendario.php?${queryCalendario.toString()}`, { cache: "no-store" });
      if (!respEventos.ok) throw new Error("No se pudo cargar el calendario del curso.");
      const dataEventos = await respEventos.json();
      eventosGlobales = dataEventos.success ? (dataEventos.events || {}) : {};
    } catch (errorCalendario) {
      console.warn("No se pudo cargar el calendario; se conservan los cursos y alumnos.", errorCalendario);
      eventosGlobales = {};
    }

  } catch (error) {
    console.error("Error al sincronizar con el servidor PHP:", error);
    datosCursos = cursosAnteriores;
    eventosGlobales = eventosAnteriores;
    cursoActual = cursoAnterior;
    falloCargaCursos = true;
    poblarSelectorCursos();
    if (Object.keys(datosCursos).length > 0) refrescarInterfazSegunPagina();
    mostrarModalMensaje("Error de conexión", "No se pudo sincronizar con la base de datos local.");
  }
}

function poblarSelectorCursos() {
  const selector = document.getElementById("selectorCursoGlobal");
  const etiquetaCurso = document.getElementById("cursoActualLabel");
  if (!selector && !etiquetaCurso) return;

  if (selector) selector.innerHTML = "";
  const cursoIds = Object.keys(datosCursos);

  if (cursoIds.length === 0) {
    if (selector) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.innerText = "Sin cursos asignados";
      selector.appendChild(opt);
    }
    if (etiquetaCurso) etiquetaCurso.textContent = "Sin curso asignado";
    cursoActual = "";
    return;
  }

  cursoIds.forEach((cid) => {
    const c = datosCursos[cid];
    if (selector) {
      const opt = document.createElement("option");
      opt.value = cid;
      opt.innerText = c.titulo.replace("SEMA - ", "");
      selector.appendChild(opt);
    }
  });

  // Mantener curso seleccionado o elegir el primero
  if (!cursoActual || !datosCursos[cursoActual]) {
    cursoActual = cursoIds[0];
  }
  if (selector) selector.value = cursoActual;
  if (etiquetaCurso) etiquetaCurso.textContent = datosCursos[cursoActual].titulo.replace("SEMA - ", "");
}

function configurarLogin() {
  const wrapper = document.getElementById("frmWrapper");
  const btnSignup = document.getElementById("toggleBtnSignup");
  const btnLogin = document.getElementById("toggleBtnLogin");
  const loginForm = document.getElementById("loginForm");
  const signupForm = document.getElementById("signupForm");
  let consultaPadronTimer;
  let consultaPadronVersion = 0;
  const actualizarCursoPadron = () => {
    const version = ++consultaPadronVersion;
    clearTimeout(consultaPadronTimer);
    const campoCurso = document.getElementById("signupCursoAsignado");
    if (campoCurso) campoCurso.value = "";
    consultaPadronTimer = setTimeout(async () => {
      const dni = document.getElementById("signupDni")?.value.trim() || "";
      const nombre = document.getElementById("signupNombreCompleto")?.value.trim() || "";
      if (!/^\d[\d.\s-]{5,14}$/.test(dni) || nombre.length < 4 || !campoCurso) return;
      try {
        const resp = await fetch("api/auth.php", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "preview_student_course", dni, nombre_completo: nombre })
        });
        const res = await resp.json();
    if (version === consultaPadronVersion && res.success && res.matched) campoCurso.value = res.curso || "Curso asignado";
      } catch (error) {
        // La validación definitiva ocurre al enviar el formulario.
      }
    }, 350);
  };
  ["signupDni", "signupNombreCompleto"].forEach((id) => {
    document.getElementById(id)?.addEventListener("input", actualizarCursoPadron);
  });

  [btnSignup, document.getElementById("mobileToggleBtnSignup")].filter(Boolean).forEach((button) => {
    button.addEventListener("click", (e) => {
      e.preventDefault();
      wrapper.classList.add("active");
      const input = document.getElementById("signupUsername");
      if (input) input.focus();
    });
  });

  [btnLogin, document.getElementById("mobileToggleBtnLogin")].filter(Boolean).forEach((button) => {
    button.addEventListener("click", (e) => {
      e.preventDefault();
      wrapper.classList.remove("active");
      const input = document.getElementById("loginIdentity");
      if (input) input.focus();
    });
  });

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const identity = document.getElementById("loginIdentity").value.trim();
      const password = document.getElementById("loginPassword").value;
      const Fecha_de_Nacimiento = document.getElementById("loginFecha_de_Nacimiento").value;

      try {
        const resp = await fetch("api/auth.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "login", identity, password, Fecha_de_Nacimiento })
        });
        const res = await resp.json();

        if (res.success) {
          usuarioLogueado = res.user;
          esUsuarioAdmin = res.user.rol === "admin";
          esUsuarioAlumno = res.user.rol === "alumno";
          await cargarDatosDesdeServidor();
          mostrarAplicacion();
        } else {
          mostrarModalMensaje("Acceso denegado", res.message || "Usuario o contraseña inválidos.");
          document.getElementById("loginPassword").value = "";
        }
      } catch (err) {
        mostrarModalMensaje("Error de red", "No se pudo comunicar con el servidor de autenticación.");
      }
    });
  }

  if (signupForm) {
    signupForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const username = document.getElementById("signupUsername").value.trim();
      const email = document.getElementById("signupEmail").value.trim();
      const Fecha_de_Nacimiento = document.getElementById("signupFecha_de_Nacimiento").value.trim();
      const nombreCompleto = document.getElementById("signupNombreCompleto").value.trim();
      const dni = document.getElementById("signupDni").value.trim();
      const password = document.getElementById("signupPassword").value;
      const termsAccepted = document.getElementById("signupTermsAccepted").checked;

      try {
        const resp = await fetch("api/auth.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "signup", username, email,Fecha_de_Nacimiento, nombre_completo: nombreCompleto, dni, password, terms_accepted: termsAccepted, terms_version: window.SEMA_SERVER?.termsVersion || "" })
        });
        const res = await resp.json();

        if (res.success) {
          usuarioLogueado = res.user;
          esUsuarioAdmin = res.user.rol === "admin";
          esUsuarioAlumno = res.user.rol === "alumno";
          signupForm.reset();
          await cargarDatosDesdeServidor();
          mostrarAplicacion();
          mostrarModalMensaje("Registro completo", res.message || "La cuenta quedó asociada a tu curso.");
        } else {
          mostrarModalMensaje("Error de registro", res.message || "No se pudo registrar la cuenta.");
        }
      } catch (err) {
        mostrarModalMensaje("Error", "Ocurrió un fallo al intentar registrar la cuenta.");
      }
    });
  }
}

function mostrarPantallaLogin() {
  const loginScr = document.getElementById("loginScreen");
  const appScr = document.getElementById("semaApp");
  if (loginScr) loginScr.hidden = false;
  if (appScr) appScr.hidden = true;
}

function mostrarAplicacion() {
  const loginScr = document.getElementById("loginScreen");
  const appScr = document.getElementById("semaApp");
  const avisoLogin = document.getElementById("loginStatusMessage");
  if (loginScr) loginScr.hidden = true;
  if (appScr) appScr.hidden = false;
  if (avisoLogin) {
    avisoLogin.hidden = true;
    avisoLogin.textContent = "";
  }

  // Actualizar chip de usuario en la barra
  if (usuarioLogueado) {
    asignarTexto("labelNombreUsuario", usuarioLogueado.nombre_completo || usuarioLogueado.username);
    const rolBadge = document.getElementById("labelRolUsuario");
    if (rolBadge) {
      rolBadge.innerText = esUsuarioAdmin ? "ADMINISTRADOR GENERAL" : (esUsuarioAlumno ? "ALUMNO" : "DOCENTE");
      rolBadge.className = "user-chip-role " + (esUsuarioAdmin ? "role-badge-admin" : "role-badge-docente");
    }
  }

  // Visibilidad de herramientas admin
  const navAdmin = document.getElementById("navItemAdmin");
  if (navAdmin) navAdmin.style.display = esUsuarioAdmin ? "inline-block" : "none";
  const selectorCurso = document.getElementById("selectorCursoGlobal");
  const etiquetaCurso = document.getElementById("cursoActualLabel");
  if (selectorCurso) selectorCurso.hidden = !esUsuarioAdmin;
  if (etiquetaCurso) etiquetaCurso.hidden = esUsuarioAdmin;

  const navLista = document.getElementById("navItemLista");
  const tieneCursoAlumno = esUsuarioAlumno && Object.keys(datosCursos).length > 0;
  document.body.classList.toggle("sema-rol-alumno", esUsuarioAlumno);
  if (navLista) {
    navLista.style.display = esUsuarioAlumno && !tieneCursoAlumno ? "none" : "";
    if (esUsuarioAlumno) navLista.innerText = "MIS CALIFICACIONES";
    else navLista.innerText = "REGISTRO ALUMNOS";
  }
  const panelLista = document.getElementById("lista");
  if (panelLista && esUsuarioAlumno) panelLista.classList.remove("active");
  const observacionesDocente = document.getElementById("detalleObservacionesDocenteWrapper");
  if (observacionesDocente) observacionesDocente.hidden = esUsuarioAlumno;
  const observacionesAlumno = document.getElementById("observacionesAulaAlumno");
  if (observacionesAlumno) observacionesAlumno.hidden = !esUsuarioAlumno;
  const btnNuevaUnidad = document.getElementById("btnNuevaUnidadCurricular");
  if (btnNuevaUnidad) btnNuevaUnidad.hidden = esUsuarioAlumno;

  const btnBackup = document.getElementById("btnBackupRapido");
  if (btnBackup) btnBackup.style.display = esUsuarioAdmin ? "inline-block" : "none";

  document.querySelectorAll("#lista input, #lista select, #lista textarea").forEach((control) => { control.disabled = false; });
  document.querySelectorAll("#lista button").forEach((button) => { button.hidden = false; });
  document.querySelectorAll(".utn-nav-tools button").forEach((button) => { button.hidden = false; });
  const importLabel = document.getElementById("btnImportarAlumnosLabel");
  if (importLabel) importLabel.hidden = false;

  if (esUsuarioAlumno) {
    if (importLabel) importLabel.hidden = true;
    document.querySelectorAll("#lista input, #lista select, #lista textarea").forEach((control) => { control.disabled = true; });
    document.querySelectorAll("#lista button").forEach((button) => { button.hidden = true; });
    document.querySelectorAll("#temas .btn-add-tema-capsula, #temas .btn-editar").forEach((button) => { button.hidden = true; });
    document.querySelectorAll(".utn-nav-tools button").forEach((button) => {
      if (!button.classList.contains("logout-btn")) button.hidden = true;
    });
  }

  refrescarInterfazSegunPagina();
  restaurarPestanaActiva();
  actualizarBadgeNotificaciones();
}

async function cerrarSesion() {
  try {
    await fetch("api/auth.php?action=logout", { method: "POST" });
  } catch (e) {}

  usuarioLogueado = null;
  esUsuarioAdmin = false;
  esUsuarioAlumno = false;
  datosCursos = {};
  eventosGlobales = {};
  cursoActual = "";
  falloCargaCursos = false;
  mostrarPantallaLogin();
  const lf = document.getElementById("loginForm");
  const sf = document.getElementById("signupForm");
  const wr = document.getElementById("frmWrapper");
  if (lf) lf.reset();
  if (sf) sf.reset();
  if (wr) wr.classList.remove("active");
}

function cambiarPestana(idPestana, elementoClick) {
  document.querySelectorAll(".utn-tab-panel").forEach((p) => p.classList.remove("active"));
  document.querySelectorAll(".utn-link-item").forEach((link) => link.classList.remove("active"));

  const panel = document.getElementById(idPestana);
  if (panel) panel.classList.add("active");
  if (elementoClick) elementoClick.classList.add("active");
  try {
    if (usuarioLogueado?.id) sessionStorage.setItem(`sema-tab-${usuarioLogueado.id}`, idPestana);
  } catch (error) {}

  // Si entra al panel de administración, cargar sus datos correspondientes
  if (idPestana === "adminPanel" && esUsuarioAdmin) {
    cargarRegistroGlobalAlumnosAdmin();
    cargarLogsAdmin();
    cargarAdminUsuarios();
  }
  if (idPestana === "cron") {
    refrescarCronogramaDinamico();
  }
}

function restaurarPestanaActiva() {
  if (!usuarioLogueado?.id) return;

  try {
    const pestaña = sessionStorage.getItem(`sema-tab-${usuarioLogueado.id}`);
    if (!pestaña || !["sema", "temas", "lista", "cron", "adminPanel"].includes(pestaña)) return;
    if (pestaña === "adminPanel" && !esUsuarioAdmin) return;
    if (pestaña === "lista" && esUsuarioAlumno && Object.keys(datosCursos).length === 0) return;

    const enlace = Array.from(document.querySelectorAll(".utn-link-item"))
      .find((item) => item.getAttribute("onclick")?.includes(`'${pestaña}'`));
    if (enlace) cambiarPestana(pestaña, enlace);
  } catch (error) {}
}

async function cambiarDeCurso(idCurso) {
  if (!esUsuarioAdmin || !datosCursos[idCurso]) return;
  cursoActual = idCurso;
  alumnosListaExpandida = false;
  const query = new URLSearchParams({ action: "list", curso_id: cursoActual });
  try {
    const resp = await fetch(`api/calendario.php?${query.toString()}`, { cache: "no-store" });
    const data = await resp.json();
    if (data.success) eventosGlobales = data.events || {};
  } catch (error) {
    eventosGlobales = {};
  }
  refrescarInterfazSegunPagina();
}

function refrescarInterfazSegunPagina() {
  refrescarCronogramaDinamico();
  const info = datosCursos[cursoActual];
  if (!info) {
    mostrarEstadoSinCursoAutorizado();
    return;
  }

  const selectorGlobal = document.getElementById("selectorCursoGlobal");
  if (selectorGlobal) selectorGlobal.value = cursoActual;
  const etiquetaCurso = document.getElementById("cursoActualLabel");
  if (etiquetaCurso && info.titulo) etiquetaCurso.textContent = info.titulo.replace("SEMA - ", "");

  asignarTexto("sema-titulo-curso", info.titulo);
  asignarTexto("sema-subtitulo-materias", info.materias);
  asignarTexto("sema-fecha-examen", info.proximoExamen || "--/--");
  asignarTexto("sema-tema-examen", info.temaExamen || "Sin tema fijado");
  asignarTexto("sema-comunicado-texto", info.comunicadoProfesora || "Espacio docente para el seguimiento del aula.");
  asignarTexto("subtituloCursoLista", `${info.titulo} (${info.materias})`);

  refrescarDashboard(info);
  refrescarUnidades();
  refrescarAlumnos(info);
  refrescarContenedorSolicitudes();
}

function mostrarEstadoSinCursoAutorizado() {
  document.querySelectorAll(".utn-tab-panel").forEach((panel) => panel.classList.remove("active"));
  document.getElementById("sema")?.classList.add("active");
  document.querySelectorAll(".utn-link-item").forEach((link) => link.classList.remove("active"));
  document.querySelector(".utn-link-item")?.classList.add("active");
  asignarTexto("sema-titulo-curso", falloCargaCursos ? "No se pudieron sincronizar los cursos" : "Tu cuenta todavía no está asociada a un curso");
  asignarTexto("sema-subtitulo-materias", falloCargaCursos ? "No se pudo consultar el servidor. Los registros no fueron borrados." : "Cuando la institución te asigne un curso, vas a encontrar acá tus contenidos.");
  asignarTexto("sema-comunicado-texto", falloCargaCursos ? "Revisá la conexión e intentá recargar la página." : "No hay información de cursos disponible para esta cuenta.");
  asignarTexto("sema-fecha-examen", "--/--");
  asignarTexto("sema-tema-examen", "Sin curso asignado");
  asignarTexto("dashboard-curso-corto", "Sin curso");
  asignarTexto("dashboardProgressLabel", esUsuarioAlumno ? "MI AVANCE" : "CONTENIDOS DADOS");
  asignarTexto("dashboardRosterLabel", esUsuarioAlumno ? "Mi calificación" : "Estudiantes");
  asignarTexto("dashboard-progreso-total", "—");
  asignarTexto("dashboard-progreso-ring", "—");
  asignarTexto("dashboard-progreso-text", "Tu progreso aparecerá cuando tengas un curso asignado.");
  asignarTexto("dashboard-siguiente-titulo", falloCargaCursos ? "Esperando sincronización" : "Sin curso asignado");
  asignarTexto("dashboard-siguiente-desc", falloCargaCursos ? "La lista continúa en el servidor; no se pudo consultar en este momento." : "Pedile a un docente o administrador que vincule tu cuenta con tu curso.");
  asignarTexto("dashboard-unidades", "0");
  asignarTexto("dashboard-alumnos", "0");
  asignarTexto("dashboard-evaluacion", "--");

  const barra = document.getElementById("dashboard-progreso-bar");
  if (barra) barra.style.width = "0%";
  const anillo = document.getElementById("dashboard-ring");
  if (anillo) anillo.style.setProperty("--progress", "0deg");
  const unidades = document.getElementById("contenedor-unidades");
  if (unidades) unidades.innerHTML = `<p class="section-supporting-text">${falloCargaCursos ? "No se pudieron cargar los contenidos del servidor." : "No hay contenidos disponibles hasta que se asigne un curso."}</p>`;
  const alumnos = document.getElementById("tabla-alumnos-body");
  if (alumnos) alumnos.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:20px;">${falloCargaCursos ? "No se pudo consultar la lista. Los registros no fueron borrados." : "No hay un curso asignado a esta cuenta."}</td></tr>`;
  const solicitudes = document.getElementById("solicitudes-contenedor");
  if (solicitudes) solicitudes.textContent = "No hay solicitudes disponibles.";
}

function obtenerProgresoCurso(info) {
  const capsulas = (info.unidades || []).flatMap((unidad) => typeof unidad === "object" ? (unidad.tareas || []) : []);
  if (capsulas.length === 0) return 0;
  const completadas = capsulas.filter((capsula) => esUsuarioAlumno ? Number(capsula.completada) === 1 : Number(capsula.dictada) === 1).length;
  return Math.round(completadas * 100 / capsulas.length);
}

function refrescarDashboard(info) {
  actualizarAccesosDrive(info);
  const progreso = obtenerProgresoCurso(info);
  const unidades = info.unidades || [];
  const primeraUnidad = unidades[0];
  const nombrePrimeraUnidad = typeof primeraUnidad === "object" ? primeraUnidad.nombre : primeraUnidad;
  const porcentajeTexto = `${progreso}%`;

  asignarTexto("dashboard-curso-corto", info.titulo.replace("SEMA - ", ""));
  asignarTexto("dashboardProgressLabel", esUsuarioAlumno ? "MI AVANCE" : "CONTENIDOS DADOS");
  asignarTexto("dashboardRosterLabel", esUsuarioAlumno ? "Mi calificación" : "Estudiantes");
  asignarTexto("dashboard-progreso-total", porcentajeTexto);
  asignarTexto("dashboard-progreso-ring", porcentajeTexto);
  asignarTexto("dashboard-progreso-text", esUsuarioAlumno ? `Completaste el ${progreso}% de los contenidos del curso.` : (progreso > 0 ? `Se dio el ${progreso}% de los contenidos cargados.` : "Marcá las cápsulas a medida que las des en clase."));
  asignarTexto("dashboard-siguiente-titulo", nombrePrimeraUnidad || "Unidad pendiente");
  asignarTexto("dashboard-siguiente-desc", "Revisá la teoría y completá la práctica de esta unidad.");
  asignarTexto("dashboard-unidades", unidades.length);
  const alumnoPropio = esUsuarioAlumno ? (info.alumnos || [])[0] : null;
  asignarTexto("dashboard-alumnos", esUsuarioAlumno ? (alumnoPropio ? `${alumnoPropio.nota}/10` : "Pendiente") : (info.alumnos ? info.alumnos.length : 0));
  asignarTexto("dashboard-evaluacion", info.proximoExamen || "--");

  const barra = document.getElementById("dashboard-progreso-bar");
  if (barra) barra.style.width = porcentajeTexto;
  const anillo = document.getElementById("dashboard-ring");
  if (anillo) anillo.style.setProperty("--progress", `${progreso * 3.6}deg`);
}

function actualizarAccesosDrive(info) {
  const driveUrl = String(info?.drive_url || "").trim();
  let urlDriveValida = false;
  try {
    const url = new URL(driveUrl);
    urlDriveValida = url.protocol === "https:" && ["drive.google.com", "docs.google.com"].includes(url.hostname);
  } catch (error) {}

  const banner = document.getElementById("courseDriveBanner");
  const linkCurso = document.getElementById("courseDriveLink");
  const descripcion = document.getElementById("courseDriveDescription");
  if (banner) banner.hidden = !urlDriveValida;
  if (linkCurso && urlDriveValida) {
    linkCurso.href = driveUrl;
    linkCurso.textContent = esUsuarioAlumno ? "Abrir carpeta para ver y subir tareas" : "Abrir carpeta de Drive del curso";
  }
  if (descripcion) {
    descripcion.textContent = esUsuarioAlumno
      ? "Consultá las tareas y cargá tus resoluciones en la carpeta compartida."
      : "La profesora publica tareas y recibe resoluciones en esta carpeta compartida.";
  }
}

function asignarTexto(id, texto) {
  const elem = document.getElementById(id);
  if (elem) elem.innerText = texto;
}

function escaparHTML(valor) {
  return String(valor ?? "").replace(/[&<>"']/g, (caracter) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
  })[caracter]);
}

function refrescarContenedorSolicitudes() {
  const info = datosCursos[cursoActual];
  const contenedor = document.getElementById("solicitudes-contenedor");
  const badge = document.getElementById("badge-solicitudes");

  if (!contenedor) return;

  if (info && info.solicitudAcceso) {
    if (badge) {
      badge.innerText = "1";
      badge.style.display = "inline-block";
    }

    contenedor.innerHTML = `
      <div class="solicitud-escolar-box">
        <div>
          <strong style="color:#000;">${escaparHTML(info.solicitudAcceso)}</strong><br>
          <span style="background-color: rgba(234, 179, 8, 0.1); color: #ca8a04; font-size: 0.8rem; padding: 2px 6px; border-radius: 4px; font-weight: bold;">Esperando Validación</span>
        </div>
        <button onclick="aceptarMatriculaEstudiante()" class="btn-mini-action" style="background: #22c55e; color:#fff;">Aceptar</button>
      </div>
    `;
  } else {
    if (badge) badge.style.display = "none";
    contenedor.innerHTML = `<p style="color:#64748b; font-style:italic; text-align:center; padding:10px;">No hay solicitudes de inscripción pendientes.</p>`;
  }
}

async function aceptarMatriculaEstudiante() {
  try {
    const resp = await fetch("api/cursos.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "accept_access", curso_id: cursoActual })
    });
    const res = await resp.json();
    if (res.success) {
      mostrarModalMensaje("Matrícula aceptada", res.message || "El alumno fue incorporado al curso.");
      await cargarDatosDesdeServidor();
      refrescarInterfazSegunPagina();
      cerrarModal("modalControlAcceso");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo aceptar la solicitud.");
    }
  } catch (err) {
    mostrarModalMensaje("Error", "Error de comunicación con el servidor.");
  }
}

// ==========================================
// CALENDARIO ACADÉMICO Y ALERTAS
// ==========================================

function refrescarCronogramaDinamico() {
  const calDias = document.getElementById("calendario-dias");
  const listaLateral = document.getElementById("lista-eventos-lateral");
  if (!calDias || !listaLateral) return;

  const anio = fechaCalendarioActual.getFullYear();
  const mes = fechaCalendarioActual.getMonth();

  asignarTexto("dinamico-anio-cronograma", anio);
  asignarTexto("dinamico-mes-cronograma", nombresMeses[mes]);

  calDias.innerHTML = "";
  const diasSemana = ["D", "L", "Ma", "Mi", "J", "V", "S"];
  diasSemana.forEach((d) => {
    calDias.innerHTML += `<div class="day-name">${d}</div>`;
  });

  listaLateral.innerHTML = "<h3>Próximos Eventos:</h3>";

  const primerDiaIndex = new Date(anio, mes, 1).getDay();
  const totalDiasMes = new Date(anio, mes + 1, 0).getDate();

  for (let j = 0; j < primerDiaIndex; j++) {
    calDias.innerHTML += `<div class="day" style="color:#cbd5e1; cursor:default;"></div>`;
  }

  for (let i = 1; i <= totalDiasMes; i++) {
    let claseDia = "day";
    const mesFormateado = String(mes + 1).padStart(2, "0");
    const diaFormateado = String(i).padStart(2, "0");
    const fechaClave = `${anio}-${mesFormateado}-${diaFormateado}`;

    if (eventosGlobales[fechaClave]) {
      const ev = eventosGlobales[fechaClave];
      const claseEvento = String(ev.clase || "").split(/\s+/).filter((clase) => /^[a-zA-Z0-9_-]+$/.test(clase)).join(" ");
      const tipoEvento = String(ev.tipo || "ev-repaso").replace(/[^a-zA-Z0-9_-]/g, "");
      claseDia += claseEvento ? ` ${claseEvento}` : "";
      listaLateral.innerHTML += `
        <div class="event-item ${escaparHTML(tipoEvento || "ev-repaso")}">
          <h4>${escaparHTML(ev.titulo)}</h4>
          <p>${escaparHTML(ev.desc)}</p>
        </div>
      `;
    }

    calDias.innerHTML += `<div class="${claseDia}" onclick="abrirManejadorEventosFecha('${fechaClave}', ${i})">${i}</div>`;
  }
}

function mesAnterior() {
  fechaCalendarioActual.setMonth(fechaCalendarioActual.getMonth() - 1);
  refrescarCronogramaDinamico();
}

function mesSiguiente() {
  fechaCalendarioActual.setMonth(fechaCalendarioActual.getMonth() + 1);
  refrescarCronogramaDinamico();
}

function abrirManejadorEventosFecha(fechaClave, nDia) {
  if (esUsuarioAlumno) return;
  diaSeleccionadoCronograma = fechaClave;
  asignarTexto("txtDiaSeleccionado", nDia);
  const ev = eventosGlobales[fechaClave];

  if (ev) {
    document.getElementById("inputTituloEvento").value = ev.titulo;
    document.getElementById("inputDescEvento").value = ev.desc;
    document.getElementById("selectTipoEvento").value = ev.tipo ? ev.tipo.replace("ev-", "") : "repaso";
    document.getElementById("btnBorrarEvento").style.display = ev.curso_id === cursoActual ? "inline-block" : "none";
  } else {
    document.getElementById("inputTituloEvento").value = "";
    document.getElementById("inputDescEvento").value = "";
    document.getElementById("selectTipoEvento").value = "repaso";
    document.getElementById("btnBorrarEvento").style.display = "none";
  }

  abrirModal("modalGestionarFecha");
}

async function guardarEventoCronograma() {
  const titulo = document.getElementById("inputTituloEvento").value.trim();
  const desc = document.getElementById("inputDescEvento").value.trim();
  const tipoSeleccionado = document.getElementById("selectTipoEvento").value;

  if (!titulo) {
    mostrarModalMensaje("Validación requerida", "Introduce un título para la alerta evaluativa.");
    return;
  }

  let claseMapeada = "event-12";
  if (tipoSeleccionado === "recup") claseMapeada = "event-19";
  if (tipoSeleccionado === "cierre") claseMapeada = "event-27";

  try {
    const resp = await fetch("api/calendario.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "save",
        curso_id: cursoActual,
        fecha: diaSeleccionadoCronograma,
        titulo,
        desc,
        tipo: `ev-${tipoSeleccionado}`,
        clase: claseMapeada
      })
    });
    const res = await resp.json();

    if (res.success) {
      eventosGlobales[diaSeleccionadoCronograma] = {
        curso_id: cursoActual,
        clase: claseMapeada,
        titulo,
        desc,
        tipo: `ev-${tipoSeleccionado}`
      };
      refrescarCronogramaDinamico();
      cerrarModal("modalGestionarFecha");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo guardar el evento.");
    }
  } catch (err) {
    mostrarModalMensaje("Error", "Fallo al guardar evento en el servidor.");
  }
}

function eliminarEventoCronograma() {
  mostrarModalConfirmacion(
    "Eliminar alerta",
    "¿Confirmas la eliminación permanente de esta alerta en el calendario?",
    async () => {
      try {
        const resp = await fetch("api/calendario.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "delete", curso_id: cursoActual, fecha: diaSeleccionadoCronograma })
        });
        const res = await resp.json();
        if (res.success) {
          delete eventosGlobales[diaSeleccionadoCronograma];
          refrescarCronogramaDinamico();
          cerrarModal("modalGestionarFecha");
        } else {
          mostrarModalMensaje("No se pudo eliminar", res.message || "No hay una alerta propia para eliminar.");
        }
      } catch (e) {
        mostrarModalMensaje("Error", "No se pudo eliminar el evento.");
      }
    }
  );
}

// ==========================================
// UNIDADES Y CÁPSULAS DIDÁCTICAS
// ==========================================

function refrescarUnidades() {
  const contenedor = document.getElementById("contenedor-unidades");
  if (!contenedor) return;

  contenedor.innerHTML = "";
  const curso = datosCursos[cursoActual];
  if (!curso || !curso.unidades) {
    return;
  }

  curso.unidades.forEach((un, index) => {
    const esObjeto = typeof un === "object" && un !== null;
    const nombreUnidad = esObjeto ? un.nombre : un;
    const listaTareas = esObjeto ? (un.tareas || []) : [];

    const card = document.createElement("div");
    card.className = "unidad-card";

    const capsulas = listaTareas;

    let tareasHtml = "";
    capsulas.forEach((tarea, idx) => {
      const tareaObj = typeof tarea === "string" ? { texto: tarea } : tarea;
      const tipoSolicitado = String(tareaObj.tipo || "").toUpperCase();
      const tipo = ["T", "V", "E"].includes(tipoSolicitado) ? tipoSolicitado : ["T", "V", "E"][idx % 3];
      const tituloTarea = tareaObj.texto || tareaObj.archivo || tareaObj.url || `Cápsula ${idx + 1}`;
      const tareaJson = encodeURIComponent(JSON.stringify(tareaObj)).replace(/'/g, "%27");
      const tieneId = Number(tareaObj.id) > 0;
      const recursoControl = `<button class="capsula-t capsule-${tipo.toLowerCase()}" onclick="verTareaAdjunta('${tareaJson}')" title="Abrir ${escaparHTML(tituloTarea)}"><strong>${escaparHTML(tipo)}</strong><span>${escaparHTML(tituloTarea)}</span></button>`;
      const habilitadoEntrega = Number(tareaObj.dictada) === 1;
      const estadoAlumno = `<label class="capsule-completion"><input type="checkbox" ${Number(tareaObj.completada) === 1 ? "checked" : ""} ${habilitadoEntrega ? "" : "disabled"} onchange="actualizarEstadoCapsula(${Number(tareaObj.id)}, 'completada', this.checked)"> Completada</label>`;
      const estadoDocente = `<label class="capsule-completion"><input type="checkbox" ${Number(tareaObj.dictada) === 1 ? "checked" : ""} onchange="actualizarEstadoCapsula(${Number(tareaObj.id)}, 'dictada', this.checked)"> Dada en clase</label>`;
      const estadoControl = !tieneId ? "" : (esUsuarioAlumno ? estadoAlumno : estadoDocente);
      tareasHtml += `<div class="capsule-item">${recursoControl}${estadoControl}</div>`;
    });

    const cantidadMarcada = listaTareas.filter((tarea) => esUsuarioAlumno ? Number(tarea.completada) === 1 : Number(tarea.dictada) === 1).length;
    const avanceUnidad = listaTareas.length ? Math.round(cantidadMarcada * 100 / listaTareas.length) : 0;
    const estadoUnidad = avanceUnidad === 100 && listaTareas.length ? (esUsuarioAlumno ? "COMPLETADA" : "CONTENIDOS DADOS") : "EN PROGRESO";

    card.innerHTML = `
      <div class="unit-card-header"><span class="unit-number">${String(index + 1).padStart(2, "0")}</span><span class="unit-status">${estadoUnidad}</span></div>
      <h3>${escaparHTML(nombreUnidad)}</h3>
      <div class="unit-progress-track"><span style="width: ${avanceUnidad}%"></span></div>
      <div class="unit-progress-label"><span>${listaTareas.length ? `${cantidadMarcada} de ${listaTareas.length} ${esUsuarioAlumno ? "completadas" : "dadas"}` : "Sin cápsulas todavía"}</span><span>${avanceUnidad}%</span></div>
      <div class="tareas-capsulas">
        ${tareasHtml || `<span class="section-supporting-text">${esUsuarioAlumno ? "Todavía no hay contenidos en esta unidad." : "Agregá cápsulas para registrar el avance de esta unidad."}</span>`}
        ${esUsuarioAlumno ? "" : `<button class="btn-add-tema-capsula" onclick="abrirModalAgregarTema(decodeURIComponent('${encodeURIComponent(nombreUnidad).replace(/'/g, "%27")}'))" title="Añadir cápsula">+</button>`}
      </div>
      <div class="unit-card-footer">
        <span>${capsulas.length} cápsulas de aprendizaje</span>
        ${esUsuarioAlumno ? "" : `<button class="btn-editar" onclick="abrirModalEditarUnidad(decodeURIComponent('${encodeURIComponent(nombreUnidad).replace(/'/g, "%27")}'))">Editar unidad</button>`}
      </div>
    `;
    contenedor.appendChild(card);
  });
}

async function actualizarEstadoCapsula(capsulaId, campo, valor) {
  const action = campo === "dictada" ? "toggle_delivered" : "toggle_complete";
  try {
    const resp = await fetch("api/unidades.php", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, capsula_id: capsulaId, [campo]: valor })
    });
    const res = await resp.json();
    if (!res.success) {
      mostrarModalMensaje("No se pudo actualizar", res.message || "El servidor rechazó el cambio.");
    }
    await cargarDatosDesdeServidor();
    refrescarInterfazSegunPagina();
  } catch (error) {
    mostrarModalMensaje("Error de conexión", "No se pudo guardar el estado del contenido.");
  }
}

function abrirModalAgregarTema(nombreUnidad) {
  unidadSeleccionadaParaEditar = nombreUnidad;
  asignarTexto("dinamicoTituloUnidad", `Adjuntar Contenido a ${nombreUnidad}`);
  const input = document.getElementById("inputContenidoTema");
  if (input) input.value = "";
  const tipo = document.getElementById("selectTipoTema");
  if (tipo) tipo.value = "T";
  const fileInput = document.getElementById("inputFileTema");
  if (fileInput) fileInput.value = "";
  abrirModal("modalAgregarTema");
}

async function confirmarAgregarTema() {
  const inputNombre = document.getElementById("inputNombreTemaImg");
  const inputDescripcion = document.getElementById("inputDescTemaImg");
  const inputContenido = document.getElementById("inputContenidoTema");
  const fileInput = document.getElementById("inputFileTema");
  const tipoInput = document.getElementById("selectTipoTema");

  const nombre = inputNombre ? inputNombre.value.trim() : "";
  const descripcion = inputDescripcion ? inputDescripcion.value.trim() : "";
  const txtContenido = inputContenido ? inputContenido.value.trim() : "";
  const tieneArchivo = fileInput && fileInput.files && fileInput.files.length > 0;

  if (!nombre && !txtContenido && !tieneArchivo) {
    mostrarModalMensaje("Contenido requerido", "Agrega un nombre, enlace o selecciona un archivo local.");
    return;
  }

  const formData = new FormData();
  formData.append("action", "add_capsule");
  formData.append("curso_id", cursoActual);
  formData.append("nombre_unidad", unidadSeleccionadaParaEditar);
  formData.append("tipo", tipoInput ? tipoInput.value : "T");
  formData.append("nombre", nombre);
  formData.append("descripcion", descripcion);
  formData.append("contenido", txtContenido);
  if (tieneArchivo) {
    formData.append("archivo", fileInput.files[0]);
  }

  try {
    const resp = await fetch("api/unidades.php", {
      method: "POST",
      body: formData
    });
    const res = await resp.json();

    if (res.success) {
      await cargarDatosDesdeServidor();
      refrescarUnidades();
      cerrarModal("modalAgregarTema");
      if (inputNombre) inputNombre.value = "";
      if (inputDescripcion) inputDescripcion.value = "";
      if (inputContenido) inputContenido.value = "";
      if (fileInput) fileInput.value = "";
      mostrarModalMensaje("Tarea guardada", res.message || "El contenido fue agregado correctamente.");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo agregar la cápsula.");
    }
  } catch (err) {
    mostrarModalMensaje("Error", "Error de red al subir cápsula.");
  }
}

async function guardarNuevaUnidad() {
  const input = document.getElementById("inputNuevoNombreUnidad");
  const txt = input.value.trim();
  if (!txt) {
    mostrarModalMensaje("Nombre requerido", "Escriba el nombre de la unidad.");
    return;
  }

  const formData = new FormData();
  formData.append("action", "create_unit");
  formData.append("curso_id", cursoActual);
  formData.append("nombre", txt);
  formData.append("teoria_nombre", document.getElementById("inputNombreTeoria")?.value.trim() || "");
  formData.append("teoria_url", document.getElementById("inputUrlTeoria")?.value.trim() || "");
  formData.append("video_nombre", document.getElementById("inputNombreVideo")?.value.trim() || "");
  formData.append("video_url", document.getElementById("inputUrlVideo")?.value.trim() || "");
  formData.append("ejercicio_nombre", document.getElementById("inputNombreEjercicio")?.value.trim() || "");
  formData.append("ejercicio_url", document.getElementById("inputUrlEjercicio")?.value.trim() || "");

  try {
    const resp = await fetch("api/unidades.php", {
      method: "POST",
      body: formData
    });
    const res = await resp.json();

    if (res.success) {
      await cargarDatosDesdeServidor();
      refrescarUnidades();
      cerrarModal("modalNuevaUnidad");
      input.value = "";
      mostrarModalMensaje("Unidad dada de alta", res.message || "La unidad se creó exitosamente.");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo crear la unidad.");
    }
  } catch (e) {
    mostrarModalMensaje("Error", "Fallo al comunicar con el servidor.");
  }
}

function abrirModalEditarUnidad(nombreUnidad) {
  unidadSeleccionadaParaEditar = nombreUnidad;
  document.getElementById("inputEditarNombreUnidad").value = nombreUnidad;
  abrirModal("modalEditarUnidad");
}

async function guardarCambiosUnidad() {
  const nuevoNombre = document.getElementById("inputEditarNombreUnidad").value.trim();
  if (!nuevoNombre) {
    mostrarModalMensaje("Validación requerida", "El nombre de la unidad no puede quedar vacío.");
    return;
  }

  const curso = datosCursos[cursoActual];
  const unidadObj = curso.unidades.find((u) => u.nombre === unidadSeleccionadaParaEditar);
  if (!unidadObj || !unidadObj.id) {
    cerrarModal("modalEditarUnidad");
    return;
  }

  const formData = new FormData();
  formData.append("action", "update_unit");
  formData.append("unidad_id", unidadObj.id);
  formData.append("nombre", nuevoNombre);

  try {
    const resp = await fetch("api/unidades.php", {
      method: "POST",
      body: formData
    });
    const res = await resp.json();

    if (res.success) {
      await cargarDatosDesdeServidor();
      refrescarUnidades();
      cerrarModal("modalEditarUnidad");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo actualizar.");
    }
  } catch (err) {
    mostrarModalMensaje("Error", "Error de red.");
  }
}

function eliminarUnidadActual() {
  mostrarModalConfirmacion(
    "Eliminar unidad",
    "¿Eliminar esta unidad de la planificación? Esta acción no se puede deshacer.",
    async () => {
      const curso = datosCursos[cursoActual];
      const unidadObj = curso.unidades.find((u) => u.nombre === unidadSeleccionadaParaEditar);
      if (!unidadObj || !unidadObj.id) return;

      const formData = new FormData();
      formData.append("action", "delete_unit");
      formData.append("unidad_id", unidadObj.id);

      try {
        const resp = await fetch("api/unidades.php", {
          method: "POST",
          body: formData
        });
        const res = await resp.json();
        if (res.success) {
          await cargarDatosDesdeServidor();
          refrescarUnidades();
          cerrarModal("modalEditarUnidad");
        }
      } catch (e) {
        mostrarModalMensaje("Error", "No se pudo eliminar la unidad.");
      }
    }
  );
}

function refrescarAlumnos(info) {
  const tablaBody = document.getElementById("tabla-alumnos-body");
  if (!tablaBody) return;

  tablaBody.innerHTML = "";

  const lista = info.alumnos || [];

  if (lista.length === 0) {
    tablaBody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding: 20px; color:#64748b;">No hay estudiantes matriculados en este curso.</td></tr>`;
    actualizarBandejaAlumnos();
    return;
  }

  // La lista del alumno contiene únicamente su propia ficha. No reutilizar
  // una selección anterior (por ejemplo, de otra sesión o de otro curso).
  const alumnoObjetivo = esUsuarioAlumno
    ? lista[0]
    : (lista.find((al) => al.email === alumnoSeleccionadoEmail) || lista[0]);
  const alumnoActualEmail = alumnoObjetivo?.email || "";

  lista.forEach((al) => {
    const nota = Math.max(0, Math.min(10, Number(al.nota) || 0));
    const porcentaje = Math.round(nota * 10);
    const claseRendimiento = obtenerClaseRendimiento(nota);
    const tr = document.createElement("tr");
    tr.dataset.filtroCoincide = "true";
    const esInactivo = al.activo === 0;

    const seleccionado = al.email === alumnoActualEmail;
    tr.className = "row-juan" + (seleccionado ? " selected" : "") + (esInactivo ? " row-alumno-baja" : "");
    tr.style.cursor = "pointer";

    tr.onclick = function () {
      document.querySelectorAll(".row-juan").forEach((r) => r.classList.remove("selected"));
      tr.classList.add("selected");
      seleccionarAlumnoRapido(al);
    };

    const estadoHtml = esInactivo
      ? `<span class="badge-baja" title="Dado de baja">Baja</span>`
      : `<span class="badge-activo">Activo</span>`;

    tr.innerHTML = `
      <td>${al.n}</td>
      <td><span style="font-weight: bold; padding: 2px 4px;">${escaparHTML(al.completo)}</span></td>
      <td class="nota-corriente ${claseRendimiento}" style="text-align:center;">${nota}</td>
      <td>
        <div class="student-progress ${claseRendimiento}">
          <span>${porcentaje}%</span>
          <div class="student-progress-track"><i style="width: ${porcentaje}%"></i></div>
        </div>
      </td>
      <td style="text-align:center;">${estadoHtml}</td>
    `;

    tablaBody.appendChild(tr);
  });

  actualizarBandejaAlumnos();
  if (alumnoObjetivo) seleccionarAlumnoRapido(alumnoObjetivo);
}

function actualizarBandejaAlumnos() {
  const filas = Array.from(document.querySelectorAll("#tabla-alumnos-body tr"));
  const filasCoincidentes = filas.filter((fila) => fila.dataset.filtroCoincide !== "false");
  const boton = document.getElementById("btnExpandirAlumnos");
  const texto = document.getElementById("textoExpandirAlumnos");
  const flecha = boton?.querySelector(".student-roster-toggle-arrow");
  let indiceCoincidente = 0;

  filas.forEach((fila) => {
    const coincide = fila.dataset.filtroCoincide !== "false";
    fila.hidden = !coincide || (!alumnosListaExpandida && indiceCoincidente >= 7);
    if (coincide) indiceCoincidente += 1;
  });

  if (!boton) return;
  const hayMas = filasCoincidentes.length > 7;
  boton.hidden = !hayMas;
  boton.setAttribute("aria-expanded", alumnosListaExpandida && hayMas ? "true" : "false");
  if (texto) texto.textContent = alumnosListaExpandida ? "Mostrar menos alumnos" : `Mostrar ${filasCoincidentes.length - 7} alumnos más`;
  if (flecha) flecha.textContent = alumnosListaExpandida ? "⌃" : "⌄";
}

function alternarBandejaAlumnos() {
  alumnosListaExpandida = !alumnosListaExpandida;
  actualizarBandejaAlumnos();
}

function obtenerClaseRendimiento(nota) {
  if (nota < 6) return "performance-red";
  if (nota < 8) return "performance-yellow";
  return "performance-green";
}

function seleccionarAlumnoRapido(alumnoObj) {
  if (!alumnoObj) return;

  alumnoSeleccionadoEmail = alumnoObj.email;
  alumnoSeleccionadoId = alumnoObj.id || 0;

  asignarTexto("detalle-nombre-rapido", alumnoObj.corto || alumnoObj.completo);
  asignarTexto("detalle-email-alumno", alumnoObj.email || "Ficha de Seguimiento Escolar");

  const inputNota = document.getElementById("inputNotaAlumnoDetalle");
  const nombreEditar = document.getElementById("detalle-nombre-editar");
  const condicionSelect = document.getElementById("detalle-condicion-alumno");
  const emailEditar = document.getElementById("detalle-email-editar");
  const dniEditar = document.getElementById("detalle-dni-editar");
  const observacionesEditar = document.getElementById("detalle-observaciones-docente");
  const observacionesAulaAlumno = document.getElementById("observacionesAulaAlumnoTexto");
  const btnBaja = document.getElementById("btnDarDeBajaAlumno");
  const btnReinc = document.getElementById("btnReincorporarDetalle");

  if (inputNota) inputNota.value = alumnoObj.nota ?? 0;
  if (nombreEditar) nombreEditar.value = alumnoObj.completo || "";
  if (emailEditar) emailEditar.value = alumnoObj.email || "";
  if (dniEditar) dniEditar.value = alumnoObj.dni || "";
  if (observacionesEditar) observacionesEditar.value = alumnoObj.observaciones_docente || "";
  if (observacionesAulaAlumno) {
    observacionesAulaAlumno.textContent = alumnoObj.observaciones_docente?.trim() || "Todavía no hay observaciones del profesor.";
  }
  if (condicionSelect) {
    const cond = alumnoObj.condicion === "Mal" ? "Desaprobado" : alumnoObj.condicion === "Excelente" ? "Bien" : (alumnoObj.condicion || "Regular");
    condicionSelect.value = cond;
  }

  // Visibilidad de botones según estado activo/baja
  if (alumnoObj.activo === 0) {
    if (btnBaja) btnBaja.style.display = "none";
    if (btnReinc) btnReinc.style.display = "inline-block";
  } else {
    if (btnBaja) btnBaja.style.display = "inline-block";
    if (btnReinc) btnReinc.style.display = "none";
  }
}

async function guardarCambiosAlumnoDetalle() {
  if (!alumnoSeleccionadoEmail && !alumnoSeleccionadoId) return;

  const nombreInput = document.getElementById("detalle-nombre-editar");
  const notaInput = document.getElementById("inputNotaAlumnoDetalle");
  const emailInput = document.getElementById("detalle-email-editar");
  const dniInput = document.getElementById("detalle-dni-editar");
  const observacionesInput = document.getElementById("detalle-observaciones-docente");
  const condicionSelect = document.getElementById("detalle-condicion-alumno");

  const nuevoNombre = nombreInput ? nombreInput.value.trim() : "";
  const nuevaNota = notaInput ? parseFloat(notaInput.value) : 0;
  const nuevoEmail = emailInput ? emailInput.value.trim() : "";
  const nuevoDni = dniInput ? dniInput.value.trim() : "";
  const observacionesDocente = observacionesInput ? observacionesInput.value.trim() : "";
  const nuevaCondicion = condicionSelect ? condicionSelect.value : "Regular";

  if (isNaN(nuevaNota) || nuevaNota < 0 || nuevaNota > 10) {
    mostrarModalMensaje("Nota inválida", "La calificación debe ser un valor entre 0 y 10.");
    return;
  }

  try {
    const resp = await fetch("api/alumnos.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "update",
        id: alumnoSeleccionadoId,
        email_original: alumnoSeleccionadoEmail,
        curso_id: cursoActual,
        completo: nuevoNombre,
        email: nuevoEmail,
        dni: nuevoDni,
        observaciones_docente: observacionesDocente,
        nota: nuevaNota,
        condicion: nuevaCondicion
      })
    });
    const res = await resp.json();

    if (res.success) {
      await cargarDatosDesdeServidor();
      refrescarAlumnos(datosCursos[cursoActual]);
      refrescarDashboard(datosCursos[cursoActual]);
      mostrarModalMensaje("Ficha actualizada", "Cambios del estudiante guardados correctamente en la base de datos.");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo actualizar.");
    }
  } catch (e) {
    mostrarModalMensaje("Error", "Fallo de comunicación con la base de datos.");
  }
}

// Baja Lógica (Soft-Delete): No se borra de la BD, se marca inactivo
function eliminarAlumnoSeleccionado() {
  if (!alumnoSeleccionadoEmail && !alumnoSeleccionadoId) return;

  mostrarModalConfirmacion(
    "Dar de baja a estudiante",
    "¿Confirmas dar de baja a este estudiante? El registro quedará archivado en el sistema y el Administrador General podrá reincorporarlo en cualquier momento sin perder notas.",
    async () => {
      try {
        const resp = await fetch("api/alumnos.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "soft_delete",
            id: alumnoSeleccionadoId,
            email: alumnoSeleccionadoEmail,
            curso_id: cursoActual
          })
        });
        const res = await resp.json();

        if (res.success) {
          mostrarModalMensaje("Baja registrada", res.message);
          alumnoSeleccionadoEmail = "";
          alumnoSeleccionadoId = 0;
          await cargarDatosDesdeServidor();
          refrescarAlumnos(datosCursos[cursoActual]);
          refrescarDashboard(datosCursos[cursoActual]);
        } else {
          mostrarModalMensaje("Error", res.message || "No se pudo dar de baja.");
        }
      } catch (err) {
        mostrarModalMensaje("Error", "Fallo al procesar baja en el servidor.");
      }
    }
  );
}

// Reincorporar estudiante desde el panel de detalle
async function reincorporarAlumnoDetalle() {
  if (!alumnoSeleccionadoId) return;
  await reincorporarAlumnoPorId(alumnoSeleccionadoId);
}

// Reincorporar estudiante por ID
async function reincorporarAlumnoPorId(idAlumno) {
  try {
    const resp = await fetch("api/alumnos.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "restore", id: idAlumno })
    });
    const res = await resp.json();

    if (res.success) {
      mostrarModalMensaje("Estudiante reincorporado", res.message);
      await cargarDatosDesdeServidor();
      refrescarAlumnos(datosCursos[cursoActual]);
      if (esUsuarioAdmin) {
        cargarRegistroGlobalAlumnosAdmin();
      }
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo reincorporar.");
    }
  } catch (e) {
    mostrarModalMensaje("Error", "Fallo al comunicar con la base de datos.");
  }
}

async function guardarNuevoEstudiante() {
  const completoInput = document.getElementById("inputRegNombreCompleto");
  const cortoInput = document.getElementById("inputRegNombreCorto");
  const emailInput = document.getElementById("inputRegEmail");
  const dniInput = document.getElementById("inputRegDni");

  const completo = completoInput ? completoInput.value.trim() : "";
  const corto = cortoInput ? cortoInput.value.trim() : "";
  const email = emailInput ? emailInput.value.trim() : "";
  const dni = dniInput ? dniInput.value.trim() : "";

  if (!completo || !corto || !/^\d{7,10}$/.test(dni.replace(/\D/g, ""))) {
    mostrarModalMensaje("Campos incompletos", "Completá el nombre y un DNI válido de entre 7 y 10 números.");
    return;
  }

  try {
    const resp = await fetch("api/alumnos.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "create",
        curso_id: cursoActual,
        completo,
        corto,
        email,
        dni
      })
    });
    const res = await resp.json();

    if (res.success) {
      await cargarDatosDesdeServidor();
      refrescarAlumnos(datosCursos[cursoActual]);
      refrescarDashboard(datosCursos[cursoActual]);
      cerrarModal("modalRegistrarAlumno");
      completoInput.value = "";
      cortoInput.value = "";
      if (emailInput) emailInput.value = "";
      if (dniInput) dniInput.value = "";
      mostrarModalMensaje("Inscripción exitosa", res.message);
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo inscribir al alumno.");
    }
  } catch (err) {
    mostrarModalMensaje("Error", "Error al registrar estudiante en el servidor.");
  }
}

function leerFilasCSV(texto, separador) {
  const filas = [];
  let fila = [], campo = "", entreComillas = false;
  for (let i = 0; i < texto.length; i++) {
    const caracter = texto[i];
    if (caracter === '"') {
      if (entreComillas && texto[i + 1] === '"') { campo += '"'; i++; }
      else entreComillas = !entreComillas;
    } else if (caracter === separador && !entreComillas) {
      fila.push(campo.trim()); campo = "";
    } else if ((caracter === "\n" || caracter === "\r") && !entreComillas) {
      if (caracter === "\r" && texto[i + 1] === "\n") i++;
      fila.push(campo.trim());
      if (fila.some((valor) => valor !== "")) filas.push(fila);
      fila = []; campo = "";
    } else campo += caracter;
  }
  fila.push(campo.trim());
  if (fila.some((valor) => valor !== "")) filas.push(fila);
  return filas;
}

async function importarAlumnosCSV(input) {
  const archivo = input?.files?.[0];
  if (!archivo) return;
  try {
    const texto = (await archivo.text()).replace(/^\uFEFF/, "");
    const primeraLinea = texto.split(/\r?\n/, 1)[0] || "";
    const separadores = [";", ",", "\t"];
    const separador = separadores.sort((a, b) => primeraLinea.split(b).length - primeraLinea.split(a).length)[0];
    const filas = leerFilasCSV(texto, separador);
    let indices = { nombre: 0, email: 1, dni: 2 };
    if (filas.length && /nombre|apellido|email|correo|dni/i.test(filas[0].join(" "))) {
      const encabezados = filas.shift().map((texto) => texto.toLowerCase());
      indices = {
        nombre: encabezados.findIndex((texto) => /nombre|apellido|alumno|estudiante/.test(texto)),
        email: encabezados.findIndex((texto) => /email|correo/.test(texto)),
        dni: encabezados.findIndex((texto) => /dni|documento/.test(texto))
      };
    }
    const alumnos = filas.map((fila) => ({
      completo: fila[indices.nombre] || "",
      email: indices.email >= 0 ? (fila[indices.email] || "") : "",
      dni: indices.dni >= 0 ? (fila[indices.dni] || "") : ""
    })).filter((alumno) => alumno.completo);
    if (!alumnos.length) {
      mostrarModalMensaje("Archivo vacío", "No encontré nombres. Incluí columnas para nombre completo, email opcional y DNI.");
      return;
    }
    if (alumnos.length > 500) {
      mostrarModalMensaje("Demasiados registros", "Podés importar hasta 500 alumnos por archivo.");
      return;
    }
    if (alumnos.some((alumno) => alumno.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(alumno.email))) {
      mostrarModalMensaje("Email inválido", "Revisá los emails del CSV.");
      return;
    }
    if (alumnos.some((alumno) => !/^\d{7,10}$/.test(alumno.dni.replace(/\D/g, "")))) {
      mostrarModalMensaje("DNI inválido", "Cada fila debe incluir un DNI de entre 7 y 10 números. Usá encabezados: nombre, email, DNI.");
      return;
    }
    const dnisImportados = alumnos.map((alumno) => alumno.dni.replace(/\D/g, ""));
    if (new Set(dnisImportados).size !== dnisImportados.length) {
      mostrarModalMensaje("DNI repetido", "El archivo contiene el mismo DNI más de una vez.");
      return;
    }
    mostrarModalConfirmacion("Importar alumnos", `Se agregarán ${alumnos.length} alumnos al curso actual. ¿Querés continuar?`, async () => {
      try {
        const resp = await fetch("api/alumnos.php", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "import", curso_id: cursoActual, alumnos })
        });
        const res = await resp.json();
        mostrarModalMensaje(res.success ? "Importación completada" : "No se pudo importar", res.message || "Ocurrió un error.");
        if (res.success) {
          await cargarDatosDesdeServidor();
          refrescarInterfazSegunPagina();
        }
      } catch (error) {
        mostrarModalMensaje("Error de conexión", "No se pudo importar la lista.");
      }
    });
  } catch (error) {
    mostrarModalMensaje("No se pudo leer el archivo", "Guardá la lista como CSV UTF-8 e intentá de nuevo.");
  } finally {
    input.value = "";
  }
}

// ==========================================
// PANEL EXCLUSIVO ADMIN GENERAL
// ==========================================

function cambiarSubtabAdmin(subpanelId, btn) {
  document.querySelectorAll(".admin-subpanel").forEach((p) => p.classList.remove("active"));
  document.querySelectorAll(".admin-subnav-btn").forEach((b) => b.classList.remove("active"));

  const panel = document.getElementById(subpanelId);
  if (panel) panel.classList.add("active");
  if (btn) btn.classList.add("active");

  if (subpanelId === "adminAlumnos") cargarRegistroGlobalAlumnosAdmin();
  if (subpanelId === "adminLogs") cargarLogsAdmin();
  if (subpanelId === "adminUsuarios") cargarAdminUsuarios();
  if (subpanelId === "adminIncidencias") cargarIncidenciasAdmin();
}

async function enviarIncidencia() {
  const categoria = document.getElementById("incidenciaCategoria");
  const descripcion = document.getElementById("incidenciaDescripcion");
  const estado = document.getElementById("incidenciaEstado");
  const boton = document.getElementById("btnEnviarIncidencia");
  if (!categoria || !descripcion || !estado || !boton) return;

  const texto = descripcion.value.trim();
  if (texto.length < 10 || texto.length > 5000) {
    estado.textContent = "Describí el problema en 10 a 5.000 caracteres.";
    return;
  }

  boton.disabled = true;
  estado.textContent = "Enviando reporte...";
  try {
    const resp = await fetch("api/incidencias.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ categoria: categoria.value, descripcion: texto })
    });
    const res = await resp.json();
    if (!resp.ok || !res.success) {
      estado.textContent = res.message || "No se pudo enviar el reporte.";
      return;
    }

    cerrarModal("modalReportarIncidencia");
    categoria.value = "acceso";
    descripcion.value = "";
    estado.textContent = "";
    mostrarModalMensaje("Reporte enviado", "Administración recibió tu incidencia y la revisará desde el panel del sistema.");
  } catch (error) {
    estado.textContent = "No se pudo conectar con el servidor. Intentá nuevamente.";
  } finally {
    boton.disabled = false;
  }
}

async function cargarIncidenciasAdmin() {
  const tbody = document.getElementById("tablaAdminIncidenciasBody");
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:15px;">Cargando incidencias...</td></tr>';

  try {
    const resp = await fetch("api/admin.php?action=incidents", { cache: "no-store" });
    const res = await resp.json();
    if (!resp.ok || !res.success || !Array.isArray(res.incidencias)) {
      throw new Error(res.message || "No se pudieron cargar las incidencias.");
    }
    if (res.incidencias.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#64748b;">Todavía no hay incidencias recibidas.</td></tr>';
      return;
    }

    const categorias = {
      acceso: "Acceso",
      contenidos: "Contenidos",
      alumnos: "Registro de alumnos",
      calificaciones: "Calificaciones u observaciones",
      calendario: "Calendario",
      otro: "Otro"
    };
    const estados = { abierta: "Abierta", en_revision: "En revisión", resuelta: "Resuelta" };
    tbody.innerHTML = res.incidencias.map((incidencia) => `
      <tr>
        <td>${escaparHTML(incidencia.creado_en)}</td>
        <td><strong>${escaparHTML(incidencia.usuario_nombre)}</strong><br><small>${escaparHTML(incidencia.usuario_email)}</small><br><small>${escaparHTML(incidencia.rol).toUpperCase()}</small></td>
        <td>${escaparHTML(categorias[incidencia.categoria] || incidencia.categoria)}</td>
        <td class="incident-description">${escaparHTML(incidencia.descripcion)}</td>
        <td>${escaparHTML(estados[incidencia.estado] || incidencia.estado)}</td>
        <td>
          <div class="incident-status-control">
            <select id="incidencia-estado-${Number(incidencia.id)}" class="utn-rect-select" aria-label="Estado de incidencia">
              ${Object.entries(estados).map(([valor, etiqueta]) => `<option value="${valor}" ${incidencia.estado === valor ? "selected" : ""}>${etiqueta}</option>`).join("")}
            </select>
            <button class="utn-btn-rect-secondary" onclick="actualizarEstadoIncidencia(${Number(incidencia.id)})">Guardar</button>
          </div>
        </td>
      </tr>
    `).join("");
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; color:#b42318;">No se pudieron cargar las incidencias.</td></tr>';
  }
}

async function actualizarEstadoIncidencia(id) {
  const estado = document.getElementById(`incidencia-estado-${id}`)?.value || "";
  try {
    const resp = await fetch("api/admin.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "update_incident_status", id, estado })
    });
    const res = await resp.json();
    mostrarModalMensaje(res.success ? "Incidencia actualizada" : "No se pudo actualizar", res.message || "Ocurrió un error.");
    if (res.success) await cargarIncidenciasAdmin();
  } catch (error) {
    mostrarModalMensaje("Error de conexión", "No se pudo actualizar el estado de la incidencia.");
  }
}

// Registro global: los activos se ven normales y los dados de baja en gris con botón "Reincorporar"
async function cargarRegistroGlobalAlumnosAdmin() {
  const tbody = document.getElementById("tablaAdminAlumnosBody");
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; padding:15px;">Consultando base de datos...</td></tr>`;

  try {
    const resp = await fetch("api/admin.php?action=students_registry", { cache: "no-store" });
    const res = await resp.json();

    if (!res.success || !res.alumnos) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#ef4444;">Error al cargar registros.</td></tr>`;
      return;
    }

    if (res.alumnos.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#64748b;">No hay alumnos registrados en el sistema.</td></tr>`;
      return;
    }

    tbody.innerHTML = "";
    const linkedIds = new Set(res.alumnos.map((al) => al.usuario_id).filter(Boolean));
    res.alumnos.forEach((al) => {
      const esBaja = al.activo === 0;
      const tr = document.createElement("tr");

      if (esBaja) {
        tr.className = "row-alumno-baja";
      }

      const estadoBadge = esBaja
        ? `<span class="badge-baja">Dado de baja</span><br><small style="color:#94a3b8; font-size:0.7rem;">${escaparHTML(al.fecha_baja || '')}</small>`
        : `<span class="badge-activo">Activo</span>`;

      const accionBtn = esBaja
        ? `<button class="btn-reincorporar" onclick="reincorporarAlumnoPorId(${al.id})">↻ Reincorporar</button>`
        : `<span style="color:#64748b; font-size:0.8rem;">En curso regular</span>`;
      const accountOptions = (res.cuentas_alumno || [])
        .filter((cuenta) => !linkedIds.has(cuenta.id) || cuenta.id === al.usuario_id)
        .map((cuenta) => `<option value="${Number(cuenta.id)}" ${cuenta.id === al.usuario_id ? "selected" : ""}>${escaparHTML(cuenta.nombre_completo)} (${escaparHTML(cuenta.username)})</option>`)
        .join("");
      const accountControl = `<div style="display:flex; gap:6px; min-width:250px;"><select id="vincular-cuenta-${al.id}" class="utn-rect-select"><option value="">Sin vincular</option>${accountOptions}</select><button class="utn-btn-rect-secondary" onclick="vincularCuentaAlumno(${al.id})">Vincular</button></div>`;

      tr.innerHTML = `
        <td><strong>${escaparHTML(al.nombre_curso)}</strong></td>
        <td>${al.n}</td>
        <td><strong>${escaparHTML(al.completo)}</strong></td>
        <td>${escaparHTML(al.dni)}</td>
        <td>${escaparHTML(al.email)}</td>
        <td style="text-align:center; font-weight:bold;">${al.nota}</td>
        <td style="text-align:center;">${estadoBadge}</td>
        <td style="text-align:center;">${accionBtn}</td>
        <td>${accountControl}</td>
      `;

      tbody.appendChild(tr);
    });

  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color:#ef4444;">Fallo de conexión.</td></tr>`;
  }
}

async function vincularCuentaAlumno(alumnoId) {
  const select = document.getElementById(`vincular-cuenta-${alumnoId}`);
  if (!select) return;
  try {
    const resp = await fetch("api/admin.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "link_student", alumno_id: alumnoId, usuario_id: select.value })
    });
    const res = await resp.json();
    mostrarModalMensaje(res.success ? "Vinculación actualizada" : "No se pudo vincular", res.message || "Ocurrió un error.");
    if (res.success) cargarRegistroGlobalAlumnosAdmin();
  } catch (error) {
    mostrarModalMensaje("Error de conexión", "No se pudo guardar la vinculación de la cuenta.");
  }
}

async function cargarLogsAdmin() {
  const tbody = document.getElementById("tablaAdminLogsBody");
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:15px;">Consultando bitácora de auditoría...</td></tr>`;

  try {
    const resp = await fetch("api/admin.php?action=logs&limit=60", { cache: "no-store" });
    const res = await resp.json();

    if (!res.success || !res.logs) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#ef4444;">Error al cargar logs.</td></tr>`;
      return;
    }

    tbody.innerHTML = "";
    res.logs.forEach((log) => {
      const tr = document.createElement("tr");
      const esOk = log.exitoso === 1;
      const statusHtml = esOk
        ? `<span style="color:#10b981; font-weight:bold;">✓ Exitoso</span>`
        : `<span style="color:#ef4444; font-weight:bold;">✕ Fallido</span>`;

      tr.innerHTML = `
        <td>${escaparHTML(log.fecha_ingreso)}</td>
        <td><strong>${escaparHTML(log.username)}</strong></td>
        <td><span style="font-size:0.75rem; background:#e2e8f0; padding:2px 6px; border-radius:4px;">${escaparHTML(log.rol).toUpperCase()}</span></td>
        <td><code>${escaparHTML(log.ip)}</code></td>
        <td style="font-size:0.8rem; color:#64748b;" title="${escaparHTML(log.user_agent)}">${escaparHTML(String(log.user_agent || "").substring(0, 45))}...</td>
        <td style="text-align:center;">${statusHtml}</td>
      `;
      tbody.appendChild(tr);
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#ef4444;">Fallo al consultar logs.</td></tr>`;
  }
}

async function cargarAdminUsuarios() {
  const tbody = document.getElementById("tablaAdminUsuariosBody");
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:15px;">Cargando usuarios...</td></tr>`;

  try {
    const resp = await fetch("api/admin.php?action=users", { cache: "no-store" });
    const res = await resp.json();

    if (!res.success || !res.users) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:#ef4444;">Error al cargar usuarios.</td></tr>`;
      return;
    }

    tbody.innerHTML = "";
    res.users.forEach((u) => {
      const tr = document.createElement("tr");
      const rolColor = u.rol === "admin" ? "#f59e0b" : "#0284c7";
      const opcionesRol = ["admin", "profesor", "alumno"].map((rol) => `<option value="${rol}" ${u.rol === rol ? "selected" : ""}>${rol === "admin" ? "Administrador" : rol === "profesor" ? "Docente" : "Alumno"}</option>`).join("");
      const cursosOptions = (res.cursos || []).map((curso) => `<option value="${escaparHTML(curso.id)}" ${String(curso.profesor_id) === String(u.id) ? "selected" : ""}>${escaparHTML(curso.titulo)}</option>`).join("");

      tr.innerHTML = `
        <td style="font-weight:bold; text-align:center;">${u.orden}</td>
        <td><strong>${escaparHTML(u.nombre_completo)}</strong></td>
        <td><code>${escaparHTML(u.username)}</code></td>
        <td>${escaparHTML(u.email)}</td>
        <td><span style="background:${rolColor}; color:#fff; font-size:0.75rem; padding:2px 6px; border-radius:4px; font-weight:bold;">${escaparHTML(u.rol).toUpperCase()}</span></td>
        <td><div style="display:flex; gap:6px; align-items:center;"><select id="adminCursosUsuario${u.id}" class="utn-rect-select" multiple size="3" ${u.rol === "profesor" ? "" : "disabled"}>${cursosOptions}</select><button class="utn-btn-rect-secondary" onclick="actualizarCursosUsuario(${u.id})" ${u.rol === "profesor" ? "" : "disabled"}>Guardar</button></div></td>
        <td style="text-align:center;">
          <div style="display:flex; gap:6px; align-items:center; justify-content:center;">
            <select id="adminRolUsuario${u.id}" class="utn-rect-select">${opcionesRol}</select>
            <button class="utn-btn-rect-secondary" onclick="actualizarRolUsuario(${u.id})">Guardar</button>
          </div>
        </td>
      `;
      tbody.appendChild(tr);
    });

  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; color:#ef4444;">Fallo de conexión.</td></tr>`;
  }
}

async function actualizarRolUsuario(usuarioId) {
  const rol = document.getElementById(`adminRolUsuario${usuarioId}`)?.value || "";
  try {
    const resp = await fetch("api/admin.php", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "set_user_role", id: usuarioId, rol })
    });
    const res = await resp.json();
    if (!res.success) {
      mostrarModalMensaje("No se pudo cambiar el rol", res.message || "Ocurrió un error.");
      return;
    }
    mostrarModalMensaje("Rol actualizado", res.message);
    if (Number(usuarioId) === Number(usuarioLogueado?.id)) {
      window.location.reload();
      return;
    }
    await cargarAdminUsuarios();
    await cargarDatosDesdeServidor();
  } catch (error) {
    mostrarModalMensaje("Error de conexión", "No se pudo actualizar el rol.");
  }
}

async function actualizarCursosUsuario(usuarioId) {
  const select = document.getElementById(`adminCursosUsuario${usuarioId}`);
  if (!select) return;
  const cursoIds = Array.from(select.selectedOptions).map((option) => option.value);
  try {
    const resp = await fetch("api/admin.php", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "set_teacher_courses", id: usuarioId, curso_ids: cursoIds })
    });
    const res = await resp.json();
    mostrarModalMensaje(res.success ? "Cursos actualizados" : "No se pudieron asignar", res.message || "Ocurrió un error.");
    if (res.success) {
      await cargarAdminUsuarios();
      await cargarDatosDesdeServidor();
    }
  } catch (error) {
    mostrarModalMensaje("Error de conexión", "No se pudieron guardar los cursos del docente.");
  }
}

function toggleSelectorCursoUsuario(rol) {
  const bloque = document.getElementById("bloqueAsignarCursoUser");
  if (bloque) {
    bloque.style.display = rol === "profesor" ? "block" : "none";
  }
}

async function guardarUsuarioManualAdmin() {
  const nombre = document.getElementById("inputAdminUserNombre")?.value.trim() || "";
  const login = document.getElementById("inputAdminUserLogin")?.value.trim() || "";
  const email = document.getElementById("inputAdminUserEmail")?.value.trim() || "";
  const pass = document.getElementById("inputAdminUserPass")?.value || "";
  const rol = document.getElementById("selectAdminUserRol")?.value || "profesor";
  const cursoId = document.getElementById("selectAdminUserCurso")?.value || "";

  if (!nombre || !login || !email || !pass) {
    mostrarModalMensaje("Campos incompletos", "Complete todos los datos del usuario.");
    return;
  }
  if (new TextEncoder().encode(pass).length < 12 || new TextEncoder().encode(pass).length > 72) {
    mostrarModalMensaje("Contraseña no válida", "Usá una contraseña de 12 a 72 caracteres.");
    return;
  }

  try {
    const resp = await fetch("api/admin.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "create_user",
        nombre_completo: nombre,
        username: login,
        email,
        password: pass,
        rol,
        curso_id: cursoId
      })
    });
    const res = await resp.json();

    if (res.success) {
      mostrarModalMensaje("Usuario creado", res.message);
      cerrarModal("modalNuevoUsuario");
      cargarAdminUsuarios();
      await cargarDatosDesdeServidor();
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo crear el usuario.");
    }
  } catch (err) {
    mostrarModalMensaje("Error", "Fallo al comunicar con el servidor.");
  }
}

// Descarga directa del backup SQL generado por PHP
function descargarBackupSQL() {
  window.location.href = "api/backup.php?action=download";
}

// ==========================================
// CONFIGURACIÓN DE CÁTEDRA
// ==========================================

async function guardarConfiguracionCatedra() {
  const fechaInput = document.getElementById("configFechaExamen");
  const temaInput = document.getElementById("configTemaExamen");
  const comunicadoInput = document.getElementById("configComunicadoProfesora");
  const driveInput = document.getElementById("configDriveUrl");

  if (!fechaInput || !temaInput) return;

  try {
    const resp = await fetch("api/cursos.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "update_info",
        curso_id: cursoActual,
        proximo_examen: fechaInput.value.trim(),
        tema_examen: temaInput.value.trim(),
        comunicado_profesora: comunicadoInput ? comunicadoInput.value.trim() : "",
        drive_url: driveInput ? driveInput.value.trim() : ""
      })
    });
    const res = await resp.json();

    if (res.success) {
      await cargarDatosDesdeServidor();
      refrescarInterfazSegunPagina();
      cerrarModal("modalConfiguracion");
      mostrarModalMensaje("Configuración guardada", "Los datos de la cátedra se han actualizado en la base de datos.");
    } else {
      mostrarModalMensaje("Error", res.message || "No se pudo guardar la configuración.");
    }
  } catch (e) {
    mostrarModalMensaje("Error", "Error al guardar configuración.");
  }
}

function restaurarConfiguracionPredeterminada() {
  const info = datosCursos[cursoActual];
  if (!info) return;
  document.getElementById("configFechaExamen").value = info.proximoExamen || "";
  document.getElementById("configTemaExamen").value = info.temaExamen || "";
  document.getElementById("configComunicadoProfesora").value = info.comunicadoProfesora || "";
  document.getElementById("configDriveUrl").value = info.drive_url || "";
}

// ==========================================
// HERRAMIENTAS Y MODALES AUXILIARES
// ==========================================

function conmutarBuscadorLupa() {
  const buscador = document.getElementById("inputBuscarFiltro");
  const wrapperBuscador = document.getElementById("wrapperBuscador");
  if (!buscador || !wrapperBuscador) return;

  wrapperBuscador.classList.toggle("open");
  if (wrapperBuscador.classList.contains("open")) {
    buscador.focus();
  } else {
    buscador.value = "";
    filtrarAlumnosEnTabla("");
  }
}

function filtrarAlumnosEnTabla(textoBusqueda) {
  const textoClean = textoBusqueda.toLowerCase().trim();
  const filas = document.querySelectorAll("#tabla-alumnos-body tr");

  filas.forEach((fila) => {
    const celdaNombre = fila.getElementsByTagName("td")[1];
    if (!celdaNombre) return;
    const nombreCompleto = celdaNombre.textContent || celdaNombre.innerText;
    fila.dataset.filtroCoincide = nombreCompleto.toLowerCase().includes(textoClean) ? "true" : "false";
  });
  actualizarBandejaAlumnos();
}

function verTareaAdjunta(encodedTarea) {
  let tarea = {};
  try {
    tarea = JSON.parse(decodeURIComponent(encodedTarea));
  } catch (e) {
    tarea = { texto: decodeURIComponent(encodedTarea) };
  }

  if (tarea.url) {
    window.open(tarea.url, "_blank", "noopener,noreferrer");
    return;
  }

  if (tarea.archivo) {
    const rutaArchivo = "api/archivo.php?nombre=" + encodeURIComponent(tarea.archivo);
    window.open(rutaArchivo, "_blank", "noopener,noreferrer");
    return;
  }

  const texto = tarea.texto || "Contenido de tarea disponible.";
  mostrarModalMensaje("Detalle de contenido", texto);
}

function abrirModal(idModal) {
  if (esUsuarioAlumno && ["modalControlAcceso", "modalRegistrarAlumno", "modalAgregarTema", "modalNuevaUnidad", "modalEditarUnidad", "modalGestionarFecha", "modalConfiguracion", "modalNuevoUsuario"].includes(idModal)) return;
  if (idModal === "modalConfiguracion") restaurarConfiguracionPredeterminada();
  const modal = document.getElementById(idModal);
  if (modal) modal.style.display = "flex";
}

function cerrarModal(idModal) {
  const modal = document.getElementById(idModal);
  if (modal) modal.style.display = "none";
}

function mostrarModalMensaje(titulo, texto) {
  const appScr = document.getElementById("semaApp");
  const avisoLogin = document.getElementById("loginStatusMessage");
  if (appScr?.hidden && avisoLogin) {
    avisoLogin.textContent = `${titulo}: ${texto}`;
    avisoLogin.hidden = false;
    return;
  }

  const modal = document.getElementById("modalMensaje");
  if (!modal) return;
  document.getElementById("modalMensajeTitulo").innerText = titulo;
  document.getElementById("modalMensajeTexto").innerText = texto;
  abrirModal("modalMensaje");
}

function mostrarModalConfirmacion(titulo, texto, callback) {
  const modal = document.getElementById("modalConfirmacion");
  if (!modal) return;
  document.getElementById("modalConfirmacionTitulo").innerText = titulo;
  document.getElementById("modalConfirmacionTexto").innerText = texto;
  const botonAceptar = document.getElementById("modalConfirmacionAceptar");
  if (botonAceptar) {
    botonAceptar.onclick = () => {
      callback();
      cerrarModal("modalConfirmacion");
    };
  }
  abrirModal("modalConfirmacion");
}

function toggleNotificacionesPopup() {
  const popup = document.getElementById("notificacionesPopup");
  if (!popup) return;
  popup.classList.toggle("hidden");
  if (!popup.classList.contains("hidden")) {
    actualizarBitacoraNotificaciones();
    marcarNotificacionesLeidas();
  }
}

function actualizarBitacoraNotificaciones() {
  const contenido = document.getElementById("notificacionesContenido");
  if (!contenido) return;
  contenido.innerHTML = `
    <div class="popup-item" onclick="leerNotificacion('Base de datos conectada','El sistema SEMA ahora opera con persistencia MySQL activa.')"><strong>Base de datos conectada</strong><p>El sistema SEMA ahora opera con persistencia MySQL activa.</p></div>
    <div class="popup-item" onclick="leerNotificacion('Aviso de curso','El próximo examen será planificado en la agenda académica.')"><strong>Aviso de curso</strong><p>El próximo examen será planificado en la agenda académica.</p></div>
    <div class="popup-item" onclick="leerNotificacion('Backup disponible','El respaldo semanal de la base de datos se encuentra listo para descargar.')"><strong>Backup disponible</strong><p>El respaldo semanal de la base de datos se encuentra listo para descargar.</p></div>
  `;
}

function leerNotificacion(titulo, mensaje) {
  mostrarModalMensaje(titulo, mensaje);
  marcarNotificacionesLeidas();
}

function actualizarBadgeNotificaciones() {
  const badge = document.getElementById("badge-notificaciones");
  if (!badge) return;
  badge.style.display = notificacionesLeidas ? "none" : "inline-block";
}

function marcarNotificacionesLeidas() {
  notificacionesLeidas = true;
  actualizarBadgeNotificaciones();
}

function inicializarNotificaciones() {
  notificacionesLeidas = false;
  actualizarBadgeNotificaciones();
}

window.addEventListener("click", (event) => {
  const popup = document.getElementById("notificacionesPopup");
  if (popup && !popup.classList.contains("hidden") && !popup.contains(event.target) && event.target !== document.querySelector('[title="Notificaciones"]')) {
    popup.classList.add("hidden");
  }
});
