<?php
/**
 * Footer institucional SEMA
 */
$usuarioFooter = obtenerUsuarioActual();
$rolFooter = $usuarioFooter['rol'] ?? '';
?>
<footer class="utn-footer-real">
	<div class="footer-top-columns">
		<div class="footer-column-info">
			<h4 class="footer-title-brand">GESTIÓN ESCOLAR SECUNDARIA</h4>
			<p class="footer-address-text">Sistema de Evaluación de Matemática Aplicada (SEMA)</p>
			<p class="footer-address-text">Registro y control digital de contenidos y seguimiento escolar.</p>
		</div>

		<div class="footer-column-links">
			<h4 class="footer-title-list">SOPORTE DEL SISTEMA</h4>
			<ul class="footer-links-stack">
				<?php if (in_array($rolFooter, ['alumno', 'profesor'], true)): ?>
					<li><a href="#" onclick="abrirModal('modalReportarIncidencia'); return false;">Reportar incidencia</a></li>
				<?php endif; ?>
				<?php if ($rolFooter === 'profesor'): ?>
					<li><a href="#" onclick="abrirModal('modalManualProfesor'); return false;">Manual del profesor</a></li>
				<?php endif; ?>
			</ul>
		</div>
	</div>

	<div class="footer-bottom-copyright">
		<span>© Sistema SEMA - Registro Escolar de Contenidos y Calificaciones</span>
	</div>
</footer>
