<?php
/**
 * Barra de Navegación UTN - SEMA
 */
$usuarioActual = obtenerUsuarioActual();
$esAdminActual = esAdmin();
$esAlumnoActual = esAlumno();
?>
<header class="utn-header">
  <div class="utn-top-bar">
    <div style="display: flex; align-items: center; gap: 12px;">
      <span class="utn-brand-text">COLEGIO DE EDUCACIÓN TÉCNICA SECUNDARIA</span>
      <span class="utn-regional-text">Ciclo Lectivo Oficial</span>
    </div>
    <div class="utn-user-chip" id="userChipGreeting">
      <span class="user-chip-name" id="labelNombreUsuario"><?= htmlspecialchars($usuarioActual['nombre_completo'] ?? 'Usuario') ?></span>
      <span class="user-chip-role <?= $esAdminActual ? 'role-badge-admin' : 'role-badge-docente' ?>" id="labelRolUsuario">
        <?= $esAdminActual ? 'ADMINISTRADOR GENERAL' : ($esAlumnoActual ? 'ALUMNO' : 'DOCENTE') ?>
      </span>
    </div>
  </div>

  <div class="utn-main-nav">
    <div class="nav-left-block">
      <span class="label-nav-curso">CURSO:</span>
      <span id="cursoActualLabel" class="curso-actual-label" <?= $esAdminActual ? 'hidden' : '' ?>></span>
      <select class="select-utn-curso" id="selectorCursoGlobal" onchange="cambiarDeCurso(this.value)" <?= $esAdminActual ? '' : 'hidden' ?>>
        <!-- Se rellena dinámicamente con los cursos autorizados -->
        <option value="2gao">2° 1ra GAO</option>
        <option value="2cstep">2° 1ra TEP</option>
      </select>
    </div>

    <div class="utn-nav-links">
      <span onclick="cambiarPestana('sema', this)" class="utn-link-item active">INICIO SEMA</span>
      <span onclick="cambiarPestana('temas', this)" class="utn-link-item">RUTA DE APRENDIZAJE</span>
      <span onclick="cambiarPestana('lista', this)" class="utn-link-item" id="navItemLista" style="<?= $esAlumnoActual ? 'display:none;' : '' ?>">REGISTRO ALUMNOS</span>
      <span onclick="cambiarPestana('cron', this)" class="utn-link-item">CALENDARIO ACADÉMICO</span>
      <span onclick="cambiarPestana('adminPanel', this)" class="utn-link-item nav-admin-item" id="navItemAdmin" style="<?= $esAdminActual ? '' : 'display:none;' ?>">
        PANEL ADMINISTRACIÓN
      </span>
    </div>

    <div class="utn-nav-tools">
      <div class="search-wrapper" id="wrapperBuscador">
        <input type="text" id="inputBuscarFiltro" class="input-search-hidden" placeholder="Buscar alumno..." oninput="filtrarAlumnosEnTabla(this.value)">
        <button class="tool-btn" onclick="conmutarBuscadorLupa()" title="Buscar en el sistema">
          <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
        </button>
      </div>

      <button class="tool-btn" onclick="abrirModal('modalControlAcceso')" title="Solicitudes de Matrícula Pendientes">
        <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"></path><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path></svg>
        <span class="tool-badge" id="badge-solicitudes" style="display:none;">0</span>
      </button>

      <button class="tool-btn" onclick="toggleNotificacionesPopup()" title="Notificaciones">
        <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
        <span class="tool-badge" id="badge-notificaciones">3</span>
      </button>

      <button class="tool-btn" onclick="abrirModal('modalConfiguracion')" title="Ajustes de la Cátedra">
        <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
      </button>

      <button class="tool-btn backup-btn" id="btnBackupRapido" onclick="descargarBackupSQL()" title="Descargar Backup de Base de Datos" style="<?= $esAdminActual ? '' : 'display:none;' ?>">
        <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
      </button>

      <button class="tool-btn logout-btn" onclick="cerrarSesion()" title="Cerrar sesión">
        <svg class="icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><path d="M16 17l5-5-5-5"></path><path d="M21 12H9"></path></svg>
      </button>
    </div>
  </div>

  <div id="notificacionesPopup" class="notificaciones-popup hidden">
    <div class="popup-header">
      <span>Bitácora de Novedades</span>
      <button class="popup-close-btn" onclick="toggleNotificacionesPopup()">×</button>
    </div>
    <div id="notificacionesContenido" class="popup-body"></div>
  </div>
</header>
