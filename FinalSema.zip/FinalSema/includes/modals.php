<?php
/**
 * Diálogos Modales del Sistema SEMA
 */
?>
<!-- Modal 1: Control de Acceso / Solicitudes de Matrícula -->
<div id="modalControlAcceso" class="modal-window-overlay">
  <div class="modal-rect-card">
    <span class="modal-close-x" onclick="cerrarModal('modalControlAcceso')">&times;</span>
    <h3 class="modal-heading">SOLICITUDES DE INGRESO A MATRÍCULA</h3>
    <p style="font-size: 0.85rem; color: #475569; margin: 8px 0 15px 0;">Verifique la identidad de los estudiantes que solicitan incorporarse al libro de actas digital de este curso:</p>
    <div id="solicitudes-contenedor" style="margin-top: 16px;"></div>
  </div>
</div>

<!-- Modal 2: Registrar Nuevo Estudiante -->
<div id="modalRegistrarAlumno" class="modal-window-overlay">
  <div class="modal-rect-card" style="max-width: 450px;">
    <span class="modal-close-x" onclick="cerrarModal('modalRegistrarAlumno')">&times;</span>
    <h3 class="modal-heading">REGISTRAR NUEVO ESTUDIANTE</h3>
    <div class="utn-form-item" style="margin-top:16px;">
      <label class="utn-form-label">Apellido y Nombre Completo:</label>
      <input type="text" class="utn-rect-input" id="inputRegNombreCompleto" placeholder="Ej: Gómez, Braian Ezequiel" required>
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Nombre para Visualización Rápida:</label>
      <input type="text" class="utn-rect-input" id="inputRegNombreCorto" placeholder="Ej: Braian Gómez" required>
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Correo Electrónico de Contacto:</label>
      <input type="email" class="utn-rect-input" id="inputRegEmail" placeholder="Ej: estudiante@gmail.com">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">DNI (necesario para asociar la cuenta)</label>
      <input type="text" inputmode="numeric" class="utn-rect-input" id="inputRegDni" placeholder="Solo números" required>
    </div>
    <div class="modal-footer-buttons" style="margin-top: 24px;">
      <button class="utn-btn-rect-primary" onclick="guardarNuevoEstudiante()">Inscribir Alumno</button>
      <button class="utn-btn-rect-cancel" onclick="cerrarModal('modalRegistrarAlumno')">Cancelar</button>
    </div>
  </div>
</div>

<!-- Modal 3: Agregar Tema / Cápsula a Unidad -->
<div id="modalAgregarTema" class="modal-window-overlay">
  <div class="modal-rect-card modal-resource-card">
    <span class="modal-close-x" onclick="cerrarModal('modalAgregarTema')">&times;</span>
    <h3 class="modal-heading" id="dinamicoTituloUnidad">Adjuntar Eje de Contenido</h3>
    <p class="modal-help-text">Elegí el tipo de cápsula, escribí el nombre que verá la profesora y pegá el enlace del PDF, video o subí el archivo local.</p>
    <div class="resource-form-stack">
      <div class="resource-form-row resource-input-t">
        <span class="resource-input-badge">T</span>
        <div class="resource-input-fields resource-input-fields-single">
          <input type="text" class="utn-rect-input" id="inputNombreTemaImg" placeholder="Nombre visible del contenido">
          <input type="text" class="utn-rect-input" id="inputDescTemaImg" placeholder="Descripción breve (opcional)">
        </div>
      </div>
      <div class="resource-form-row resource-input-v">
        <span class="resource-input-badge resource-input-badge-wide">TIPO</span>
        <select id="selectTipoTema" class="utn-rect-select">
          <option value="T">T - Teoría / lectura</option>
          <option value="V">V - Video explicativo</option>
          <option value="E">E - Ejercicio / práctica</option>
        </select>
      </div>
      <div class="resource-form-row resource-input-e">
        <span class="resource-input-badge resource-input-badge-wide">URL</span>
        <input type="url" id="inputContenidoTema" class="utn-rect-input" placeholder="https://... PDF, video o material de apoyo">
      </div>
      <div class="resource-file-note">
        <label for="inputFileTema">O seleccionar un archivo local (se subirá al servidor):</label>
        <input type="file" id="inputFileTema" accept=".pdf,video/*,.doc,.docx,.ppt,.pptx,.txt,.zip">
      </div>
    </div>
    <div class="modal-footer-buttons">
      <button class="utn-btn-rect-primary" onclick="confirmarAgregarTema()">Acoplar al Eje Curricular</button>
      <button class="utn-btn-rect-cancel" onclick="cerrarModal('modalAgregarTema')">Cancelar</button>
    </div>
  </div>
</div>

<!-- Modal 4: Alta de Unidad Académica -->
<div id="modalNuevaUnidad" class="modal-window-overlay">
  <div class="modal-rect-card">
    <span class="modal-close-x" onclick="cerrarModal('modalNuevaUnidad')">&times;</span>
    <h3 class="modal-heading">DAR DE ALTA UNIDAD ACADÉMICA</h3>
    <p class="modal-help-text">Cargá la unidad y un recurso para cada cápsula. Los enlaces a PDF y videos se abrirán directamente.</p>
    <div class="utn-form-item" style="margin-top: 16px;">
      <label class="utn-form-label">Título Estructural de la Unidad:</label>
      <input type="text" class="utn-rect-input" id="inputNuevoNombreUnidad" placeholder="Ej: Unidad II: Planificación e Interfaces Dinámicas">
    </div>
    <div class="unit-resource-form">
      <div class="resource-input-row resource-input-t">
        <span class="resource-input-badge">T</span>
        <div class="resource-input-fields">
          <input type="text" class="utn-rect-input" id="inputNombreTeoria" placeholder="Nombre visible de la guía teórica">
          <input type="url" class="utn-rect-input" id="inputUrlTeoria" placeholder="URL del PDF o material teórico">
        </div>
      </div>
      <div class="resource-input-row resource-input-v">
        <span class="resource-input-badge">V</span>
        <div class="resource-input-fields">
          <input type="text" class="utn-rect-input" id="inputNombreVideo" placeholder="Nombre visible del video">
          <input type="url" class="utn-rect-input" id="inputUrlVideo" placeholder="URL del video explicativo">
        </div>
      </div>
      <div class="resource-input-row resource-input-e">
        <span class="resource-input-badge">E</span>
        <div class="resource-input-fields">
          <input type="text" class="utn-rect-input" id="inputNombreEjercicio" placeholder="Nombre visible de los ejercicios">
          <input type="url" class="utn-rect-input" id="inputUrlEjercicio" placeholder="URL del PDF o práctica">
        </div>
      </div>
    </div>
    <div class="modal-footer-buttons" style="margin-top: 24px;">
      <button class="utn-btn-rect-primary" onclick="guardarNuevaUnidad()">Confirmar Alta</button>
      <button class="utn-btn-rect-cancel" onclick="cerrarModal('modalNuevaUnidad')">Cancelar</button>
    </div>
  </div>
</div>

<!-- Modal 5: Editar Unidad -->
<div id="modalEditarUnidad" class="modal-window-overlay">
  <div class="modal-rect-card">
    <span class="modal-close-x" onclick="cerrarModal('modalEditarUnidad')">&times;</span>
    <h3 class="modal-heading">MODIFICAR ESTRUCTURA CURRICULAR</h3>
    <div class="utn-form-item" style="margin-top: 16px;">
      <label class="utn-form-label">Nombre de la Unidad Curricular:</label>
      <input type="text" class="utn-rect-input" id="inputEditarNombreUnidad">
    </div>
    <div class="modal-footer-buttons" style="margin-top: 24px;">
      <button class="utn-btn-rect-primary" onclick="guardarCambiosUnidad()">Guardar Modificación</button>
      <button class="utn-btn-rect-danger" onclick="eliminarUnidadActual()">Eliminar de Planificación</button>
    </div>
  </div>
</div>

<!-- Modal 6: Planificar Evento Escolar en Calendario -->
<div id="modalGestionarFecha" class="modal-window-overlay">
  <div class="modal-rect-card">
    <span class="modal-close-x" onclick="cerrarModal('modalGestionarFecha')">&times;</span>
    <h3 class="modal-heading">PLANIFICAR EVENTO ESCOLAR (DÍA <span id="txtDiaSeleccionado">0</span>)</h3>
    <div class="utn-form-item" style="margin-top:14px;">
      <label class="utn-form-label">Título de la Alerta Evaluativa:</label>
      <input type="text" class="utn-rect-input" id="inputTituloEvento" placeholder="Ej: Evaluación Integradora">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Consignas dispuestas:</label>
      <input type="text" class="utn-rect-input" id="inputDescEvento" placeholder="Ej: Contenido modular teórico-práctico">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Clasificación Curricular de Alerta:</label>
      <select id="selectTipoEvento" class="utn-rect-select">
        <option value="repaso">Clase de Repaso / Trabajo Integrador (Franja Amarilla)</option>
        <option value="recup">Instancia Evaluativa / Recuperatorio (Franja Violeta)</option>
        <option value="cierre">Cierre Definitivo del Trimestre (Franja Azul Oscuro)</option>
      </select>
    </div>
    <div class="modal-footer-buttons" style="margin-top: 24px;">
      <button class="utn-btn-rect-primary" onclick="guardarEventoCronograma()">Asentar en Agenda</button>
      <button class="utn-btn-rect-danger" id="btnBorrarEvento" onclick="eliminarEventoCronograma()">Eliminar Alerta</button>
    </div>
  </div>
</div>

<!-- Modal 7: Configuración de Cátedra -->
<div id="modalConfiguracion" class="modal-window-overlay">
  <div class="modal-rect-card">
    <span class="modal-close-x" onclick="cerrarModal('modalConfiguracion')">&times;</span>
    <h3 class="modal-heading">CONFIGURACIÓN DE LA CÁTEDRA</h3>
    <div class="utn-form-item" style="margin-top: 14px;">
      <label class="utn-form-label">Fecha de la próxima instancia evaluativa:</label>
      <input type="text" class="utn-rect-input" id="configFechaExamen" placeholder="Ej: 18/8">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Tema de examen actual:</label>
      <input type="text" class="utn-rect-input" id="configTemaExamen" placeholder="Ej: Integrador Estructural.">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Comunicado de la cátedra:</label>
      <textarea class="utn-rect-input" id="configComunicadoProfesora" rows="3" placeholder="Escriba el comunicado que verá el curso."></textarea>
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label" for="configDriveUrl">Carpeta compartida de Google Drive:</label>
      <input type="url" class="utn-rect-input" id="configDriveUrl" placeholder="https://drive.google.com/drive/folders/...">
      <p class="drive-permission-note">La profesora deja las tareas aquí y los alumnos cargan sus resoluciones. Compartí la carpeta con las cuentas correspondientes; quienes tengan permiso de edición también podrían modificar archivos existentes.</p>
    </div>
    <div class="modal-footer-buttons" style="margin-top: 24px; justify-content: space-between;">
      <button class="utn-btn-rect-primary" onclick="guardarConfiguracionCatedra()">Guardar configuración</button>
      <button class="utn-btn-rect-secondary" onclick="restaurarConfiguracionPredeterminada()">Restablecer valores</button>
    </div>
  </div>
</div>

<!-- Modal 8: Crear Usuario Manualmente (Exclusivo Admin) -->
<div id="modalNuevoUsuario" class="modal-window-overlay">
  <div class="modal-rect-card" style="max-width: 480px;">
    <span class="modal-close-x" onclick="cerrarModal('modalNuevoUsuario')">&times;</span>
    <h3 class="modal-heading">CREAR USUARIO MANUALMENTE</h3>
    <p style="font-size: 0.85rem; color: #64748b; margin: 6px 0 16px 0;">Alta directa de profesores y personal para asignación de cursos.</p>
    <div class="utn-form-item">
      <label class="utn-form-label">Nombre Completo:</label>
      <input type="text" class="utn-rect-input" id="inputAdminUserNombre" placeholder="Ej: Prof. Andrea López">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Nombre de Usuario (Login):</label>
      <input type="text" class="utn-rect-input" id="inputAdminUserLogin" placeholder="Ej: alopez">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Correo Electrónico:</label>
      <input type="email" class="utn-rect-input" id="inputAdminUserEmail" placeholder="Ej: alopez@sema.edu.ar">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Contraseña Inicial:</label>
      <input type="password" class="utn-rect-input" id="inputAdminUserPass" minlength="12" maxlength="72" autocomplete="new-password" placeholder="Contraseña (12 a 72 caracteres)">
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label">Rol:</label>
      <select id="selectAdminUserRol" class="utn-rect-select" onchange="toggleSelectorCursoUsuario(this.value)">
        <option value="profesor">Profesor / Docente</option>
        <option value="admin">Administrador General</option>
        <option value="alumno">Alumno</option>
      </select>
    </div>
    <div class="utn-form-item" id="bloqueAsignarCursoUser">
      <label class="utn-form-label">Asignar Curso que Dictará:</label>
      <select id="selectAdminUserCurso" class="utn-rect-select">
        <option value="">-- Sin asignar por ahora --</option>
        <option value="2gao">2° 1ra GAO</option>
        <option value="2cstep">2° 1ra TEP</option>
      </select>
    </div>
    <div class="modal-footer-buttons" style="margin-top: 24px;">
      <button class="utn-btn-rect-primary" onclick="guardarUsuarioManualAdmin()">Crear Usuario</button>
      <button class="utn-btn-rect-cancel" onclick="cerrarModal('modalNuevoUsuario')">Cancelar</button>
    </div>
  </div>
</div>

<!-- Modal 9: Notificaciones / Mensajes del Sistema -->
<div id="modalMensaje" class="modal-window-overlay">
  <div class="modal-rect-card" style="max-width: 420px;">
    <span class="modal-close-x" onclick="cerrarModal('modalMensaje')">&times;</span>
    <h3 class="modal-heading" id="modalMensajeTitulo">Mensaje</h3>
    <p id="modalMensajeTexto" style="margin-top: 12px; color: #334155; line-height: 1.5;"></p>
    <div class="modal-footer-buttons" style="margin-top: 24px; justify-content: flex-end;">
      <button class="utn-btn-rect-primary" onclick="cerrarModal('modalMensaje')">Aceptar</button>
    </div>
  </div>
</div>

<!-- Modal 10: Confirmación de Acciones -->
<div id="modalConfirmacion" class="modal-window-overlay">
  <div class="modal-rect-card" style="max-width: 420px;">
    <span class="modal-close-x" onclick="cerrarModal('modalConfirmacion')">&times;</span>
    <h3 class="modal-heading" id="modalConfirmacionTitulo">Confirmar</h3>
    <p id="modalConfirmacionTexto" style="margin-top: 12px; color: #334155; line-height: 1.5;"></p>
    <div class="modal-footer-buttons" style="margin-top: 24px; justify-content: space-between;">
      <button class="utn-btn-rect-secondary" onclick="cerrarModal('modalConfirmacion')">Cancelar</button>
      <button class="utn-btn-rect-primary" id="modalConfirmacionAceptar">Confirmar</button>
    </div>
  </div>
</div>

<div id="modalReportarIncidencia" class="modal-window-overlay">
  <section class="modal-rect-card modal-support-card" role="dialog" aria-modal="true" aria-labelledby="incidenciaTitulo">
    <button type="button" class="modal-close-x" aria-label="Cerrar" onclick="cerrarModal('modalReportarIncidencia')">&times;</button>
    <h3 class="modal-heading" id="incidenciaTitulo">REPORTAR INCIDENCIA</h3>
    <p class="modal-help-text">El reporte será recibido por administración. Incluí qué estabas haciendo y qué ocurrió.</p>
    <div class="utn-form-item">
      <label class="utn-form-label" for="incidenciaCategoria">Tipo de problema</label>
      <select id="incidenciaCategoria" class="utn-rect-select">
        <option value="acceso">Inicio de sesión o acceso</option>
        <option value="contenidos">Ruta o materiales</option>
        <option value="alumnos">Registro de alumnos</option>
        <option value="calificaciones">Calificaciones u observaciones</option>
        <option value="calendario">Calendario</option>
        <option value="otro">Otro</option>
      </select>
    </div>
    <div class="utn-form-item">
      <label class="utn-form-label" for="incidenciaDescripcion">Descripción</label>
      <textarea id="incidenciaDescripcion" class="utn-rect-input support-message-input" minlength="10" maxlength="5000" rows="6" required placeholder="Describí el problema (10 a 5.000 caracteres)"></textarea>
    </div>
    <p id="incidenciaEstado" class="support-form-status" role="status" aria-live="polite"></p>
    <div class="modal-footer-buttons">
      <button type="button" class="utn-btn-rect-secondary" onclick="cerrarModal('modalReportarIncidencia')">Cancelar</button>
      <button type="button" class="utn-btn-rect-primary" id="btnEnviarIncidencia" onclick="enviarIncidencia()">Enviar reporte</button>
    </div>
  </section>
</div>

<div id="modalManualProfesor" class="modal-window-overlay">
  <section class="modal-rect-card modal-teacher-manual" role="dialog" aria-modal="true" aria-labelledby="manualProfesorTitulo">
    <button type="button" class="modal-close-x" aria-label="Cerrar manual" onclick="cerrarModal('modalManualProfesor')">&times;</button>
    <h3 class="modal-heading" id="manualProfesorTitulo">MANUAL DEL PROFESOR</h3>
    <p class="modal-help-text">Guía rápida para gestionar el curso desde SEMA.</p>
    <div class="teacher-manual-content">
      <section>
        <h4>Inicio</h4>
        <p>Consultá el curso asignado, los avisos, la próxima evaluación y el acceso a la carpeta de Drive.</p>
      </section>
      <section>
        <h4>Ruta de aprendizaje</h4>
        <p>Revisá las unidades y cápsulas. Podés añadir unidades, adjuntar teoría, videos y ejercicios, y marcar cuándo se dieron en clase.</p>
      </section>
      <section>
        <h4>Registro de alumnos</h4>
        <p>Seleccioná una fila para editar la ficha, actualizar nota y condición, agregar observaciones del aula o registrar una baja. Los cambios se guardan en la base.</p>
      </section>
      <section>
        <h4>Importar alumnos</h4>
        <p>Usá un CSV con nombre completo, DNI y correo opcional. Revisá los duplicados y el padrón antes de confirmar la importación.</p>
      </section>
      <section>
        <h4>Calendario y configuración</h4>
        <p>Seleccioná un día para planificar o editar eventos. En Ajustes de cátedra podés actualizar el examen, el comunicado y el enlace de Drive.</p>
      </section>
      <section>
        <h4>Incidencias</h4>
        <p>Desde el pie de página, enviá un reporte con la categoría y una descripción clara del problema. Administración lo recibe en su panel.</p>
      </section>
    </div>
    <div class="modal-footer-buttons">
      <button type="button" class="utn-btn-rect-primary" onclick="cerrarModal('modalManualProfesor')">Cerrar manual</button>
    </div>
  </section>
</div>
