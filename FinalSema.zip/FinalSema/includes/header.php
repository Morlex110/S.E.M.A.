<?php
/**
 * Header HTML SEMA
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Sistema SEMA - Gestión y Planificación Áulica</title>
  <link rel="stylesheet" href="style.css?v=<?= file_exists(__DIR__ . '/../style.css') ? filemtime(__DIR__ . '/../style.css') : time() ?>" />
</head>
<body>
