<?php
/**
 * Manejo de Sesión y Autenticación con Roles SEMA
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/privacy.php';

function iniciarSesionSegura(): void {
    if (session_status() === PHP_SESSION_NONE) {
        $nombreSesion = semaEnv('SESSION_NAME', 'SEMASESSID');
        if (!preg_match('/^[A-Za-z][A-Za-z0-9_-]{0,63}$/', $nombreSesion ?? '')) {
            $nombreSesion = 'SEMASESSID';
        }
        session_name($nombreSesion);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        $conexionSegura = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off')
            || (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;

        // Asegurar configuración de cookie de sesión
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => semaEnv('SESSION_COOKIE_PATH', '/') ?: '/',
            'secure' => semaEnvBool('SESSION_SECURE', $conexionSegura),
            'httponly' => true,
            'samesite' => 'Lax'
        ]);
        session_start();
    }
}

function estaAutenticado(): bool {
    return obtenerUsuarioActual() !== null;
}

function obtenerUsuarioActual(): ?array {
    iniciarSesionSegura();
    $usuarioSesion = $_SESSION['usuario'] ?? null;
    if (!is_array($usuarioSesion) || empty($usuarioSesion['id'])) {
        return null;
    }

    static $usuarioActualizado = false;
    static $usuarioCache = null;
    if ($usuarioActualizado) return $usuarioCache;
    $usuarioActualizado = true;

    $stmt = getPDO()->prepare('SELECT id, username, email, nombre_completo, rol, activo FROM usuarios WHERE id = ? LIMIT 1');
    $stmt->execute([(int)$usuarioSesion['id']]);
    $usuarioDb = $stmt->fetch();
    if (!$usuarioDb || !(int)$usuarioDb['activo']) {
        unset($_SESSION['usuario']);
        return null;
    }

    $usuarioCache = [
        'id' => (int)$usuarioDb['id'],
        'username' => $usuarioDb['username'],
        'email' => $usuarioDb['email'],
        'nombre_completo' => $usuarioDb['nombre_completo'],
        'rol' => $usuarioDb['rol']
    ];
    $_SESSION['usuario'] = $usuarioCache;
    return $usuarioCache;
}

function esAdmin(): bool {
    $u = obtenerUsuarioActual();
    return $u !== null && ($u['rol'] ?? '') === 'admin';
}

function esProfesor(): bool {
    $u = obtenerUsuarioActual();
    return $u !== null && ($u['rol'] ?? '') === 'profesor';
}

function esAlumno(): bool {
    $u = obtenerUsuarioActual();
    return $u !== null && ($u['rol'] ?? '') === 'alumno';
}

function requerirDocenteOAdmin(): void {
    requerirAutenticacion();
    if (!esAdmin() && !esProfesor()) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        echo json_encode(['error' => 'Acceso denegado. Se requieren privilegios docentes.']);
        exit;
    }
}

function puedeGestionarCurso(PDO $pdo, string $cursoId, array $usuario): bool {
    if (($usuario['rol'] ?? '') === 'admin') {
        return true;
    }
    if (($usuario['rol'] ?? '') !== 'profesor' || empty($usuario['id'])) {
        return false;
    }
    $stmt = $pdo->prepare('SELECT 1 FROM cursos WHERE id = ? AND profesor_id = ? LIMIT 1');
    $stmt->execute([$cursoId, (int)$usuario['id']]);
    return (bool)$stmt->fetchColumn();
}

function requerirAutenticacion(): void {
    if (obtenerUsuarioActual() === null) {
        header('Content-Type: application/json');
        http_response_code(401);
        echo json_encode(['error' => 'No autorizado. Debe iniciar sesión.']);
        exit;
    }
}

function requerirAdmin(): void {
    requerirAutenticacion();
    if (!esAdmin()) {
        header('Content-Type: application/json');
        http_response_code(403);
        echo json_encode(['error' => 'Acceso denegado. Se requieren privilegios de Administrador General.']);
        exit;
    }
}

function registrarLogAcceso(PDO $pdo, ?int $usuarioId, string $username, string $rol, bool $exitoso): void {
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $userAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Desconocido', 0, 255);
        $stmt = $pdo->prepare("
            INSERT INTO logs_acceso (usuario_id, username, rol, ip, user_agent, exitoso)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$usuarioId, $username, $rol, $ip, $userAgent, $exitoso ? 1 : 0]);
    } catch (Exception $e) {
        error_log("Error registrando log de acceso: " . $e->getMessage());
    }
}
