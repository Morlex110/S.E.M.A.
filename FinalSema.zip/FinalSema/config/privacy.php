<?php
require_once __DIR__ . '/env.php';

if (!defined('SEMA_TERMS_VERSION')) {
	define('SEMA_TERMS_VERSION', semaEnv('SEMA_TERMS_VERSION', '1.0'));
}