<?php
/**
 * Configuración de Base de Datos y Auto-Instalador SEMA
 */

require_once __DIR__ . '/env.php';

define('DB_HOST', semaEnv('DB_HOST', '127.0.0.1'));
define('DB_PORT', semaEnv('DB_PORT', '3306'));
define('DB_USER', semaEnv('DB_USER', 'root'));
define('DB_PASS', semaEnv('DB_PASS', ''));
define('DB_NAME', semaEnv('DB_NAME', 'sema_db'));
define('DB_AUTO_CREATE', semaEnvBool('DB_AUTO_CREATE', SEMA_ENV !== 'production'));
define('DB_AUTO_MIGRATE', semaEnvBool('DB_AUTO_MIGRATE', SEMA_ENV !== 'production'));

if (!preg_match('/^[a-zA-Z0-9_]+$/', DB_NAME) || !ctype_digit(DB_PORT) || (int)DB_PORT < 1 || (int)DB_PORT > 65535) {
    throw new RuntimeException('La configuración de base de datos no es válida.');
}
if (SEMA_ENV === 'production' && (strtolower(DB_USER) === 'root' || DB_PASS === '')) {
    throw new RuntimeException('En producción se requiere un usuario MySQL exclusivo y una contraseña.');
}
if (SEMA_ENV === 'production' && (DB_AUTO_CREATE || DB_AUTO_MIGRATE)) {
    throw new RuntimeException('En producción DB_AUTO_CREATE y DB_AUTO_MIGRATE deben estar desactivados.');
}

function getPDO(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    try {
        $opciones = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        if (DB_AUTO_CREATE) {
            $pdoInit = new PDO(
                'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                $opciones
            );
            $pdoInit->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        }

        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            $opciones
        );

        if (DB_AUTO_MIGRATE) {
            inicializarBaseDeDatos($pdo);
        }

        return $pdo;
    } catch (PDOException $e) {
        error_log('SEMA database connection failed: ' . $e->getMessage());
        throw new RuntimeException('No se pudo conectar con la base de datos.', 0, $e);
    }
}

function inicializarBaseDeDatos(PDO $pdo): void {
    // 1. Crear tablas si no existen
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            Fecha_de_Nacimiento DATE NULL,
            nombre_completo VARCHAR(120) NOT NULL,
            rol ENUM('admin', 'profesor', 'alumno') NOT NULL DEFAULT 'alumno',
            orden INT DEFAULT 0,
            activo TINYINT(1) DEFAULT 1,
            terms_accepted_at DATETIME NULL,
            terms_version VARCHAR(20) NULL,
            creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS cursos (
            id VARCHAR(20) PRIMARY KEY,
            titulo VARCHAR(150) NOT NULL,
            materias VARCHAR(150) NOT NULL,
            profesor_id INT NULL,
            proximo_examen VARCHAR(50) DEFAULT NULL,
            tema_examen TEXT DEFAULT NULL,
            comunicado_profesora TEXT DEFAULT NULL,
            solicitud_acceso VARCHAR(255) DEFAULT NULL,
            drive_url VARCHAR(1000) DEFAULT NULL,
            orden INT DEFAULT 0,
            FOREIGN KEY (profesor_id) REFERENCES usuarios(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS unidades (
            id INT AUTO_INCREMENT PRIMARY KEY,
            curso_id VARCHAR(20) NOT NULL,
            nombre VARCHAR(200) NOT NULL,
            orden INT DEFAULT 0,
            FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS capsulas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            unidad_id INT NOT NULL,
            tipo ENUM('T', 'V', 'E') NOT NULL,
            texto TEXT NOT NULL,
            url VARCHAR(500) DEFAULT NULL,
            archivo VARCHAR(255) DEFAULT NULL,
            orden INT DEFAULT 0,
            dictada TINYINT(1) NOT NULL DEFAULT 0,
            FOREIGN KEY (unidad_id) REFERENCES unidades(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS alumnos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NULL UNIQUE,
            curso_id VARCHAR(20) NOT NULL,
            n_orden INT NOT NULL,
            corto VARCHAR(50) NOT NULL,
            completo VARCHAR(150) NOT NULL,
            dni VARCHAR(20) NULL,
            email VARCHAR(100) NOT NULL,
            Fecha_de_Nacimiento DATE NULL,
            observaciones_docente TEXT NULL,
            nota DECIMAL(4,2) DEFAULT 0.00,
            condicion ENUM('Regular', 'Desaprobado', 'Bien') DEFAULT 'Regular',
            progreso INT DEFAULT 0,
            activo TINYINT(1) DEFAULT 1,
            fecha_baja DATETIME DEFAULT NULL,
            motivo_baja VARCHAR(255) DEFAULT NULL,
            FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS eventos_calendario (
            id INT AUTO_INCREMENT PRIMARY KEY,
            curso_id VARCHAR(20) NULL,
            fecha DATE NOT NULL,
            titulo VARCHAR(150) NOT NULL,
            descripcion TEXT,
            tipo VARCHAR(50) DEFAULT 'ev-repaso',
            clase VARCHAR(50) DEFAULT 'event-12',
            UNIQUE KEY uq_evento_curso_fecha (curso_id, fecha),
            FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS logs_acceso (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NULL,
            username VARCHAR(50) NOT NULL,
            rol VARCHAR(20) NOT NULL,
            ip VARCHAR(45) NOT NULL,
            user_agent TEXT,
            fecha_ingreso TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            exitoso TINYINT(1) DEFAULT 1,
            INDEX idx_logs_usuario_ip (username, ip, exitoso, fecha_ingreso),
            INDEX idx_logs_ip (ip, exitoso, fecha_ingreso),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

        CREATE TABLE IF NOT EXISTS entregas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            alumno_id INT NOT NULL,
            capsula_id INT NOT NULL,
            enlace_drive VARCHAR(1000) NOT NULL,
            comentario TEXT NULL,
            estado ENUM('pendiente', 'visto') NOT NULL DEFAULT 'pendiente',
            entregada_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_entrega_alumno_capsula (alumno_id, capsula_id),
            FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE,
            FOREIGN KEY (capsula_id) REFERENCES capsulas(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS incidencias (
            id INT AUTO_INCREMENT PRIMARY KEY,
            usuario_id INT NULL,
            usuario_nombre VARCHAR(120) NOT NULL,
            usuario_email VARCHAR(100) NOT NULL,
            rol VARCHAR(20) NOT NULL,
            categoria VARCHAR(40) NOT NULL,
            descripcion TEXT NOT NULL,
            estado ENUM('abierta', 'en_revision', 'resuelta') NOT NULL DEFAULT 'abierta',
            creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_incidencias_estado_fecha (estado, creado_en),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");

    // Migraciones idempotentes para instalaciones que ya tenían las tablas.
    $colFechaUsuario = $pdo->query("SHOW COLUMNS FROM usuarios LIKE 'Fecha_de_Nacimiento'")->fetch();
    if (!$colFechaUsuario) {
        $pdo->exec('ALTER TABLE usuarios ADD COLUMN Fecha_de_Nacimiento DATE NULL');
    } elseif ($colFechaUsuario['Null'] === 'NO') {
        $pdo->exec('ALTER TABLE usuarios MODIFY Fecha_de_Nacimiento DATE NULL');
    }

    $colFechaAlumno = $pdo->query("SHOW COLUMNS FROM alumnos LIKE 'Fecha_de_Nacimiento'")->fetch();
    if (!$colFechaAlumno) {
        $pdo->exec('ALTER TABLE alumnos ADD COLUMN Fecha_de_Nacimiento DATE NULL');
    } elseif ($colFechaAlumno['Null'] === 'NO') {
        $pdo->exec('ALTER TABLE alumnos MODIFY Fecha_de_Nacimiento DATE NULL');
    }

    $colObservacionesDocente = $pdo->query("SHOW COLUMNS FROM alumnos LIKE 'observaciones_docente'")->fetch();
    if (!$colObservacionesDocente) {
        $pdo->exec('ALTER TABLE alumnos ADD COLUMN observaciones_docente TEXT NULL');
    }
    $columnasAlumnos = $pdo->query('SHOW COLUMNS FROM alumnos')->fetchAll(PDO::FETCH_COLUMN);
    foreach (['anio_ingreso_aula', 'anio_de_ingreso_aula'] as $columnaAnioAula) {
        if (in_array($columnaAnioAula, $columnasAlumnos, true)) {
            $pdo->exec('ALTER TABLE alumnos DROP COLUMN `' . $columnaAnioAula . '`');
        }
    }

    $colDriveUrl = $pdo->query("SHOW COLUMNS FROM cursos LIKE 'drive_url'")->fetch();
    if (!$colDriveUrl) {
        $pdo->exec('ALTER TABLE cursos ADD COLUMN drive_url VARCHAR(1000) NULL');
    }

    $colTermsAcceptedAt = $pdo->query("SHOW COLUMNS FROM usuarios LIKE 'terms_accepted_at'")->fetch();
    if (!$colTermsAcceptedAt) {
        $pdo->exec('ALTER TABLE usuarios ADD COLUMN terms_accepted_at DATETIME NULL');
    }
    $colTermsVersion = $pdo->query("SHOW COLUMNS FROM usuarios LIKE 'terms_version'")->fetch();
    if (!$colTermsVersion) {
        $pdo->exec('ALTER TABLE usuarios ADD COLUMN terms_version VARCHAR(20) NULL');
    }

    $colUsuarioRol = $pdo->query("SHOW COLUMNS FROM usuarios LIKE 'rol'")->fetch();
    if ($colUsuarioRol && $colUsuarioRol['Default'] !== 'alumno') {
        $pdo->exec("ALTER TABLE usuarios MODIFY rol ENUM('admin', 'profesor', 'alumno') NOT NULL DEFAULT 'alumno'");
    }

    $colAlumnoUsuario = $pdo->query("SHOW COLUMNS FROM alumnos LIKE 'usuario_id'")->fetch();
    if (!$colAlumnoUsuario) {
        $pdo->exec("ALTER TABLE alumnos ADD COLUMN usuario_id INT NULL UNIQUE, ADD CONSTRAINT fk_alumnos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL");
    }

    $colAlumnoDni = $pdo->query("SHOW COLUMNS FROM alumnos LIKE 'dni'")->fetch();
    if (!$colAlumnoDni) {
        $pdo->exec('ALTER TABLE alumnos ADD COLUMN dni VARCHAR(20) NULL');
    }
    $indiceAlumnoDni = $pdo->query("SHOW INDEX FROM alumnos WHERE Key_name = 'uq_alumnos_dni'")->fetch();
    if (!$indiceAlumnoDni) {
        $pdo->exec('ALTER TABLE alumnos ADD UNIQUE KEY uq_alumnos_dni (dni)');
    }

    $colEntregaEstado = $pdo->query("SHOW COLUMNS FROM entregas LIKE 'estado'")->fetch();
    if (!$colEntregaEstado) {
        $pdo->exec("ALTER TABLE entregas ADD COLUMN estado ENUM('pendiente', 'visto') NOT NULL DEFAULT 'pendiente'");
    }
    $colEntregaFecha = $pdo->query("SHOW COLUMNS FROM entregas LIKE 'entregada_en'")->fetch();
    if ($colEntregaFecha && stripos((string)($colEntregaFecha['Extra'] ?? ''), 'on update') !== false) {
        $pdo->exec('ALTER TABLE entregas MODIFY entregada_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP');
    }

    $colCapsulaDictada = $pdo->query("SHOW COLUMNS FROM capsulas LIKE 'dictada'")->fetch();
    if (!$colCapsulaDictada) {
        $pdo->exec("ALTER TABLE capsulas ADD COLUMN dictada TINYINT(1) NOT NULL DEFAULT 0");
    }

    $colEventoCurso = $pdo->query("SHOW COLUMNS FROM eventos_calendario LIKE 'curso_id'")->fetch();
    if (!$colEventoCurso) {
        $pdo->exec("ALTER TABLE eventos_calendario ADD COLUMN curso_id VARCHAR(20) NULL, ADD CONSTRAINT fk_eventos_curso FOREIGN KEY (curso_id) REFERENCES cursos(id) ON DELETE CASCADE");
    }
    $indicesEventos = $pdo->query('SHOW INDEX FROM eventos_calendario')->fetchAll();
    $indicesPorNombre = [];
    foreach ($indicesEventos as $indice) {
        $indicesPorNombre[$indice['Key_name']][] = $indice;
    }
    foreach ($indicesPorNombre as $nombreIndice => $columnasIndice) {
        if ($nombreIndice === 'PRIMARY' || $nombreIndice === 'uq_evento_curso_fecha') continue;
        usort($columnasIndice, function($a, $b) { return (int)$a['Seq_in_index'] <=> (int)$b['Seq_in_index']; });
        if (count($columnasIndice) === 1 && $columnasIndice[0]['Column_name'] === 'fecha' && (int)$columnasIndice[0]['Non_unique'] === 0 && preg_match('/^[a-zA-Z0-9_]+$/', $nombreIndice)) {
            $pdo->exec('ALTER TABLE eventos_calendario DROP INDEX `' . $nombreIndice . '`');
        }
    }
    $indiceEventoCurso = $pdo->query("SHOW INDEX FROM eventos_calendario WHERE Key_name = 'uq_evento_curso_fecha'")->fetch();
    if (!$indiceEventoCurso) {
        $pdo->exec('ALTER TABLE eventos_calendario ADD UNIQUE KEY uq_evento_curso_fecha (curso_id, fecha)');
    }

    $indicesLogs = $pdo->query('SHOW INDEX FROM logs_acceso')->fetchAll(PDO::FETCH_COLUMN, 2);
    if (!in_array('idx_logs_usuario_ip', $indicesLogs, true)) {
        $pdo->exec('ALTER TABLE logs_acceso ADD INDEX idx_logs_usuario_ip (username, ip, exitoso, fecha_ingreso)');
    }
    if (!in_array('idx_logs_ip', $indicesLogs, true)) {
        $pdo->exec('ALTER TABLE logs_acceso ADD INDEX idx_logs_ip (ip, exitoso, fecha_ingreso)');
    }

    $nombresDocentes = [
        ['docente', 'Prof. Franco (GAO)'],
        ['docente_cstep', 'Prof. Jovanovich (TEP)'],
        ['docente_cb', 'Prof. Sallinas (CB)'],
    ];
    $actualizarNombreDocente = $pdo->prepare("UPDATE usuarios SET nombre_completo = ? WHERE username = ? AND rol = 'profesor' AND nombre_completo <> ?");
    foreach ($nombresDocentes as [$usernameDocente, $nombreDocente]) {
        $actualizarNombreDocente->execute([$nombreDocente, $usernameDocente, $nombreDocente]);
    }
    $actualizarNombrePorCurso = $pdo->prepare("UPDATE usuarios u JOIN cursos c ON c.profesor_id = u.id SET u.nombre_completo = ? WHERE u.rol = 'profesor' AND c.id = ? AND u.nombre_completo <> ?");
    $actualizarNombrePorCurso->execute(['Prof. Franco (GAO)', '2gao', 'Prof. Franco (GAO)']);
    $actualizarNombrePorCurso->execute(['Prof. Jovanovich (TEP)', '2cstep', 'Prof. Jovanovich (TEP)']);
    $actualizarNombreCB = $pdo->prepare("UPDATE usuarios u JOIN cursos c ON c.profesor_id = u.id SET u.nombre_completo = 'Prof. Sallinas (CB)' WHERE u.rol = 'profesor' AND (LOWER(c.id) LIKE '%cb%' OR LOWER(c.titulo) LIKE '%cb%') AND u.nombre_completo <> 'Prof. Sallinas (CB)'");
    $actualizarNombreCB->execute();
    $pdo->exec("UPDATE cursos SET titulo = REPLACE(titulo, 'CSTEP', 'TEP') WHERE id = '2cstep' AND titulo LIKE '%CSTEP%'");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS progreso_capsulas (
            alumno_id INT NOT NULL,
            capsula_id INT NOT NULL,
            completada TINYINT(1) NOT NULL DEFAULT 0,
            completada_en DATETIME NULL,
            PRIMARY KEY (alumno_id, capsula_id),
            FOREIGN KEY (alumno_id) REFERENCES alumnos(id) ON DELETE CASCADE,
            FOREIGN KEY (capsula_id) REFERENCES capsulas(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    ");

    // 2. Verificar si ya existen usuarios; si no existen, inicializar datos semilla
    $checkUsers = $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
    if ($checkUsers == 0) {
        sembrarDatosIniciales($pdo);
    }

    actualizarCredencialesSemilla($pdo);
    asegurarRutaCicloBasico($pdo);
    migrarRecursosCicloBasico($pdo);
}

function asegurarRutaCicloBasico(PDO $pdo): void {
    $cursoId = 'cb';
    $unidades = [
        [
            'Números y Operaciones',
            [
                ['tipo' => 'T', 'texto' => 'Números naturales, enteros (ℤ) y racionales (fracciones y decimales); operaciones básicas, propiedades, potenciación, radicación, divisibilidad, múltiplos, divisores, m.c.m. y m.c.d. Módulo 1 de Matemática BNM.', 'url' => 'https://bnm.educacion.gob.ar/digital/documentos/EL004341.pdf'],
                ['tipo' => 'V', 'texto' => 'Números: naturales, enteros y racionales (Educ.ar).', 'url' => 'https://www.educ.ar/recursos/105775/numeros'],
                ['tipo' => 'E', 'texto' => 'Cuadernillo de Números Enteros (INET).', 'url' => 'https://www.inet.edu.ar/wp-content/uploads/2020/05/01-01_Nu--meros-enteros.pdf'],
                ['tipo' => 'E', 'texto' => 'Guía de Números Enteros: problemas de la vida cotidiana, Escuelas Faro Córdoba.', 'url' => 'https://www.igualdadycalidadcba.gov.ar/SIPEC-CBA/publicaciones/PNFP/Eje1/EscuelasFARO/2019/PropEns/MatematicaSecundaria-Resolviendoproblemasconn%C3%BAmerosenteros.pdf']
            ]
        ],
        [
            'Álgebra y Funciones',
            [
                ['tipo' => 'T', 'texto' => 'Lenguaje coloquial y simbólico; ecuaciones lineales de primer grado con una incógnita. Iniciación al Álgebra (Educ.ar).', 'url' => 'https://www.educ.ar/dinamico/UnidadHtml__get__81dfd9c0-7a08-11e1-810f-ed15e3c494af/matematica-algebra1.pdf'],
                ['tipo' => 'T', 'texto' => 'Introducción al concepto de función, gráficos cartesianos y función lineal. Matemática: Funciones (Educ.ar).', 'url' => 'https://www.educ.ar/dinamico/UnidadHtml__get__81dfd9c0-7a08-11e1-810f-ed15e3c494af/matematica-funciones.pdf'],
                ['tipo' => 'V', 'texto' => 'Videos de Educ.ar sobre ecuaciones de primer grado.', 'url' => 'https://www.educ.ar/buscador?query=ecuaciones%20primer%20grado%20video'],
                ['tipo' => 'E', 'texto' => 'Proporcionalidad directa e inversa, porcentaje y regla de tres. Lo Proporcional, Parte 2.', 'url' => 'https://www.igualdadycalidadcba.gov.ar/SIPEC-CBA/Programas/2022/Matematica/Docs/lo-proporcional-parte-2.pdf'],
                ['tipo' => 'E', 'texto' => 'Módulo 3 de Álgebra BNM, con claves de corrección.', 'url' => 'https://bnm.educacion.gob.ar/digital/documentos/EL004343.pdf']
            ]
        ],
        [
            'Geometría y Medida',
            [
                ['tipo' => 'T', 'texto' => 'Clasificación de ángulos y triángulos, suma de ángulos interiores, paralelismo y perpendicularidad. Clase 1 del Módulo III (Entre Ríos Aprende).', 'url' => 'https://aprender.entrerios.edu.ar/wp-content/uploads/2020/04/Clase-1.-M%C3%B3dulo-3.-Matem%C3%A1tica.pdf'],
                ['tipo' => 'V', 'texto' => 'Videos y recursos audiovisuales de Educ.ar sobre el Teorema de Pitágoras.', 'url' => 'https://www.educ.ar/buscador?query=teorema%20de%20Pit%C3%A1goras%20video'],
                ['tipo' => 'E', 'texto' => 'Teorema de Pitágoras, Parte I: situaciones problemáticas de aplicación.', 'url' => 'https://hacemosescuela.cba.gov.ar/wp-content/uploads/2023/08/secundaria-matematica-teoremadepitagoras.pdf'],
                ['tipo' => 'E', 'texto' => 'Teorema de Pitágoras, Parte II (Hacemos Escuela).', 'url' => 'https://hacemosescuela.cba.gov.ar/wp-content/uploads/2023/07/secundaria-matematica-teoremadepitagoras2.pdf']
            ]
        ]
    ];

    $pdo->beginTransaction();
    try {
        $cursoStmt = $pdo->prepare('SELECT id FROM cursos WHERE id = ? FOR UPDATE');
        $cursoStmt->execute([$cursoId]);
        if (!$cursoStmt->fetchColumn()) {
            $pdo->commit();
            return;
        }

        $unidadesStmt = $pdo->prepare('SELECT COUNT(*) FROM unidades WHERE curso_id = ?');
        $unidadesStmt->execute([$cursoId]);
        if ((int)$unidadesStmt->fetchColumn() > 0) {
            $pdo->commit();
            return;
        }

        $ordenStmt = $pdo->prepare('SELECT COALESCE(MAX(orden), 0) + 1 FROM unidades WHERE curso_id = ?');
        $ordenStmt->execute([$cursoId]);
        $ordenUnidad = (int)$ordenStmt->fetchColumn();
        $insertUnidad = $pdo->prepare('INSERT INTO unidades (curso_id, nombre, orden) VALUES (?, ?, ?)');
        $insertCapsula = $pdo->prepare('INSERT INTO capsulas (unidad_id, tipo, texto, url, archivo, orden) VALUES (?, ?, ?, ?, NULL, ?)');

        foreach ($unidades as [$nombreUnidad, $temas]) {
            $insertUnidad->execute([$cursoId, $nombreUnidad, $ordenUnidad++]);
            $unidadId = (int)$pdo->lastInsertId();
            foreach ($temas as $indice => $recurso) {
                $insertCapsula->execute([$unidadId, $recurso['tipo'], $recurso['texto'], $recurso['url'], $indice + 1]);
            }
        }

        $pdo->commit();
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $error;
    }
}

function migrarRecursosCicloBasico(PDO $pdo): void {
    $estadoStmt = $pdo->query("SELECT COUNT(*) total, SUM(cap.tipo = 'T' AND cap.url IS NULL) legado FROM capsulas cap JOIN unidades u ON u.id = cap.unidad_id WHERE u.curso_id = 'cb'");
    $estado = $estadoStmt->fetch();
    if ((int)($estado['total'] ?? 0) !== 10 || (int)($estado['legado'] ?? 0) !== 10) return;

    $recursosPorUnidad = [
        'Números y Operaciones' => [
            ['T', 'Números naturales, enteros (ℤ) y racionales (fracciones y decimales); operaciones básicas, propiedades, potenciación, radicación, divisibilidad, múltiplos, divisores, m.c.m. y m.c.d. Módulo 1 de Matemática BNM.', 'https://bnm.educacion.gob.ar/digital/documentos/EL004341.pdf'],
            ['V', 'Números: naturales, enteros y racionales (Educ.ar).', 'https://www.educ.ar/recursos/105775/numeros'],
            ['E', 'Cuadernillo de Números Enteros (INET).', 'https://www.inet.edu.ar/wp-content/uploads/2020/05/01-01_Nu--meros-enteros.pdf'],
            ['E', 'Guía de Números Enteros: problemas de la vida cotidiana, Escuelas Faro Córdoba.', 'https://www.igualdadycalidadcba.gov.ar/SIPEC-CBA/publicaciones/PNFP/Eje1/EscuelasFARO/2019/PropEns/MatematicaSecundaria-Resolviendoproblemasconn%C3%BAmerosenteros.pdf']
        ],
        'Álgebra y Funciones' => [
            ['T', 'Lenguaje coloquial y simbólico; ecuaciones lineales de primer grado con una incógnita. Iniciación al Álgebra (Educ.ar).', 'https://www.educ.ar/dinamico/UnidadHtml__get__81dfd9c0-7a08-11e1-810f-ed15e3c494af/matematica-algebra1.pdf'],
            ['T', 'Introducción al concepto de función, gráficos cartesianos y función lineal. Matemática: Funciones (Educ.ar).', 'https://www.educ.ar/dinamico/UnidadHtml__get__81dfd9c0-7a08-11e1-810f-ed15e3c494af/matematica-funciones.pdf'],
            ['V', 'Videos de Educ.ar sobre ecuaciones de primer grado.', 'https://www.educ.ar/buscador?query=ecuaciones%20primer%20grado%20video'],
            ['E', 'Proporcionalidad directa e inversa, porcentaje y regla de tres. Lo Proporcional, Parte 2.', 'https://www.igualdadycalidadcba.gov.ar/SIPEC-CBA/Programas/2022/Matematica/Docs/lo-proporcional-parte-2.pdf'],
            ['E', 'Módulo 3 de Álgebra BNM, con claves de corrección.', 'https://bnm.educacion.gob.ar/digital/documentos/EL004343.pdf']
        ],
        'Geometría y Medida' => [
            ['T', 'Clasificación de ángulos y triángulos, suma de ángulos interiores, paralelismo y perpendicularidad. Clase 1 del Módulo III (Entre Ríos Aprende).', 'https://aprender.entrerios.edu.ar/wp-content/uploads/2020/04/Clase-1.-M%C3%B3dulo-3.-Matem%C3%A1tica.pdf'],
            ['V', 'Videos y recursos audiovisuales de Educ.ar sobre el Teorema de Pitágoras.', 'https://www.educ.ar/buscador?query=teorema%20de%20Pit%C3%A1goras%20video'],
            ['E', 'Teorema de Pitágoras, Parte I: situaciones problemáticas de aplicación.', 'https://hacemosescuela.cba.gov.ar/wp-content/uploads/2023/08/secundaria-matematica-teoremadepitagoras.pdf'],
            ['E', 'Teorema de Pitágoras, Parte II (Hacemos Escuela).', 'https://hacemosescuela.cba.gov.ar/wp-content/uploads/2023/07/secundaria-matematica-teoremadepitagoras2.pdf']
        ]
    ];

    $pdo->beginTransaction();
    try {
        $unidadStmt = $pdo->prepare('SELECT id FROM unidades WHERE curso_id = ? AND nombre = ? LIMIT 1');
        $capsulasStmt = $pdo->prepare('SELECT id FROM capsulas WHERE unidad_id = ? ORDER BY orden, id');
        $updateStmt = $pdo->prepare('UPDATE capsulas SET tipo = ?, texto = ?, url = ?, archivo = NULL, orden = ? WHERE id = ?');
        $insertStmt = $pdo->prepare('INSERT INTO capsulas (unidad_id, tipo, texto, url, archivo, orden) VALUES (?, ?, ?, ?, NULL, ?)');

        foreach ($recursosPorUnidad as $nombreUnidad => $recursos) {
            $unidadStmt->execute(['cb', $nombreUnidad]);
            $unidadId = (int)$unidadStmt->fetchColumn();
            if (!$unidadId) continue;

            $capsulasStmt->execute([$unidadId]);
            $capsulasExistentes = $capsulasStmt->fetchAll(PDO::FETCH_COLUMN);
            foreach ($recursos as $indice => [$tipo, $texto, $url]) {
                $orden = $indice + 1;
                if (isset($capsulasExistentes[$indice])) {
                    $updateStmt->execute([$tipo, $texto, $url, $orden, (int)$capsulasExistentes[$indice]]);
                } else {
                    $insertStmt->execute([$unidadId, $tipo, $texto, $url, $orden]);
                }
            }
        }

        $pdo->commit();
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $error;
    }
}

function actualizarCredencialesSemilla(PDO $pdo): void {
    if (SEMA_ENV !== 'production') return;

    $cuentas = [
        ['admin', 'admin1234', 'SEMA_SEED_ADMIN_PASSWORD'],
        ['docente', '1234', 'SEMA_SEED_TEACHER_GAO_PASSWORD'],
        ['docente_cstep', '1234', 'SEMA_SEED_TEACHER_CSTEP_PASSWORD'],
    ];
    $buscar = $pdo->prepare('SELECT id, password_hash FROM usuarios WHERE username = ? LIMIT 1');
    $actualizar = $pdo->prepare('UPDATE usuarios SET password_hash = ? WHERE id = ?');

    foreach ($cuentas as [$username, $claveDemo, $variableEntorno]) {
        $buscar->execute([$username]);
        $usuario = $buscar->fetch();
        if (!$usuario || !password_verify($claveDemo, $usuario['password_hash'])) continue;

        $nuevaClave = semaEnv($variableEntorno, '');
        if (strlen($nuevaClave) < 16) {
            throw new RuntimeException('Configure en .env una clave nueva de al menos 16 caracteres para ' . $username . '.');
        }
        $actualizar->execute([password_hash($nuevaClave, PASSWORD_DEFAULT), (int)$usuario['id']]);
    }
}

function sembrarDatosIniciales(PDO $pdo): void {
    // A. Usuarios Base
    $passwords = [
        'admin' => semaEnv('SEMA_SEED_ADMIN_PASSWORD', ''),
        'docente' => semaEnv('SEMA_SEED_TEACHER_GAO_PASSWORD', ''),
        'docente_cstep' => semaEnv('SEMA_SEED_TEACHER_CSTEP_PASSWORD', ''),
    ];
    foreach ($passwords as $username => $password) {
        if (strlen($password) < 16) {
            throw new RuntimeException('Configure en .env una clave inicial distinta de al menos 16 caracteres para ' . $username . '.');
        }
    }
    $passAdmin = password_hash($passwords['admin'], PASSWORD_DEFAULT);
    $passDocenteGao = password_hash($passwords['docente'], PASSWORD_DEFAULT);
    $passDocenteCstep = password_hash($passwords['docente_cstep'], PASSWORD_DEFAULT);

    $stmtUser = $pdo->prepare("
        INSERT INTO usuarios (username, email, password_hash, nombre_completo, rol, orden)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    // Admin general
    $stmtUser->execute(['admin', 'admin@sema.edu.ar', $passAdmin, 'Administrador General SEMA', 'admin', 1]);
    $adminId = $pdo->lastInsertId();

    // Profesor GAO
    $stmtUser->execute(['docente', 'docente@sema.edu.ar', $passDocenteGao, 'Prof. Franco (GAO)', 'profesor', 2]);
    $docenteGaoId = $pdo->lastInsertId();

    // Profesor CSTEP
    $stmtUser->execute(['docente_cstep', 'profesor.tep@sema.edu.ar', $passDocenteCstep, 'Prof. Jovanovich (TEP)', 'profesor', 3]);
    $docenteTepId = $pdo->lastInsertId();

    // B. Cargar datos de data-gao.json y data-tep.json
    $baseDir = dirname(__DIR__);
    $fileGao = $baseDir . DIRECTORY_SEPARATOR . 'data-gao.json';
    $fileTep = $baseDir . DIRECTORY_SEPARATOR . 'data-tep.json';

    $dataGao = file_exists($fileGao) ? json_decode(file_get_contents($fileGao), true) : null;
    $dataTep = file_exists($fileTep) ? json_decode(file_get_contents($fileTep), true) : null;

    $cursosConfig = [
        '2gao' => ['data' => $dataGao, 'profesor_id' => $docenteGaoId, 'orden' => 1],
        '2cstep' => ['data' => $dataTep, 'profesor_id' => $docenteTepId, 'orden' => 2]
    ];

    $stmtCurso = $pdo->prepare("
        INSERT INTO cursos (id, titulo, materias, profesor_id, proximo_examen, tema_examen, comunicado_profesora, solicitud_acceso, orden)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmtUnidad = $pdo->prepare("INSERT INTO unidades (curso_id, nombre, orden) VALUES (?, ?, ?)");
    $stmtCapsula = $pdo->prepare("INSERT INTO capsulas (unidad_id, tipo, texto, url, archivo, orden) VALUES (?, ?, ?, ?, ?, ?)");
    $stmtAlumno = $pdo->prepare("INSERT INTO alumnos (curso_id, n_orden, corto, completo, email, nota, condicion, progreso, activo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)");

    foreach ($cursosConfig as $cursoId => $cfg) {
        $cData = $cfg['data']['courses'][$cursoId] ?? null;
        if (!$cData) continue;

        $stmtCurso->execute([
            $cursoId,
            $cData['titulo'] ?? "Curso {$cursoId}",
            $cData['materias'] ?? "Especialidad",
            $cfg['profesor_id'],
            $cData['proximoExamen'] ?? '18/8',
            $cData['temaExamen'] ?? 'Contenido integrador',
            $cData['comunicadoProfesora'] ?? 'Espacio docente para el seguimiento del aula y control de planificaciones.',
            $cData['solicitudAcceso'] ?? null,
            $cfg['orden']
        ]);

        // Unidades y cápsulas
        if (!empty($cData['unidades'])) {
            foreach ($cData['unidades'] as $idxU => $u) {
                $nombreUnidad = is_array($u) ? ($u['nombre'] ?? "Unidad " . ($idxU + 1)) : (string)$u;
                $stmtUnidad->execute([$cursoId, $nombreUnidad, $idxU + 1]);
                $unidadId = $pdo->lastInsertId();

                $tareas = is_array($u) && isset($u['tareas']) ? $u['tareas'] : [];
                foreach ($tareas as $idxT => $t) {
                    $tipo = $t['tipo'] ?? 'T';
                    $texto = $t['texto'] ?? ($t['nombre'] ?? 'Material');
                    $url = $t['url'] ?? null;
                    $archivo = $t['archivo'] ?? null;
                    $stmtCapsula->execute([$unidadId, $tipo, $texto, $url, $archivo, $idxT + 1]);
                }
            }
        }

        // Alumnos
        if (!empty($cData['alumnos'])) {
            foreach ($cData['alumnos'] as $al) {
                $n = $al['n'] ?? 1;
                $corto = $al['corto'] ?? 'Alumno';
                $completo = $al['completo'] ?? $corto;
                $email = $al['email'] ?? "alumno{$n}@sema.edu.ar";
                $nota = $al['nota'] ?? 0;
                $condicion = $al['condicion'] ?? 'Regular';
                $progreso = $al['progreso'] ?? min(100, (int)($nota * 10));

                $stmtAlumno->execute([
                    $cursoId, $n, $corto, $completo, $email, $nota, $condicion, $progreso
                ]);
            }
        }
    }

    // C. Eventos de Calendario
    $stmtEvento = $pdo->prepare("
        INSERT IGNORE INTO eventos_calendario (curso_id, fecha, titulo, descripcion, tipo, clase)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $calendariosPorCurso = [
        '2gao' => $dataGao['calendario'] ?? [],
        '2cstep' => $dataTep['calendario'] ?? []
    ];
    foreach ($calendariosPorCurso as $cursoId => $calendario) {
        foreach ($calendario as $fecha => $ev) {
            $stmtEvento->execute([
                $cursoId,
                $fecha,
                $ev['titulo'] ?? 'Evento Académico',
                $ev['desc'] ?? '',
                $ev['tipo'] ?? 'ev-repaso',
                $ev['clase'] ?? 'event-19'
            ]);
        }
    }

    // Registro inicial en logs de acceso
    $stmtLog = $pdo->prepare("
        INSERT INTO logs_acceso (usuario_id, username, rol, ip, user_agent, exitoso)
        VALUES (?, 'admin', 'admin', '127.0.0.1', 'Instalador Sistema SEMA', 1)
    ");
    $stmtLog->execute([$adminId]);
}
