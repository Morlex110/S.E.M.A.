<?php

$semaEnvFile = dirname(__DIR__) . DIRECTORY_SEPARATOR . '.env';
if (is_file($semaEnvFile) && is_readable($semaEnvFile)) {
    $semaEnvLines = file($semaEnvFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    foreach ($semaEnvLines as $semaEnvLine) {
        $semaEnvLine = trim($semaEnvLine);
        if ($semaEnvLine === '' || $semaEnvLine[0] === '#') continue;
        if (str_starts_with($semaEnvLine, 'export ')) $semaEnvLine = substr($semaEnvLine, 7);

        $semaEnvSeparator = strpos($semaEnvLine, '=');
        if ($semaEnvSeparator === false) continue;
        $semaEnvName = trim(substr($semaEnvLine, 0, $semaEnvSeparator));
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $semaEnvName) || getenv($semaEnvName) !== false) continue;

        $semaEnvValue = trim(substr($semaEnvLine, $semaEnvSeparator + 1));
        if (strlen($semaEnvValue) >= 2 && in_array($semaEnvValue[0], ['"', "'"], true) && $semaEnvValue[0] === substr($semaEnvValue, -1)) {
            $semaEnvQuote = $semaEnvValue[0];
            $semaEnvValue = substr($semaEnvValue, 1, -1);
            if ($semaEnvQuote === '"') {
                $semaEnvValue = str_replace(['\\n', '\\r', '\\"', '\\\\'], ["\n", "\r", '"', '\\'], $semaEnvValue);
            }
        } else {
            $semaEnvValue = preg_replace('/\s+#.*$/', '', $semaEnvValue) ?? $semaEnvValue;
        }

        putenv($semaEnvName . '=' . $semaEnvValue);
        $_ENV[$semaEnvName] = $semaEnvValue;
        $_SERVER[$semaEnvName] = $semaEnvValue;
    }
}

function semaEnv(string $name, ?string $default = null): ?string {
    $value = getenv($name);
    return $value === false ? $default : $value;
}

function semaEnvBool(string $name, bool $default = false): bool {
    $value = semaEnv($name);
    if ($value === null) return $default;
    $parsed = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    return $parsed ?? $default;
}

if (!defined('SEMA_ENV')) {
    $semaEnvironment = strtolower(semaEnv('APP_ENV', 'production') ?? 'production');
    if (!in_array($semaEnvironment, ['production', 'development', 'test'], true)) {
        $semaEnvironment = 'production';
    }
    define('SEMA_ENV', $semaEnvironment);
}

$semaDebug = semaEnvBool('APP_DEBUG', false);
ini_set('display_errors', $semaDebug ? '1' : '0');
ini_set('display_startup_errors', $semaDebug ? '1' : '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);