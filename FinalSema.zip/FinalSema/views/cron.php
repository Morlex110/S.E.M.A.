<?php
/**
 * Tab 4: Calendario Académico Dinámico y Alertas
 */
?>
<section id="cron" class="utn-tab-panel">
  <div class="utn-columns-split">
    <div class="utn-calendar-card">
      <div class="calendar-bar-navigation">
        <button class="utn-btn-arrow" onclick="mesAnterior()">◀</button>
        <div class="calendar-center-lbl">
          <h2 id="dinamico-anio-cronograma" class="cal-year">2026</h2>
          <h3 id="dinamico-mes-cronograma" class="cal-month">OCTUBRE</h3>
        </div>
        <button class="utn-btn-arrow" onclick="mesSiguiente()">▶</button>
      </div>
      <div class="calendar-grid-layout" id="calendario-dias"></div>
    </div>

    <div class="utn-calendar-agenda">
      <div id="lista-eventos-lateral"></div>
    </div>
  </div>
</section>
