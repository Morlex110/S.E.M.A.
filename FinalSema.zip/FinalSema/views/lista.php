<?php
/**
 * Tab 3: Registro y Planilla de Calificaciones de Alumnos
 */
?>
<section id="lista" class="utn-tab-panel">
  <div class="utn-columns-split">
    <div class="utn-table-container">
      <div class="table-bar-actions">
        <div>
          <h3 class="table-title">Registro del curso</h3>
          <span style="font-size: 0.8rem; color: #64748b;" id="subtituloCursoLista">Curso activo</span>
        </div>
        <div style="display: flex; gap: 8px;">
          <label id="btnImportarAlumnosLabel" class="utn-btn-rect-secondary" for="inputImportarAlumnos" style="cursor:pointer;">Importar CSV</label>
          <input type="file" id="inputImportarAlumnos" accept=".csv,text/csv" hidden onchange="importarAlumnosCSV(this)">
          <button class="utn-btn-rect-secondary" onclick="abrirModal('modalRegistrarAlumno')">+ Registrar Estudiante</button>
        </div>
      </div>
      <table class="utn-table-data">
        <thead>
          <tr>
            <th style="width: 12%">N° ORDEN</th>
            <th>ESTUDIANTE (APELLIDO Y NOMBRE)</th>
            <th style="width: 20%; text-align: center;">NOTA CORRIENTE</th>
            <th style="width: 22%; text-align: center;">PROGRESO</th>
            <th style="width: 16%; text-align: center;" id="columnaEstadoTh">ESTADO</th>
          </tr>
        </thead>
        <tbody id="tabla-alumnos-body"></tbody>
      </table>
      <button id="btnExpandirAlumnos" class="student-roster-toggle" type="button" onclick="alternarBandejaAlumnos()" aria-expanded="false" hidden>
        <span class="student-roster-toggle-arrow" aria-hidden="true">⌄</span>
        <span id="textoExpandirAlumnos">Mostrar más alumnos</span>
      </button>
    </div>

    <div class="utn-side-card-profile">
      <div class="profile-card-top">
        <div class="profile-square" style="font-size: 0.85rem;">ALUMNO</div>
        <div>
          <h3 id="detalle-nombre-rapido" class="profile-name">Seleccione Alumno</h3>
          <span class="profile-subtitle" id="detalle-email-alumno">Ficha de Seguimiento Escolar</span>
        </div>
      </div>
      <section id="observacionesAulaAlumno" class="student-observation" aria-labelledby="observacionesAulaAlumnoTitulo" hidden>
        <h4 id="observacionesAulaAlumnoTitulo">Observaciones en el aula</h4>
        <p id="observacionesAulaAlumnoTexto"></p>
      </section>
      <div class="profile-info-row">
        <span>Condición de Cursado:</span>
        <select id="detalle-condicion-alumno" class="utn-rect-select">
          <option value="Regular">Regular</option>
          <option value="Desaprobado">Desaprobado</option>
          <option value="Bien">Bien</option>
        </select>
      </div>
      <div class="utn-form-item">
        <label class="utn-form-label">Nombre completo del estudiante</label>
        <input type="text" id="detalle-nombre-editar" class="utn-rect-input" />
      </div>
      <div class="utn-form-item">
        <label class="utn-form-label">Nota actual (0 a 10)</label>
        <input type="number" min="0" max="10" step="0.1" id="inputNotaAlumnoDetalle" class="utn-rect-input" />
      </div>
      <div class="utn-form-item">
      <label class="utn-form-label">Correo electrónico</label>
      <input type="email" id="detalle-email-editar" class="utn-rect-input" />
    </div>
      <div class="utn-form-item">
        <label class="utn-form-label">DNI del estudiante</label>
        <input type="text" id="detalle-dni-editar" inputmode="numeric" class="utn-rect-input" />
      </div>
      <div class="utn-form-item" id="detalleObservacionesDocenteWrapper">
        <label class="utn-form-label" for="detalle-observaciones-docente">Observaciones en el aula</label>
        <textarea id="detalle-observaciones-docente" class="utn-rect-input teacher-observation-input" rows="4" maxlength="10000" placeholder="Seguimiento y observaciones para el equipo docente"></textarea>
      </div>
      <div class="modal-footer-buttons" style="margin-top: 16px; justify-content: flex-start; gap: 10px;">
        <button class="utn-btn-rect-primary" onclick="guardarCambiosAlumnoDetalle()">Guardar cambios</button>
        <button class="utn-btn-rect-danger" id="btnDarDeBajaAlumno" onclick="eliminarAlumnoSeleccionado()">Dar de baja</button>
        <button class="utn-btn-rect-secondary" id="btnReincorporarDetalle" onclick="reincorporarAlumnoDetalle()" style="display: none; background: #059669; color: white;">Reincorporar</button>
      </div>
    </div>
  </div>
</section>
