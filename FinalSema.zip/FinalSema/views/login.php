<?php
/**
 * Vista de Inicio de Sesión y Registro
 */
?>
<section id="loginScreen" class="login-screen">
  <div class="wrapper" id="frmWrapper">
    <div class="for-container signup">
      <h2>Registrarse</h2>
      <form id="signupForm" action="#">
        <input id="signupUsername" type="text" placeholder="Usuario" required />
        <input id="signupEmail" type="email" placeholder="Correo Electrónico" required />
        <input id="signupNombreCompleto" type="text" placeholder="Apellido y Nombre (igual al padrón)" required />
        <label class="auth-field-label" for="signupFecha_de_Nacimiento">Elegí una fecha clave y recordala</label>
        <input id="signupFecha_de_Nacimiento" type="date" required />
        <input id="signupDni" type="text" inputmode="numeric" autocomplete="off" placeholder="DNI" required />
        <input id="signupPassword" type="password" minlength="12" maxlength="72" autocomplete="new-password" placeholder="Contraseña (12 a 72 caracteres)" required />
        <input id="signupCursoAsignado" type="text" placeholder="Curso asignado por el padrón" readonly aria-label="Curso asignado automáticamente" style="background:#e5e7eb;color:#475569;cursor:not-allowed;" />
        <label class="accept-terms">
          <input id="signupTermsAccepted" type="checkbox" required />
          <span>Acepto los términos y el aviso de privacidad.</span>
        </label>
        <button type="button" class="terms-open" onclick="abrirModal('modalTerminos')">Leer términos y aviso de privacidad</button>
        <button type="submit" class="submit-btn">Registrarse</button>
      </form>
      <button type="button" class="mobile-auth-toggle" id="mobileToggleBtnLogin">¿Ya tienes cuenta? Iniciar sesión</button>
    </div>

    <div class="for-container login">
      <h2>Iniciar Sesión</h2>
      <form id="loginForm" action="#">
        <input id="loginIdentity" type="text" placeholder="Email o Usuario" required />
        <label class="auth-field-label" for="loginFecha_de_Nacimiento">Fecha clave</label>
        <input id="loginFecha_de_Nacimiento" type="date" required />
        <input id="loginPassword" type="password" placeholder="Contraseña" required />
        <button type="submit" class="submit-btn">Iniciar Sesión</button>

        <div style="margin-top: 15px; font-size: 0.78rem; color: #64748b; text-align: center;">
          <span>Acceso seguro certificado SEMA</span>
        </div>
        <button type="button" class="mobile-auth-toggle" id="mobileToggleBtnSignup">¿No tienes cuenta? Registrarte</button>
      </form>
    </div>

    <div class="toggle-container">
      <div class="toggle">
        <div class="toggle-panel toggle-left">
          <h2>¿Ya tienes una cuenta?</h2>
          <p>¡Inicia sesión como docente, alumno o administrador!</p>
          <button id="toggleBtnLogin" class="ghost">Iniciar Sesión</button>
        </div>
        <div class="toggle-panel toggle-right">
          <h2>¿No tienes una cuenta?</h2>
          <p>Registrate con los datos que figuran en el padrón de tu curso.</p>
          <button id="toggleBtnSignup" class="ghost">Registrarse</button>
        </div>
      </div>
    </div>
  </div>
  <div id="loginStatusMessage" class="login-status-message" role="alert" aria-live="assertive" hidden></div>
  <div id="modalTerminos" class="modal-window-overlay">
    <section class="modal-rect-card modal-terms" role="dialog" aria-modal="true" aria-labelledby="tituloTerminos">
      <button type="button" class="modal-close-x" aria-label="Cerrar términos" onclick="cerrarModal('modalTerminos')">&times;</button>
      <h3 class="modal-heading" id="tituloTerminos">TÉRMINOS Y AVISO DE PRIVACIDAD</h3>
      <p class="terms-version">Versión <?= htmlspecialchars(SEMA_TERMS_VERSION, ENT_QUOTES, 'UTF-8') ?></p>
      <div class="terms-content">
        <h4>Uso del sistema</h4>
        <p>SEMA se utiliza para organizar cursos, contenidos y materiales, calendario, registro de alumnos, calificaciones, progreso y entregas escolares. Cada persona debe usar su propia cuenta y mantener sus credenciales en privado.</p>

        <h4>Datos tratados</h4>
        <p>Según las funciones utilizadas, el sistema guarda nombre y apellido, DNI, correo, curso, usuario, contraseña protegida mediante hash, notas, condición y progreso académico, contenidos cargados, enlaces y comentarios de entregas. También registra fecha y resultado de accesos, dirección IP y datos del navegador para seguridad y auditoría.</p>

        <h4>Finalidad y acceso</h4>
        <p>Los datos se usan para gestionar la actividad educativa, habilitar el acceso y dar seguimiento escolar. El alumnado accede a su cuenta y curso; docentes, a los cursos que tienen asignados; y administradores, a la gestión general. El personal técnico con acceso al servidor o a las copias de seguridad también podría acceder a los datos.</p>

        <h4>Almacenamiento y conservación</h4>
        <p>En esta instalación, los datos se guardan en MySQL en el servidor local WAMP. Las bajas de alumnos se archivan; el sistema no elimina automáticamente registros ni bitácoras. Las copias descargadas por administración pueden conservar datos y deben guardarse con acceso restringido. La institución debe definir los plazos de conservación y atender pedidos de corrección o eliminación según sus obligaciones escolares y la normativa aplicable.</p>

        <h4>Archivos y servicios externos</h4>
        <p>Los archivos que el personal carga se guardan en el servidor del sistema y se sirven a personas autenticadas con acceso al curso. Para las entregas, SEMA guarda el enlace de Google Drive y el comentario, no copia el archivo de Drive; quien comparte el enlace debe revisar sus permisos. Google y otros sitios enlazados se rigen por sus propias condiciones y políticas.</p>

        <h4>Seguridad y menores de edad</h4>
        <p>Las contraseñas se guardan como hash y el acceso se limita por roles, pero ninguna medida elimina todos los riesgos. La seguridad también depende del equipo, la red, la configuración de WAMP y el resguardo de las copias. Si la persona es menor de edad, debe contar con la autorización de su madre, padre o responsable cuando corresponda.</p>

        <h4>Consultas sobre los datos</h4>
        <p>Para pedir acceso, corrección o revisión de datos, contactá al docente o administrador de SEMA de tu institución. La institución que administra el sistema debe informar quién es responsable del tratamiento y un canal de contacto antes de su uso formal.</p>
      </div>
      <div class="modal-footer-buttons">
        <button type="button" class="utn-btn-rect-primary" onclick="cerrarModal('modalTerminos')">Cerrar</button>
      </div>
    </section>
  </div>
</section>
