<?php
/**
 * Tab 2: Ruta de Aprendizaje (Unidades y Cápsulas Didácticas)
 */
?>
<section id="temas" class="utn-tab-panel">
  <div class="utn-section-title-row">
    <div>
      <span class="section-kicker">MAPA DEL CURSO</span>
      <h2 class="utn-block-heading">Ruta de aprendizaje</h2>
      <p class="section-supporting-text">Avanzá por unidades y completá cada cápsula a tu ritmo.</p>
    </div>
    <button id="btnNuevaUnidadCurricular" class="utn-btn-rect-primary" onclick="abrirModal('modalNuevaUnidad')">+ Añadir Unidad Curricular</button>
  </div>
  <div class="capsule-legend" aria-label="Tipos de contenido">
    <span><b class="legend-t">T</b> Teoría y lectura</span>
    <span><b class="legend-v">V</b> Video explicativo</span>
    <span><b class="legend-e">E</b> Ejercicio y práctica</span>
  </div>
  <div id="contenedor-unidades" class="utn-grid-unidades"></div>
</section>
