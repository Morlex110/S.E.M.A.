<?php
/**
 * Tab 1: Inicio SEMA / Dashboard de Aprendizaje y Planificación
 */
?>
<section id="sema" class="utn-tab-panel active">
  <div class="utn-row-layout">
    <div class="utn-main-block">
      <span class="utn-section-badge">ENTORNO VIRTUAL DE PLANIFICACIÓN</span>
      <h1 class="utn-page-title" id="sema-titulo-curso">SEMA - Cátedra Curricular</h1>
      <h2 class="utn-page-subtitle" id="sema-subtitulo-materias">Cargando cátedra...</h2>

      <div class="utn-notice-box">
        <p><strong>Comunicado de la Cátedra:</strong> <span id="sema-comunicado-texto">Espacio docente para el seguimiento del aula, control de planificaciones didácticas modulares, y asentamiento de calificaciones trimestrales.</span></p>
      </div>
      <div class="utn-alert-card-linear">
        <div class="alert-strip"></div>
        <div class="alert-content">
          <span class="alert-tag">PRÓXIMA INSTANCIA EVALUATIVA</span>
          <p class="alert-text-main">Fecha Programada: <strong id="sema-fecha-examen">18/8</strong></p>
          <p class="alert-text-sub">Eje Temático de Evaluación: <span id="sema-tema-examen">Integrador Estructural.</span></p>
        </div>
      </div>
      <section id="courseDriveBanner" class="course-drive-banner" hidden>
        <div>
          <span class="section-kicker">DRIVE DEL CURSO</span>
          <p id="courseDriveDescription">Tareas y resoluciones compartidas.</p>
        </div>
        <a id="courseDriveLink" class="drive-folder-link" href="#" target="_blank" rel="noopener noreferrer">Abrir carpeta de Drive</a>
      </section>
    </div>

    <aside class="utn-side-news">
      <h3 class="side-title">CIRCULARES INTERNAS</h3>
      <div class="news-stack">
        <div class="news-box-item">
          <span class="date-lbl">HOY</span>
          <p>Habilitación de planillas para el cierre pedagógico trimestral.</p>
        </div>
        <div class="news-box-item">
          <span class="date-lbl">AYER</span>
          <p>Entrega obligatoria de planificaciones anuales de taller.</p>
        </div>
      </div>
    </aside>
  </div>

  <section class="learning-dashboard" aria-label="Progreso del curso">
    <div class="dashboard-heading">
      <div>
        <span class="section-kicker">PANEL DE APRENDIZAJE</span>
        <h2>Tu recorrido en <span id="dashboard-curso-corto">SEMA</span></h2>
        <p>Organiza cursos y materiales; las tareas y entregas se gestionan en Google Drive.</p>
      </div>
      <button class="learning-action" onclick="cambiarPestana('temas', document.querySelectorAll('.utn-link-item')[1])">Ver ruta completa <span>→</span></button>
    </div>
    <div class="dashboard-grid">
      <article class="progress-hero-card">
        <div class="progress-hero-top">
          <div>
            <span class="card-eyebrow" id="dashboardProgressLabel">CONTENIDOS DADOS</span>
            <strong id="dashboard-progreso-total">0%</strong>
          </div>
          <div class="progress-ring" id="dashboard-ring"><span id="dashboard-progreso-ring">0%</span></div>
        </div>
        <div class="progress-track"><span id="dashboard-progreso-bar"></span></div>
        <p id="dashboard-progreso-text">Comenzá el recorrido para registrar tu avance.</p>
      </article>
      <article class="next-lesson-card">
        <span class="card-eyebrow">SIGUIENTE PASO</span>
        <h3 id="dashboard-siguiente-titulo">Unidad pendiente</h3>
        <p id="dashboard-siguiente-desc">Explorá la ruta de aprendizaje de tu curso.</p>
        <button class="text-action" onclick="cambiarPestana('temas', document.querySelectorAll('.utn-link-item')[1])">Continuar <span>↗</span></button>
      </article>
      <article class="dashboard-stats-card">
        <div class="stat-line"><span>Unidades</span><strong id="dashboard-unidades">0</strong></div>
        <div class="stat-line"><span id="dashboardRosterLabel">Estudiantes</span><strong id="dashboard-alumnos">0</strong></div>
        <div class="stat-line"><span>Próxima evaluación</span><strong id="dashboard-evaluacion">--</strong></div>
      </article>
    </div>
  </section>

</section>
