<?php
/**
 * Tab 5: Panel Exclusivo de Administración General
 */
?>
<section id="adminPanel" class="utn-tab-panel">
  <div class="admin-panel-container">
    <div class="admin-header-strip">
      <div>
        <span class="section-kicker">CONTROL CENTRAL</span>
        <h2 class="utn-block-heading">Panel de Administración General</h2>
        <p class="section-supporting-text">Gestión de auditoría de accesos, respaldo semanal, asignación docente y registro integral de alumnos.</p>
      </div>
      <div class="admin-top-actions">
        <button class="utn-btn-rect-primary" onclick="descargarBackupSQL()">
          <svg style="width:16px;height:16px;vertical-align:middle;margin-right:6px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
          Descargar Backup SQL
        </button>
        <button class="utn-btn-rect-secondary" onclick="abrirModal('modalNuevoUsuario')">+ Crear Usuario Manualmente</button>
      </div>
    </div>

    <!-- Pestañas internas del panel admin -->
    <div class="admin-subnav">
      <button class="admin-subnav-btn active" onclick="cambiarSubtabAdmin('adminAlumnos', this)">Registro Global de Alumnos & Recuperación</button>
      <button class="admin-subnav-btn" onclick="cambiarSubtabAdmin('adminLogs', this)">Auditoría de Ingresos (Logs)</button>
      <button class="admin-subnav-btn" onclick="cambiarSubtabAdmin('adminUsuarios', this)">Gestión y Reordenamiento de Usuarios</button>
      <button class="admin-subnav-btn" onclick="cambiarSubtabAdmin('adminBackup', this)">Módulo de Respaldos (Backup)</button>
      <button class="admin-subnav-btn" onclick="cambiarSubtabAdmin('adminIncidencias', this)">Incidencias</button>
    </div>

    <!-- Subtab 1: Registro Global de Alumnos & Papelera (Activos vs Inactivos en Gris) -->
    <div id="adminAlumnos" class="admin-subpanel active">
      <div class="admin-card-box">
        <div class="admin-card-header">
          <div>
            <h3>Registro de alumnos</h3>
            <p class="admin-registry-description">
              Fichas de todos los cursos, estado de cursado y cuenta vinculada. Usá estos datos para revisar altas y corregir asociaciones.
            </p>
          </div>
          <button class="utn-btn-rect-secondary" onclick="cargarRegistroGlobalAlumnosAdmin()">↻ Actualizar Lista</button>
        </div>
        <div class="admin-registry-tools">
          <label class="roster-search-field">
            <span aria-hidden="true">⌕</span>
            <input id="inputBuscarRegistroAdmin" type="search" placeholder="Buscar alumno, DNI, correo o curso" autocomplete="off" />
          </label>
          <label class="admin-status-filter">
            <span>Estado</span>
            <select id="filtroEstadoRegistroAdmin" class="utn-rect-select">
              <option value="todos">Todos</option>
              <option value="1">Activos</option>
              <option value="0">Dados de baja</option>
            </select>
          </label>
          <span id="contadorRegistroAdmin" class="roster-result-count" aria-live="polite"></span>
        </div>
        <div class="admin-table-responsive">
          <table class="utn-table-data admin-table">
            <thead>
              <tr>
                <th>CURSO</th>
                <th>N°</th>
                <th>APELLIDO Y NOMBRE</th>
                <th>DNI</th>
                <th>EMAIL</th>
                <th style="text-align: center;">NOTA</th>
                <th style="text-align: center;">ESTADO</th>
                <th style="text-align: center;">ACCIÓN</th>
                <th>CUENTA DE ACCESO</th>
              </tr>
            </thead>
            <tbody id="tablaAdminAlumnosBody">
              <tr><td colspan="9" style="text-align:center; padding:20px;">Cargando registro global...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Subtab 2: Logs de Acceso -->
    <div id="adminLogs" class="admin-subpanel">
      <div class="admin-card-box">
        <div class="admin-card-header">
          <div>
            <h3>Auditoría de Ingreso de Docentes y Alumnos</h3>
            <p style="font-size: 0.85rem; color: #64748b; margin-top: 4px;">Registro cronológico de autenticaciones, intentos de inicio de sesión y direcciones IP.</p>
          </div>
          <button class="utn-btn-rect-secondary" onclick="cargarLogsAdmin()">↻ Actualizar Logs</button>
        </div>
        <div class="admin-table-responsive">
          <table class="utn-table-data admin-table">
            <thead>
              <tr>
                <th>FECHA Y HORA</th>
                <th>USUARIO</th>
                <th>ROL</th>
                <th>IP</th>
                <th>DISPOSITIVO / NAVEGADOR</th>
                <th style="text-align:center;">RESULTADO</th>
              </tr>
            </thead>
            <tbody id="tablaAdminLogsBody">
              <tr><td colspan="6" style="text-align:center; padding:20px;">Cargando registros de auditoría...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Subtab 3: Gestión y Reordenamiento de Usuarios -->
    <div id="adminUsuarios" class="admin-subpanel">
      <div class="admin-card-box">
        <div class="admin-card-header">
          <div>
            <h3>Gestión y Reordenamiento de Docentes y Usuarios</h3>
            <p style="font-size: 0.85rem; color: #64748b; margin-top: 4px;">Revisá los roles, seleccioná uno o más cursos para cada docente y corregí cuentas creadas anteriormente con un rol incorrecto.</p>
          </div>
          <button class="utn-btn-rect-primary" onclick="abrirModal('modalNuevoUsuario')">+ Nuevo Usuario</button>
        </div>
        <div class="admin-table-responsive">
          <table class="utn-table-data admin-table">
            <thead>
              <tr>
                <th style="width: 8%;">ORDEN</th>
                <th>NOMBRE COMPLETO</th>
                <th>USUARIO</th>
                <th>EMAIL</th>
                <th>ROL</th>
                <th>CURSO ASIGNADO</th>
                <th style="text-align: center;">CAMBIAR ROL</th>
              </tr>
            </thead>
            <tbody id="tablaAdminUsuariosBody">
              <tr><td colspan="7" style="text-align:center; padding:20px;">Cargando usuarios...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div id="adminIncidencias" class="admin-subpanel">
      <div class="admin-card-box">
        <div class="admin-card-header">
          <div>
            <h3>Reportes de alumnos y docentes</h3>
            <p class="section-supporting-text">Los reportes enviados desde el sitio aparecen aquí para su seguimiento.</p>
          </div>
          <button class="utn-btn-rect-secondary" onclick="cargarIncidenciasAdmin()">↻ Actualizar</button>
        </div>
        <div class="admin-table-responsive">
          <table class="utn-table-data admin-table incident-table">
            <thead>
              <tr>
                <th>FECHA</th>
                <th>REMITENTE</th>
                <th>TIPO</th>
                <th>DESCRIPCIÓN</th>
                <th>ESTADO</th>
                <th>SEGUIMIENTO</th>
              </tr>
            </thead>
            <tbody id="tablaAdminIncidenciasBody">
              <tr><td colspan="6" style="text-align:center; padding:20px;">Seleccioná Incidencias para consultar los reportes.</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Subtab 4: Módulo de Backups -->
    <div id="adminBackup" class="admin-subpanel">
      <div class="admin-card-box">
        <div class="admin-card-header">
          <div>
            <h3>Respaldo y Salvaguarda de Datos Escolares</h3>
            <p style="font-size: 0.85rem; color: #64748b; margin-top: 4px;">Generación de copia de seguridad semanal de todas las calificaciones, temas y usuarios.</p>
          </div>
        </div>
        <div class="backup-info-grid">
          <div class="backup-metric-card">
            <span class="backup-metric-title">BASE DE DATOS ACTIVA</span>
            <strong class="backup-metric-val">sema_db (MySQL)</strong>
            <p>Servidor local WAMP 3306</p>
          </div>
          <div class="backup-metric-card">
            <span class="backup-metric-title">FRECUENCIA RECOMENDADA</span>
            <strong class="backup-metric-val">Semanal</strong>
            <p>Ciclo lectivo activo</p>
          </div>
          <div class="backup-metric-card">
            <span class="backup-metric-title">VOLCADO INTEGRAL</span>
            <strong class="backup-metric-val">Estructura y Datos</strong>
            <p>Formato compatible phpMyAdmin / MySQL CLI</p>
          </div>
        </div>

        <div style="margin-top: 25px; padding: 20px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; text-align: center;">
          <h4 style="margin-bottom: 8px; color: #1e293b;">Descargar Respaldo Completo Inmediato</h4>
          <p style="font-size: 0.9rem; color: #64748b; max-width: 600px; margin: 0 auto 16px auto;">
            Haga clic en el botón siguiente para generar y descargar al instante el archivo SQL con todos los registros de alumnos, notas, cursos y planificaciones.
          </p>
          <button class="utn-btn-rect-primary" onclick="descargarBackupSQL()" style="font-size: 1rem; padding: 12px 24px;">
            ⬇ Descargar Archivo de Respaldo (.sql)
          </button>
        </div>
      </div>
    </div>
  </div>
</section>
