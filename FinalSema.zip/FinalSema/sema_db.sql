-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 06-11-2026 a las 02:58:01
-- Versión del servidor: 8.4.7
-- Versión de PHP: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sema_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
CREATE TABLE IF NOT EXISTS `alumnos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `curso_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `n_orden` int NOT NULL,
  `corto` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `completo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dni` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nota` decimal(4,2) DEFAULT '0.00',
  `condicion` enum('Regular','Desaprobado','Bien') COLLATE utf8mb4_unicode_ci DEFAULT 'Regular',
  `progreso` int DEFAULT '0',
  `activo` tinyint(1) DEFAULT '1',
  `fecha_baja` datetime DEFAULT NULL,
  `motivo_baja` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observaciones_docente` text COLLATE utf8mb4_unicode_ci,
  `Fecha_de_Nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  UNIQUE KEY `uq_alumnos_dni` (`dni`),
  KEY `curso_id` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`id`, `usuario_id`, `curso_id`, `n_orden`, `corto`, `completo`, `dni`, `email`, `nota`, `condicion`, `progreso`, `activo`, `fecha_baja`, `motivo_baja`, `observaciones_docente`, `Fecha_de_Nacimiento`) VALUES
(1, NULL, '2gao', 1, 'Tomas', 'Tomas Borial', NULL, 'juanhja@gmail.com', 9.00, 'Regular', 90, 1, NULL, NULL, NULL, NULL),
(2, NULL, '2cstep', 1, 'María', 'María Chavez', NULL, 'mariaf@gmail.com', 9.00, 'Regular', 90, 1, NULL, NULL, NULL, NULL),
(3, NULL, '2cstep', 2, 'Esteban', 'Esteban Gonzalez', NULL, 'estebanq@gmail.com', 7.00, 'Regular', 70, 1, NULL, NULL, NULL, NULL),
(4, 12, '2cstep', 3, 'Alumno', 'Alumno Prueba 001', '90000001', 'sema.alumno.001@example.invalid', 6.00, 'Regular', 0, 1, NULL, NULL, 'Segui estudiando y empeza a mandar los trabajos a tiempo.', NULL),
(5, NULL, '2cstep', 4, 'Alumno', 'Alumno Prueba 002', '90000002', 'sema.alumno.002@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(6, 4, '2cstep', 5, 'Alumno', 'Alumno Prueba 003', '90000003', 'sema.alumno.003@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(7, NULL, '2cstep', 6, 'Alumno', 'Alumno Prueba 004', '90000004', 'sema.alumno.004@example.invalid', 8.00, 'Bien', 0, 1, NULL, NULL, NULL, NULL),
(8, NULL, '2cstep', 7, 'Alumno', 'Alumno Prueba 005', '90000005', 'sema.alumno.005@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(9, 16, '2cstep', 8, 'Alumno', 'Alumno Prueba 006', '90000006', 'sema.alumno.006@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(10, NULL, '2cstep', 9, 'Alumno', 'Alumno Prueba 007', '90000007', 'sema.alumno.007@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(11, NULL, '2cstep', 10, 'Alumno', 'Alumno Prueba 008', '90000008', 'sema.alumno.008@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(12, NULL, '2cstep', 11, 'Alumno', 'Alumno Prueba 009', '90000009', 'sema.alumno.009@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(13, NULL, '2cstep', 12, 'Alumno', 'Alumno Prueba 010', '90000010', 'sema.alumno.010@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(14, NULL, '2cstep', 13, 'Alumno', 'Alumno Prueba 011', '90000011', 'sema.alumno.011@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(15, NULL, '2cstep', 14, 'Alumno', 'Alumno Prueba 012', '90000012', 'sema.alumno.012@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(16, NULL, '2cstep', 15, 'Alumno', 'Alumno Prueba 013', '90000013', 'sema.alumno.013@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(17, NULL, '2cstep', 16, 'Alumno', 'Alumno Prueba 014', '90000014', 'sema.alumno.014@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(18, NULL, '2cstep', 17, 'Alumno', 'Alumno Prueba 015', '90000015', 'sema.alumno.015@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(19, NULL, '2cstep', 18, 'Alumno', 'Alumno Prueba 016', '90000016', 'sema.alumno.016@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(20, NULL, '2cstep', 19, 'Alumno', 'Alumno Prueba 017', '90000017', 'sema.alumno.017@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(21, NULL, '2cstep', 20, 'Alumno', 'Alumno Prueba 018', '90000018', 'sema.alumno.018@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(22, NULL, '2cstep', 21, 'Alumno', 'Alumno Prueba 019', '90000019', 'sema.alumno.019@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(23, NULL, '2cstep', 22, 'Alumno', 'Alumno Prueba 020', '90000020', 'sema.alumno.020@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(24, NULL, '2cstep', 23, 'Alumno', 'Alumno Prueba 021', '90000021', 'sema.alumno.021@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(25, NULL, '2cstep', 24, 'Alumno', 'Alumno Prueba 022', '90000022', 'sema.alumno.022@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(26, NULL, '2cstep', 25, 'Alumno', 'Alumno Prueba 023', '90000023', 'sema.alumno.023@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(27, NULL, '2cstep', 26, 'Alumno', 'Alumno Prueba 024', '90000024', 'sema.alumno.024@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(28, NULL, '2cstep', 27, 'Alumno', 'Alumno Prueba 025', '90000025', 'sema.alumno.025@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(29, NULL, '2cstep', 28, 'Alumno', 'Alumno Prueba 026', '90000026', 'sema.alumno.026@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(30, NULL, '2cstep', 29, 'Alumno', 'Alumno Prueba 027', '90000027', 'sema.alumno.027@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(31, NULL, '2cstep', 30, 'Alumno', 'Alumno Prueba 028', '90000028', 'sema.alumno.028@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(32, NULL, '2cstep', 31, 'Alumno', 'Alumno Prueba 029', '90000029', 'sema.alumno.029@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(33, NULL, '2cstep', 32, 'Alumno', 'Alumno Prueba 030', '90000030', 'sema.alumno.030@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(34, NULL, '2cstep', 33, 'Alumno', 'Alumno Prueba 031', '90000031', 'sema.alumno.031@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(35, NULL, '2cstep', 34, 'Alumno', 'Alumno Prueba 032', '90000032', 'sema.alumno.032@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(36, NULL, '2cstep', 35, 'Alumno', 'Alumno Prueba 033', '90000033', 'sema.alumno.033@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(37, NULL, '2cstep', 36, 'Alumno', 'Alumno Prueba 034', '90000034', 'sema.alumno.034@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(38, NULL, '2cstep', 37, 'Alumno', 'Alumno Prueba 035', '90000035', 'sema.alumno.035@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(39, NULL, '2cstep', 38, 'Alumno', 'Alumno Prueba 036', '90000036', 'sema.alumno.036@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(40, NULL, '2cstep', 39, 'Alumno', 'Alumno Prueba 037', '90000037', 'sema.alumno.037@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(41, NULL, '2cstep', 40, 'Alumno', 'Alumno Prueba 038', '90000038', 'sema.alumno.038@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(42, NULL, '2cstep', 41, 'Alumno', 'Alumno Prueba 039', '90000039', 'sema.alumno.039@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(43, NULL, '2cstep', 42, 'Alumno', 'Alumno Prueba 040', '90000040', 'sema.alumno.040@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(44, NULL, '2cstep', 43, 'Alumno', 'Alumno Prueba 041', '90000041', 'sema.alumno.041@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(45, NULL, '2cstep', 44, 'Alumno', 'Alumno Prueba 042', '90000042', 'sema.alumno.042@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(46, NULL, '2cstep', 45, 'Alumno', 'Alumno Prueba 043', '90000043', 'sema.alumno.043@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(47, NULL, '2cstep', 46, 'Alumno', 'Alumno Prueba 044', '90000044', 'sema.alumno.044@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(48, NULL, '2cstep', 47, 'Alumno', 'Alumno Prueba 045', '90000045', 'sema.alumno.045@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(49, NULL, '2cstep', 48, 'Alumno', 'Alumno Prueba 046', '90000046', 'sema.alumno.046@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(50, NULL, '2cstep', 49, 'Alumno', 'Alumno Prueba 047', '90000047', 'sema.alumno.047@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(51, NULL, '2cstep', 50, 'Alumno', 'Alumno Prueba 048', '90000048', 'sema.alumno.048@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(52, NULL, '2cstep', 51, 'Alumno', 'Alumno Prueba 049', '90000049', 'sema.alumno.049@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(53, NULL, '2cstep', 52, 'Alumno', 'Alumno Prueba 050', '90000050', 'sema.alumno.050@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(54, NULL, '2gao', 2, 'GAO-PRUEBA-001', 'GAO-PRUEBA-001 Alumno Ficticio', '990000001', 'gao.prueba.001@example.invalid', 8.00, 'Bien', 0, 1, NULL, NULL, NULL, NULL),
(55, NULL, '2gao', 3, 'GAO-PRUEBA-002', 'GAO-PRUEBA-002 Alumno Ficticio', '990000002', 'gao.prueba.002@example.invalid', 10.00, 'Bien', 0, 1, NULL, NULL, NULL, NULL),
(56, NULL, '2gao', 4, 'GAO-PRUEBA-003', 'GAO-PRUEBA-003 Alumno Ficticio', '990000003', 'gao.prueba.003@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(57, NULL, '2gao', 5, 'GAO-PRUEBA-004', 'GAO-PRUEBA-004 Alumno Ficticio', '990000004', 'gao.prueba.004@example.invalid', 8.00, 'Bien', 0, 1, NULL, NULL, 'Buen Trabajo!!', NULL),
(58, NULL, '2gao', 6, 'GAO-PRUEBA-005', 'GAO-PRUEBA-005 Alumno Ficticio', '990000005', 'gao.prueba.005@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(59, NULL, '2gao', 7, 'GAO-PRUEBA-006', 'GAO-PRUEBA-006 Alumno Ficticio', '990000006', 'gao.prueba.006@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(60, NULL, '2gao', 8, 'GAO-PRUEBA-007', 'GAO-PRUEBA-007 Alumno Ficticio', '990000007', 'gao.prueba.007@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(61, NULL, '2gao', 9, 'GAO-PRUEBA-008', 'GAO-PRUEBA-008 Alumno Ficticio', '990000008', 'gao.prueba.008@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(62, NULL, '2gao', 10, 'GAO-PRUEBA-009', 'GAO-PRUEBA-009 Alumno Ficticio', '990000009', 'gao.prueba.009@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(63, NULL, '2gao', 11, 'GAO-PRUEBA-010', 'GAO-PRUEBA-010 Alumno Ficticio', '990000010', 'gao.prueba.010@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(64, NULL, '2gao', 12, 'GAO-PRUEBA-011', 'GAO-PRUEBA-011 Alumno Ficticio', '990000011', 'gao.prueba.011@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(65, NULL, '2gao', 13, 'GAO-PRUEBA-012', 'GAO-PRUEBA-012 Alumno Ficticio', '990000012', 'gao.prueba.012@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(66, NULL, '2gao', 14, 'GAO-PRUEBA-013', 'GAO-PRUEBA-013 Alumno Ficticio', '990000013', 'gao.prueba.013@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(67, NULL, '2gao', 15, 'GAO-PRUEBA-014', 'GAO-PRUEBA-014 Alumno Ficticio', '990000014', 'gao.prueba.014@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(68, NULL, '2gao', 16, 'GAO-PRUEBA-015', 'GAO-PRUEBA-015 Alumno Ficticio', '990000015', 'gao.prueba.015@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(69, NULL, '2gao', 17, 'GAO-PRUEBA-016', 'GAO-PRUEBA-016 Alumno Ficticio', '990000016', 'gao.prueba.016@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(70, NULL, '2gao', 18, 'GAO-PRUEBA-017', 'GAO-PRUEBA-017 Alumno Ficticio', '990000017', 'gao.prueba.017@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(71, NULL, '2gao', 19, 'GAO-PRUEBA-018', 'GAO-PRUEBA-018 Alumno Ficticio', '990000018', 'gao.prueba.018@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(72, NULL, '2gao', 20, 'GAO-PRUEBA-019', 'GAO-PRUEBA-019 Alumno Ficticio', '990000019', 'gao.prueba.019@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(73, NULL, '2gao', 21, 'GAO-PRUEBA-020', 'GAO-PRUEBA-020 Alumno Ficticio', '990000020', 'gao.prueba.020@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(74, NULL, '2gao', 22, 'GAO-PRUEBA-021', 'GAO-PRUEBA-021 Alumno Ficticio', '990000021', 'gao.prueba.021@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(75, NULL, '2gao', 23, 'GAO-PRUEBA-022', 'GAO-PRUEBA-022 Alumno Ficticio', '990000022', 'gao.prueba.022@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(76, NULL, '2gao', 24, 'GAO-PRUEBA-023', 'GAO-PRUEBA-023 Alumno Ficticio', '990000023', 'gao.prueba.023@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(77, NULL, '2gao', 25, 'GAO-PRUEBA-024', 'GAO-PRUEBA-024 Alumno Ficticio', '990000024', 'gao.prueba.024@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(78, 17, '2gao', 26, 'GAO-PRUEBA-025', 'GAO-PRUEBA-025 Alumno Ficticio', '990000025', 'gao.prueba.025@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(79, 18, '2gao', 27, 'GAO-PRUEBA-026', 'GAO-PRUEBA-026 Alumno Ficticio', '990000026', 'gao.prueba.026@example.invalid', 7.00, 'Regular', 0, 1, NULL, NULL, 'Bien hecho!', NULL),
(80, NULL, '2gao', 28, 'GAO-PRUEBA-027', 'GAO-PRUEBA-027 Alumno Ficticio', '990000027', 'gao.prueba.027@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(81, NULL, '2gao', 29, 'GAO-PRUEBA-028', 'GAO-PRUEBA-028 Alumno Ficticio', '990000028', 'gao.prueba.028@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(82, NULL, '2gao', 30, 'GAO-PRUEBA-029', 'GAO-PRUEBA-029 Alumno Ficticio', '990000029', 'gao.prueba.029@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(83, NULL, '2gao', 31, 'GAO-PRUEBA-030', 'GAO-PRUEBA-030 Alumno Ficticio', '990000030', 'gao.prueba.030@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(84, NULL, '2gao', 32, 'GAO-PRUEBA-031', 'GAO-PRUEBA-031 Alumno Ficticio', '990000031', 'gao.prueba.031@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(85, NULL, '2gao', 33, 'GAO-PRUEBA-032', 'GAO-PRUEBA-032 Alumno Ficticio', '990000032', 'gao.prueba.032@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(86, NULL, '2gao', 34, 'GAO-PRUEBA-033', 'GAO-PRUEBA-033 Alumno Ficticio', '990000033', 'gao.prueba.033@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(87, NULL, '2gao', 35, 'GAO-PRUEBA-034', 'GAO-PRUEBA-034 Alumno Ficticio', '990000034', 'gao.prueba.034@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(88, NULL, '2gao', 36, 'GAO-PRUEBA-035', 'GAO-PRUEBA-035 Alumno Ficticio', '990000035', 'gao.prueba.035@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(89, NULL, '2gao', 37, 'GAO-PRUEBA-036', 'GAO-PRUEBA-036 Alumno Ficticio', '990000036', 'gao.prueba.036@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(90, NULL, '2gao', 38, 'GAO-PRUEBA-037', 'GAO-PRUEBA-037 Alumno Ficticio', '990000037', 'gao.prueba.037@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(91, NULL, '2gao', 39, 'GAO-PRUEBA-038', 'GAO-PRUEBA-038 Alumno Ficticio', '990000038', 'gao.prueba.038@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(92, NULL, '2gao', 40, 'GAO-PRUEBA-039', 'GAO-PRUEBA-039 Alumno Ficticio', '990000039', 'gao.prueba.039@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(93, NULL, '2gao', 41, 'GAO-PRUEBA-040', 'GAO-PRUEBA-040 Alumno Ficticio', '990000040', 'gao.prueba.040@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(94, NULL, '2gao', 42, 'GAO-PRUEBA-041', 'GAO-PRUEBA-041 Alumno Ficticio', '990000041', 'gao.prueba.041@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(95, NULL, '2gao', 43, 'GAO-PRUEBA-042', 'GAO-PRUEBA-042 Alumno Ficticio', '990000042', 'gao.prueba.042@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(96, NULL, '2gao', 44, 'GAO-PRUEBA-043', 'GAO-PRUEBA-043 Alumno Ficticio', '990000043', 'gao.prueba.043@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(97, NULL, '2gao', 45, 'GAO-PRUEBA-044', 'GAO-PRUEBA-044 Alumno Ficticio', '990000044', 'gao.prueba.044@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(98, NULL, '2gao', 46, 'GAO-PRUEBA-045', 'GAO-PRUEBA-045 Alumno Ficticio', '990000045', 'gao.prueba.045@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(99, NULL, '2gao', 47, 'GAO-PRUEBA-046', 'GAO-PRUEBA-046 Alumno Ficticio', '990000046', 'gao.prueba.046@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(100, NULL, '2gao', 48, 'GAO-PRUEBA-047', 'GAO-PRUEBA-047 Alumno Ficticio', '990000047', 'gao.prueba.047@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(101, NULL, '2gao', 49, 'GAO-PRUEBA-048', 'GAO-PRUEBA-048 Alumno Ficticio', '990000048', 'gao.prueba.048@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(102, NULL, '2gao', 50, 'GAO-PRUEBA-049', 'GAO-PRUEBA-049 Alumno Ficticio', '990000049', 'gao.prueba.049@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(103, NULL, '2gao', 51, 'GAO-PRUEBA-050', 'GAO-PRUEBA-050 Alumno Ficticio', '990000050', 'gao.prueba.050@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(104, NULL, 'cb', 1, 'CB-PRUEBA-001', 'CB-PRUEBA-001 Alumno Ficticio', '991000001', 'cb.prueba.001@example.invalid', 0.00, 'Bien', 0, 1, NULL, NULL, NULL, NULL),
(105, NULL, 'cb', 2, 'CB-PRUEBA-002', 'CB-PRUEBA-002 Alumno Ficticio', '991000002', 'cb.prueba.002@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(106, 20, 'cb', 3, 'CB-PRUEBA-003', 'CB-PRUEBA-003 Alumno Ficticio', '991000003', 'cb.prueba.003@example.invalid', 0.00, 'Regular', 0, 1, NULL, NULL, NULL, NULL),
(107, 19, 'cb', 4, 'CB-PRUEBA-004', 'CB-PRUEBA-004 Alumno Ficticio', '991000004', 'cb.prueba.004@example.invalid', 8.00, 'Bien', 0, 1, NULL, NULL, 'Sigue asi, Buen Trabajo!!!', NULL),
(108, NULL, 'cb', 5, 'CB-PRUEBA-005', 'CB-PRUEBA-005 Alumno Ficticio', '991000005', 'cb.prueba.005@example.invalid', 9.50, 'Bien', 0, 1, NULL, NULL, 'Muy bien!!!', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `capsulas`
--

DROP TABLE IF EXISTS `capsulas`;
CREATE TABLE IF NOT EXISTS `capsulas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `unidad_id` int NOT NULL,
  `tipo` enum('T','V','E') COLLATE utf8mb4_unicode_ci NOT NULL,
  `texto` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `archivo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orden` int DEFAULT '0',
  `dictada` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `unidad_id` (`unidad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `capsulas`
--

INSERT INTO `capsulas` (`id`, `unidad_id`, `tipo`, `texto`, `url`, `archivo`, `orden`, `dictada`) VALUES
(1, 1, 'T', 'Guía teórica de racionalización y propiedades de radicales', 'https://guao.org/sites/default/files/N%C3%BAmeros%20Reales.%20Racionalizaci%C3%B3n.pdf', NULL, 1, 0),
(2, 1, 'V', 'Propiedades de los radicales y racionalización', 'https://www.youtube.com/watch?v=aZdJihD0qI8', NULL, 2, 0),
(3, 1, 'E', 'Ejercicios resueltos de operaciones con radicales', 'https://institutoclaret.cl/wp-content/uploads/2020/07/PPT-RACIONALIZACI%C3%93N-MATEM%C3%81TICA-2%C2%B0-MEDIO.pdf', NULL, 3, 0),
(4, 1, 'T', 'Guía de números complejos: forma binómica, trigonométrica y polar', 'https://www.youtube.com/watch?v=vKA6C9mLz_Q', NULL, 4, 0),
(5, 1, 'V', 'Forma trigonométrica y polar de un número complejo', 'https://www.youtube.com/watch?v=aZdJihD0qI8', NULL, 5, 0),
(6, 1, 'E', 'Práctica de números complejos y conversión entre formas', 'https://www.youtube.com/watch?v=eUzGnhwqyNk', NULL, 6, 0),
(7, 2, 'T', 'Apunte sobre factorización de polinomios y geometría analítica', 'https://educacion.sanjuan.edu.ar/mesj/LinkClick.aspx?fileticket=czdny-XG_qc%3D&tabid=677&mid=1740', NULL, 1, 1),
(8, 2, 'V', 'Factorización de polinomios y Teorema de Gauss', 'https://www.youtube.com/watch?v=9k22Jo_Sjpk', NULL, 2, 1),
(9, 2, 'E', 'Ejercicios de factorización de polinomios y cónicas', 'https://www.ofimega.es/Manuales/ESO/4eso_polinomios3_factorizar.pdf', NULL, 3, 0),
(10, 2, 'T', 'Propiedades de la función cuadrática y formas de expresión', 'https://educacion.sanjuan.edu.ar/mesj/LinkClick.aspx?fileticket=czdny-XG_qc%3D&tabid=677&mid=1740', NULL, 4, 0),
(11, 2, 'V', 'Estudio completo de la función cuadrática', 'https://www.youtube.com/watch?v=9k22Jo_Sjpk', NULL, 5, 0),
(12, 2, 'E', 'Ecuaciones de segundo grado y vértice de la parábola', 'http://todomates.com/actividades/wp-content/uploads/2018/01/Factorizaci%C3%B3n-de-polinomios-Ejercicios.pdf', NULL, 6, 0),
(13, 3, 'T', 'Trigonometría básica y teoremas del seno y del coseno', 'https://exactas.unsj.edu.ar/wp-content/uploads/2017/11/UNIDAD3-MATEMATICA-2018.pdf', NULL, 1, 1),
(14, 3, 'V', 'Resolución de triángulos oblicuángulos y razones trigonométricas', 'https://www.youtube.com/watch?v=aZdJihD0qI8', NULL, 2, 1),
(15, 3, 'E', 'Ejercicios de identidades y razones trigonométricas', 'https://institutoclaret.cl/wp-content/uploads/2020/07/PPT-RACIONALIZACI%C3%93N-MATEM%C3%81TICA-2%C2%B0-MEDIO.pdf', NULL, 3, 0),
(16, 4, 'T', 'Manual de estadística descriptiva y parámetros de posición', 'https://exactas.unsj.edu.ar/wp-content/uploads/2017/11/UNIDAD3-MATEMATICA-2018.pdf', NULL, 1, 0),
(17, 4, 'V', 'Interpretación de gráficos y medidas de tendencia central', 'https://www.youtube.com/watch?v=eUzGnhwqyNk', NULL, 2, 0),
(18, 4, 'E', 'Ejercicios de intervalos y análisis estadístico', 'https://guao.org/sites/default/files/N%C3%BAmeros%20Reales.%20Racionalizaci%C3%B3n.pdf', NULL, 3, 0),
(19, 4, 'T', 'Técnicas de conteo: permutaciones, variaciones y combinaciones', 'https://exactas.unsj.edu.ar/wp-content/uploads/2017/11/UNIDAD3-MATEMATICA-2018.pdf', NULL, 4, 0),
(20, 4, 'V', 'Análisis combinatorio y diagrama de árbol', 'https://www.youtube.com/watch?v=vKA6C9mLz_Q', NULL, 5, 0),
(21, 4, 'E', 'Problemas de probabilidad con combinatoria', 'https://ofimega.es/Manuales/ESO/4eso_polinomios3_factorizar.pdf', NULL, 6, 0),
(22, 5, 'T', 'Apunte teórico sobre teoría de conjuntos y tablas de verdad', 'https://exactas.unsj.edu.ar/wp-content/uploads/2017/11/UNIDAD3-MATEMATICA-2018.pdf', NULL, 1, 0),
(23, 5, 'V', 'Leyes de De Morgan, diagramas de Venn y conectivos', 'https://www.youtube.com/watch?v=vKA6C9mLz_Q', NULL, 2, 0),
(24, 5, 'E', 'Problemas resueltos de conjuntos y lógica', 'https://guao.org/sites/default/files/N%C3%BAmeros%20Reales.%20Racionalizaci%C3%B3n.pdf', NULL, 3, 0),
(25, 6, 'T', 'Manual de álgebra de Boole, sistemas posicionales e inducción completa', 'https://exactas.unsj.edu.ar/wp-content/uploads/2017/11/UNIDAD3-MATEMATICA-2018.pdf', NULL, 1, 0),
(26, 6, 'V', 'Conversión entre sistemas binario, octal y hexadecimal', 'https://www.youtube.com/watch?v=eUzGnhwqyNk', NULL, 2, 0),
(27, 6, 'E', 'Guía práctica de álgebra booleana y demostraciones', 'https://institutoclaret.cl/wp-content/uploads/2020/07/PPT-RACIONALIZACI%C3%93N-MATEM%C3%81TICA-2%C2%B0-MEDIO.pdf', NULL, 3, 0),
(28, 7, 'T', 'Sistemas de numeración, overflow, demostración directa, contraejemplo, inducción y recursividad.', 'https://www.ugr.es/~eaznar/sistemas_representacion_numeros.pdf', NULL, 1, 0),
(29, 7, 'V', 'Conversión entre sistemas de numeración', 'https://www.youtube.com/watch?v=eUzGnhwqyNk', NULL, 2, 0),
(30, 7, 'E', 'Guía práctica de operaciones y demostraciones', 'https://institutoclaret.cl/wp-content/uploads/2020/07/PPT-RACIONALIZACI%C3%93N-MATEM%C3%81TICA-2%C2%B0-MEDIO.pdf', NULL, 3, 0),
(31, 8, 'T', 'Manual de análisis de funciones y sus parámetros', 'https://exactas.unsj.edu.ar/wp-content/uploads/2017/11/UNIDAD3-MATEMATICA-2018.pdf', NULL, 1, 0),
(32, 8, 'V', 'Análisis gráfico y parámetros de funciones', 'https://www.youtube.com/watch?v=aZdJihD0qI8', NULL, 2, 0),
(33, 8, 'E', 'Ejercicios prácticos de funciones y gráficas', 'http://todomates.com/actividades/wp-content/uploads/2018/01/Factorizaci%C3%B3n-de-polinomios-Ejercicios.pdf', NULL, 3, 0),
(35, 9, 'T', 'Números naturales, enteros (ℤ) y racionales (fracciones y decimales); operaciones básicas, propiedades, potenciación, radicación, divisibilidad, múltiplos, divisores, m.c.m. y m.c.d. Módulo 1 de Matemática BNM.', 'https://bnm.educacion.gob.ar/digital/documentos/EL004341.pdf', NULL, 1, 0),
(36, 9, 'V', 'Números: naturales, enteros y racionales (Educ.ar).', 'https://www.educ.ar/recursos/105775/numeros', NULL, 2, 0),
(37, 9, 'E', 'Cuadernillo de Números Enteros (INET).', 'https://www.inet.edu.ar/wp-content/uploads/2020/05/01-01_Nu--meros-enteros.pdf', NULL, 3, 0),
(38, 10, 'T', 'Lenguaje coloquial y simbólico; ecuaciones lineales de primer grado con una incógnita. Iniciación al Álgebra (Educ.ar).', 'https://www.educ.ar/dinamico/UnidadHtml__get__81dfd9c0-7a08-11e1-810f-ed15e3c494af/matematica-algebra1.pdf', NULL, 1, 0),
(39, 10, 'T', 'Introducción al concepto de función, gráficos cartesianos y función lineal. Matemática: Funciones (Educ.ar).', 'https://www.educ.ar/dinamico/UnidadHtml__get__81dfd9c0-7a08-11e1-810f-ed15e3c494af/matematica-funciones.pdf', NULL, 2, 0),
(40, 10, 'V', 'Videos de Educ.ar sobre ecuaciones de primer grado.', 'https://www.educ.ar/buscador?query=ecuaciones%20primer%20grado%20video', NULL, 3, 0),
(41, 10, 'E', 'Proporcionalidad directa e inversa, porcentaje y regla de tres. Lo Proporcional, Parte 2.', 'https://www.igualdadycalidadcba.gov.ar/SIPEC-CBA/Programas/2022/Matematica/Docs/lo-proporcional-parte-2.pdf', NULL, 4, 0),
(42, 11, 'T', 'Clasificación de ángulos y triángulos, suma de ángulos interiores, paralelismo y perpendicularidad. Clase 1 del Módulo III (Entre Ríos Aprende).', 'https://aprender.entrerios.edu.ar/wp-content/uploads/2020/04/Clase-1.-M%C3%B3dulo-3.-Matem%C3%A1tica.pdf', NULL, 1, 0),
(43, 11, 'V', 'Videos y recursos audiovisuales de Educ.ar sobre el Teorema de Pitágoras.', 'https://www.educ.ar/buscador?query=teorema%20de%20Pit%C3%A1goras%20video', NULL, 2, 0),
(44, 11, 'E', 'Teorema de Pitágoras, Parte I: situaciones problemáticas de aplicación.', 'https://hacemosescuela.cba.gov.ar/wp-content/uploads/2023/08/secundaria-matematica-teoremadepitagoras.pdf', NULL, 3, 0),
(45, 9, 'E', 'Guía de Números Enteros: problemas de la vida cotidiana, Escuelas Faro Córdoba.', 'https://www.igualdadycalidadcba.gov.ar/SIPEC-CBA/publicaciones/PNFP/Eje1/EscuelasFARO/2019/PropEns/MatematicaSecundaria-Resolviendoproblemasconn%C3%BAmerosenteros.pdf', NULL, 4, 0),
(46, 10, 'E', 'Módulo 3 de Álgebra BNM, con claves de corrección.', 'https://bnm.educacion.gob.ar/digital/documentos/EL004343.pdf', NULL, 5, 0),
(47, 11, 'E', 'Teorema de Pitágoras, Parte II (Hacemos Escuela).', 'https://hacemosescuela.cba.gov.ar/wp-content/uploads/2023/07/secundaria-matematica-teoremadepitagoras2.pdf', NULL, 4, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

DROP TABLE IF EXISTS `cursos`;
CREATE TABLE IF NOT EXISTS `cursos` (
  `id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `materias` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profesor_id` int DEFAULT NULL,
  `proximo_examen` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tema_examen` text COLLATE utf8mb4_unicode_ci,
  `comunicado_profesora` text COLLATE utf8mb4_unicode_ci,
  `solicitud_acceso` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orden` int DEFAULT '0',
  `drive_url` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profesor_id` (`profesor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`id`, `titulo`, `materias`, `profesor_id`, `proximo_examen`, `tema_examen`, `comunicado_profesora`, `solicitud_acceso`, `orden`, `drive_url`) VALUES
('2cstep', 'SEMA - 2° 1ra TEP', 'Técnico en Programación', 3, '25/11', 'Lógica, funciones y sistemas de numeración.', 'Espacio docente para el seguimiento del aula y control de planificaciones.', 'Lautaro Martínez (Petición de ingreso a 2°1 CSTEP)', 2, 'https://drive.google.com/drive/u/0/folders/1GabOixE9oFZLmbeWdT7jI25Tpu6kkvZn'),
('2gao', 'SEMA - 2° 1ra GAO', 'Gestión y Administración de las Organizaciones', 2, '18/8', 'Números reales, álgebra y funciones.', 'Espacio docente para el seguimiento del aula y control de planificaciones.', NULL, 1, 'https://drive.google.com/drive/u/0/folders/1oQUmZzzZDI9mr8exqcAMGzN-VqywNnHl'),
('cb', 'Ciclo Básico (CB)', 'SEMA - 2° 1ra Ciclo Basico', 15, NULL, NULL, NULL, NULL, 3, 'https://drive.google.com/drive/u/0/folders/1RC-Oc4GtuzMR_2umjihvqyFS9kLhKl1X');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entregas`
--

DROP TABLE IF EXISTS `entregas`;
CREATE TABLE IF NOT EXISTS `entregas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alumno_id` int NOT NULL,
  `capsula_id` int NOT NULL,
  `enlace_drive` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comentario` text COLLATE utf8mb4_unicode_ci,
  `estado` enum('pendiente','visto') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `entregada_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_entrega_alumno_capsula` (`alumno_id`,`capsula_id`),
  KEY `capsula_id` (`capsula_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eventos_calendario`
--

DROP TABLE IF EXISTS `eventos_calendario`;
CREATE TABLE IF NOT EXISTS `eventos_calendario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `curso_id` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date NOT NULL,
  `titulo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `tipo` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'ev-repaso',
  `clase` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'event-12',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_evento_curso_fecha` (`curso_id`,`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `eventos_calendario`
--

INSERT INTO `eventos_calendario` (`id`, `curso_id`, `fecha`, `titulo`, `descripcion`, `tipo`, `clase`) VALUES
(1, '2gao', '2026-10-16', 'Último Recuperatorio', 'Sucederá en el aula común', 'ev-recup', 'event-19'),
(2, '2gao', '2026-10-27', 'Cierre de Notas', 'Carga central de planillas', 'ev-cierre', 'event-27'),
(3, '2cstep', '2026-10-16', 'Último Recuperatorio', 'Sucederá en el aula común', 'ev-recup', 'event-19'),
(4, '2cstep', '2026-10-27', 'Cierre de Notas', 'Carga central de planillas', 'ev-cierre', 'event-27');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `incidencias`
--

DROP TABLE IF EXISTS `incidencias`;
CREATE TABLE IF NOT EXISTS `incidencias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `usuario_nombre` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usuario_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` enum('abierta','en_revision','resuelta') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'abierta',
  `creado_en` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_incidencias_estado_fecha` (`estado`,`creado_en`),
  KEY `usuario_id` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `incidencias`
--

INSERT INTO `incidencias` (`id`, `usuario_id`, `usuario_nombre`, `usuario_email`, `rol`, `categoria`, `descripcion`, `estado`, `creado_en`) VALUES
(1, 3, 'Prof. Jovanovich (TEP)', 'profesor.tep@sema.edu.ar', 'profesor', 'otro', 'Tiempo de Espera muy largo para responder...', 'abierta', '2026-11-06 02:57:32');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs_acceso`
--

DROP TABLE IF EXISTS `logs_acceso`;
CREATE TABLE IF NOT EXISTS `logs_acceso` (
  `id` int NOT NULL AUTO_INCREMENT,
  `usuario_id` int DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `fecha_ingreso` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exitoso` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `idx_logs_usuario_ip` (`username`,`ip`,`exitoso`,`fecha_ingreso`),
  KEY `idx_logs_ip` (`ip`,`exitoso`,`fecha_ingreso`)
) ENGINE=InnoDB AUTO_INCREMENT=240 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `logs_acceso`
--

INSERT INTO `logs_acceso` (`id`, `usuario_id`, `username`, `rol`, `ip`, `user_agent`, `fecha_ingreso`, `exitoso`) VALUES
(1, 1, 'admin', 'admin', '127.0.0.1', 'Instalador Sistema SEMA', '2026-10-09 19:01:39', 1),
(2, NULL, 'dscsdc', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 19:47:49', 0),
(3, NULL, 'dscsdc', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 19:55:48', 0),
(4, NULL, 'Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 19:57:38', 0),
(5, NULL, 'Profe Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 19:57:56', 0),
(6, NULL, 'Profe Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:03:59', 0),
(7, NULL, 'Prof Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:04:16', 0),
(8, NULL, 'Prof Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:04:19', 0),
(9, NULL, 'Prof Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:04:37', 0),
(10, NULL, 'Prof Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:04:44', 0),
(11, NULL, 'Prof. Salinas', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:06:28', 0),
(12, NULL, 'Prof. Salinas', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:06:34', 0),
(13, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:07:01', 0),
(14, NULL, 'dscsdc', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:08:02', 0),
(15, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.140.0 Chrome/150.0.7871.250 Electron/43.7.3 Safari/537.36', '2026-10-09 20:09:40', 1),
(16, NULL, 'P', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:10:51', 0),
(17, NULL, 'Profe Jovanovich', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '2026-10-09 20:11:01', 0),
(18, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:31:38', 1),
(19, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-13 18:33:00', 1),
(20, NULL, 'Prof Sallinas', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-13 18:37:43', 0),
(21, NULL, 'Prof Sallinas', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-13 18:37:47', 0),
(22, NULL, 'Prof Salinas', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-13 18:37:58', 0),
(23, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:39:26', 1),
(24, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:39:42', 1),
(25, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:39:59', 1),
(26, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-13 18:40:46', 1),
(27, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:43:34', 1),
(28, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:44:50', 1),
(29, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:44:50', 1),
(30, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:44:51', 1),
(31, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:51:19', 1),
(32, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:51:49', 1),
(33, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-13 18:53:26', 1),
(34, 4, 'Alumno', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:57:16', 1),
(35, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:58:10', 1),
(36, NULL, 'Alumno Prueba 003', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:59:03', 0),
(37, 4, 'Alumno', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:59:14', 0),
(38, 4, 'Alumno', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:59:16', 0),
(39, 4, 'Alumno', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:59:17', 0),
(40, 4, 'Alumno', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 18:59:19', 0),
(41, 4, 'Alumno', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-13 19:00:10', 0),
(42, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-14 01:33:29', 1),
(43, NULL, 'sema.alumno.009@example.invalid', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 01:41:51', 0),
(48, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-14 01:58:52', 1),
(49, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-14 01:59:31', 1),
(50, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-14 01:59:59', 1),
(51, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-14 02:00:25', 1),
(52, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:00:48', 1),
(53, NULL, 'dscsdc', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-14 02:05:17', 0),
(54, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:05:49', 1),
(55, NULL, 'Alumno Prueba 009', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:07:22', 1),
(56, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:08:50', 1),
(58, NULL, 'Alumno Prueba 003', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:12:14', 0),
(59, NULL, 'GAO-PRUEBA-009 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:13:53', 1),
(61, NULL, 'Alumno Prueba 011', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:18:50', 1),
(62, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:21:09', 1),
(63, NULL, 'Alumno Prueba 011', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.1 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-14 02:21:34', 1),
(64, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-15 13:18:57', 1),
(65, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 13:19:58', 1),
(66, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.141.2 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-15 13:23:25', 1),
(67, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 13:24:20', 1),
(68, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 13:26:03', 1),
(69, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 13:30:08', 1),
(70, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 13:47:42', 1),
(71, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 13:49:35', 1),
(72, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 15:06:38', 0),
(73, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 15:06:40', 1),
(74, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 15:08:02', 1),
(75, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 15:08:44', 1),
(76, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 15:08:57', 1),
(77, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 17:19:07', 1),
(78, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 17:19:45', 1),
(79, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 20:39:09', 1),
(80, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 20:56:05', 1),
(81, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-15 20:57:39', 1),
(83, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; es-AR) WindowsPowerShell/5.1.22000.282', '2026-10-15 21:06:32', 1),
(84, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.142.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-15 21:10:25', 1),
(87, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.142.0 Chrome/150.0.7871.250 Electron/43.7.7 Safari/537.36', '2026-10-15 21:16:21', 1),
(88, NULL, 'fokus', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:20:24', 0),
(89, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:20:30', 1),
(90, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:21:13', 1),
(91, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:21:48', 1),
(92, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:22:03', 1),
(93, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:22:09', 1),
(94, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:52:28', 1),
(95, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:54:06', 1),
(96, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:54:39', 0),
(97, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 00:54:41', 1),
(98, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:01:24', 0),
(99, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:01:28', 0),
(100, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:01:29', 0),
(101, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:01:32', 1),
(102, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:04:52', 1),
(103, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:18:08', 1),
(104, NULL, 'docentecb', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:39:57', 0),
(105, NULL, 'docenteCB', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:40:16', 0),
(106, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:42:34', 0),
(107, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:42:39', 0),
(108, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:42:42', 0),
(109, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:42:45', 0),
(110, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:42:48', 0),
(111, 1, 'admin', 'admin', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:42:51', 1),
(112, NULL, 'docenteCB', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:45:22', 0),
(113, NULL, 'docenteCB', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:45:25', 0),
(114, NULL, 'docenteCB', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:45:27', 0),
(115, NULL, 'docenteCB', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:45:29', 0),
(116, NULL, 'docenteCB', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:45:30', 0),
(117, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:45:49', 1),
(118, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:47:09', 1),
(119, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-19 01:49:13', 1),
(120, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:35:09', 1),
(121, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:37:06', 1),
(122, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:37:41', 0),
(123, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:37:43', 1),
(124, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:42:22', 1),
(125, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:49:27', 0),
(126, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:49:29', 1),
(127, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 13:54:20', 1),
(128, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 14:01:04', 1),
(129, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 14:01:34', 1),
(130, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 14:02:03', 1),
(131, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-23 14:02:42', 1),
(132, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 10:48:25', 1),
(133, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 10:48:37', 0),
(134, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 10:48:40', 1),
(135, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 11:04:52', 0),
(136, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 11:04:55', 1),
(137, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 11:05:14', 1),
(138, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 11:26:21', 1),
(139, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 12:54:51', 1),
(140, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 12:57:48', 1),
(141, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 12:58:33', 1),
(142, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 17:29:25', 1),
(143, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 17:49:32', 1),
(144, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 18:23:28', 1),
(145, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 18:36:02', 1),
(146, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 18:51:50', 1),
(147, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:13:57', 1),
(148, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:15:43', 0),
(149, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:15:45', 1),
(150, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:24:55', 1),
(151, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:25:11', 1),
(152, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:25:23', 1),
(153, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:29:37', 1),
(154, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 19:29:50', 1),
(155, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:04:35', 1),
(156, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:07:48', 1),
(157, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:07:58', 1),
(158, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:08:08', 0),
(159, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:08:09', 1),
(160, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:43:16', 1),
(161, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:44:41', 1),
(162, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:45:35', 1),
(163, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:54:56', 1),
(164, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 20:55:13', 1),
(165, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:19:19', 1),
(166, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:19:34', 1),
(167, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:20:58', 1),
(168, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:21:20', 1),
(169, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:31:20', 1),
(170, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:36:26', 1),
(171, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:36:51', 1),
(172, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:39:33', 1),
(173, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:40:01', 1),
(174, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:43:27', 1),
(175, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:45:03', 1),
(176, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:47:31', 1),
(177, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:47:59', 1),
(178, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:57:44', 1),
(179, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 21:58:19', 1),
(180, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 22:02:05', 1),
(181, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-10-30 22:14:04', 1),
(182, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 22:03:27', 1),
(183, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 22:04:24', 1),
(184, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 22:30:31', 1),
(185, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 22:45:58', 1),
(186, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 22:47:12', 1),
(187, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:07:17', 1),
(188, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:09:29', 0),
(189, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:09:31', 0),
(190, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:09:49', 1),
(191, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:14:12', 1),
(192, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:14:50', 1),
(193, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:20:37', 1),
(194, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:33:00', 1),
(195, 16, 'Alumno Prueba 006', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:36:30', 1),
(196, 16, 'Alumno Prueba 006', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:37:02', 1),
(197, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:37:27', 1),
(198, NULL, 'cb.prueba.004@example.invalid', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:39:38', 0),
(199, NULL, 'cb.prueba.004@example.invalid', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:39:40', 0),
(200, NULL, 'cb.prueba.004@example.invalid', 'desconocido', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:39:42', 0),
(201, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:40:50', 1),
(202, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:41:30', 0),
(203, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:42:01', 0),
(204, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:42:11', 1),
(205, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:42:55', 0),
(206, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:42:57', 1),
(207, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:43:37', 0),
(208, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:43:44', 0),
(209, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:43:56', 0),
(210, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:44:14', 0),
(211, 18, 'GAO-PRUEBA-026 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:46:21', 1),
(212, 19, 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:47:57', 1),
(213, 19, 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:50:41', 1),
(214, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:53:57', 1),
(215, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:54:29', 0),
(216, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:54:35', 0),
(217, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:54:53', 1),
(218, 19, 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-01 23:55:27', 1),
(219, 20, 'CB-PRUEBA-003 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:09:32', 1),
(220, 19, 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:10:15', 1),
(221, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:12:12', 1),
(222, 19, 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:12:49', 1),
(223, 19, 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:15:55', 1),
(224, 17, 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:16:19', 1),
(225, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:17:35', 1),
(226, 2, 'docente', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 00:18:02', 1),
(227, 12, 'Alumno Prueba 001', 'alumno', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 21:37:10', 1),
(228, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 21:44:28', 0),
(229, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-02 21:44:47', 1),
(230, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 01:55:19', 0),
(231, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 01:55:24', 0),
(232, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 01:55:41', 0),
(233, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 01:55:51', 1),
(234, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 02:10:24', 1),
(235, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 02:12:18', 0),
(236, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 02:13:06', 1),
(237, 15, 'ProfesorCB', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 02:13:49', 1),
(238, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Code/1.144.1 Chrome/150.0.7871.250 Electron/43.8.3 Safari/537.36', '2026-11-06 02:14:12', 1),
(239, 3, 'docente_cstep', 'profesor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36', '2026-11-06 02:57:07', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `progreso_capsulas`
--

DROP TABLE IF EXISTS `progreso_capsulas`;
CREATE TABLE IF NOT EXISTS `progreso_capsulas` (
  `alumno_id` int NOT NULL,
  `capsula_id` int NOT NULL,
  `completada` tinyint(1) NOT NULL DEFAULT '0',
  `completada_en` datetime DEFAULT NULL,
  PRIMARY KEY (`alumno_id`,`capsula_id`),
  KEY `capsula_id` (`capsula_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidades`
--

DROP TABLE IF EXISTS `unidades`;
CREATE TABLE IF NOT EXISTS `unidades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `curso_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `orden` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `curso_id` (`curso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `unidades`
--

INSERT INTO `unidades` (`id`, `curso_id`, `nombre`, `orden`) VALUES
(1, '2gao', 'Unidad I: Números reales, complejos y radicación', 1),
(2, '2gao', 'Unidad II: Polinomios y función cuadrática', 2),
(3, '2gao', 'Unidad III: Trigonometría y sistemas de ecuaciones', 3),
(4, '2gao', 'Unidad IV: Estadística, probabilidad y combinatoria', 4),
(5, '2cstep', 'Unidad I: Conjuntos, lógica y lenguajes formales', 1),
(6, '2cstep', 'Unidad II: Circuitos digitales y álgebra de Boole', 2),
(7, '2cstep', 'Unidad III: Sistemas de numeración y demostración matemática', 3),
(8, '2cstep', 'Unidad IV: Funciones, curvas y geometría analítica', 4),
(9, 'cb', 'Números y Operaciones', 1),
(10, 'cb', 'Álgebra y Funciones', 2),
(11, 'cb', 'Geometría y Medida', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_completo` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rol` enum('admin','profesor','alumno') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'alumno',
  `orden` int DEFAULT '0',
  `activo` tinyint(1) DEFAULT '1',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `terms_accepted_at` datetime DEFAULT NULL,
  `terms_version` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Fecha_de_Nacimiento` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `email`, `password_hash`, `nombre_completo`, `rol`, `orden`, `activo`, `creado_en`, `terms_accepted_at`, `terms_version`, `Fecha_de_Nacimiento`) VALUES
(1, 'admin', 'admin@sema.edu.ar', '$2y$10$xZsEpEMlrWJW07A6p5t8u.wm/Ji0j/O4fTzkWylEmHjnNIDjP3xkO', 'Administrador General SEMA', 'admin', 1, 1, '2026-10-09 19:01:39', NULL, NULL, NULL),
(2, 'docente', 'docente@sema.edu.ar', '$2y$10$xqmZnms3kWL3gUzOcawYYu09kxOxPWTSzXOdj3dkrYa0ixuBFHpUq', 'Prof. Franco (GAO)', 'profesor', 2, 1, '2026-10-09 19:01:39', NULL, NULL, '2026-11-12'),
(3, 'docente_cstep', 'profesor.tep@sema.edu.ar', '$2y$10$xqmZnms3kWL3gUzOcawYYu09kxOxPWTSzXOdj3dkrYa0ixuBFHpUq', 'Prof. Jovanovich (TEP)', 'profesor', 3, 1, '2026-10-09 19:01:39', NULL, NULL, '1975-03-12'),
(4, 'Alumno', 'sema.alumno.003@example.invalid', '$2y$10$Dx0IgVT58xMjEpsezeBvRewWWCo.A9o48aQe5NMDNGe9RnE1lcHLa', 'Alumno Prueba 003', 'alumno', 0, 1, '2026-10-13 18:57:16', '2026-10-13 15:57:16', '1.0', NULL),
(12, 'Alumno Prueba 001', 'sema.alumno.001@example.invalid', '$2y$10$4RIN0j8vUlTs31VlZsRm0u6wjGjP2DTxJTSy6zI.UMHEoFrzhZ6/u', 'Alumno Prueba 001', 'alumno', 0, 1, '2026-10-15 15:08:02', '2026-10-15 12:08:02', '1.0', '2009-04-09'),
(15, 'ProfesorCB', 'ProfesorCicloBasico@gmail.com', '$2y$10$ZGp9XCUAJlnhmzxBA4ccmuuaRkn4xw9gkLkcGz3lexL2ydihjqvNi', 'Prof. Sallinas (CB)', 'profesor', 4, 1, '2026-10-19 01:44:58', NULL, NULL, '2026-11-01'),
(16, 'Alumno Prueba 006', 'sema.alumno.006@example.invalid', '$2y$10$XYNwlxyXP.GTGsYG2SSfkuo6QkOFe6yVnPKM7SKjKWVrth4J20Mgy', 'Alumno Prueba 006', 'alumno', 0, 1, '2026-11-01 23:36:30', '2026-11-01 20:36:30', '1.0', '2009-06-30'),
(17, 'GAO-PRUEBA-025 Alumno Ficticio', 'gao.prueba.025@example.invalid', '$2y$10$1h88Y0.ZpFf4GZArjtvKE.vR1U0BSN9NHwmsLXrZenHMmInm7BDOC', 'GAO-PRUEBA-025 Alumno Ficticio', 'alumno', 0, 1, '2026-11-01 23:40:50', '2026-11-01 20:40:50', '1.0', '2009-06-07'),
(18, 'GAO-PRUEBA-026 Alumno Ficticio', 'gao.prueba.026@example.invalid', '$2y$10$ir.2k8mEELdx4f8/sG./5.MhReECOdelBqgQp/EhMQUtDi4Iv/Bm.', 'GAO-PRUEBA-026 Alumno Ficticio', 'alumno', 0, 1, '2026-11-01 23:46:21', '2026-11-01 20:46:21', '1.0', '2009-09-12'),
(19, 'CB-PRUEBA-004 Alumno Ficticio', 'cb.prueba.004@example.invalid', '$2y$10$y8EQSMrBIFM4VUeaWnIoFu/RscsgtsRY61E0aLqts1we2ce4u0Uq.', 'CB-PRUEBA-004 Alumno Ficticio', 'alumno', 0, 1, '2026-11-01 23:47:57', '2026-11-01 20:47:57', '1.0', '2012-05-03'),
(20, 'CB-PRUEBA-003 Alumno Ficticio', 'cb.prueba.003@example.invalid', '$2y$10$vJrrfS0BqvCVNF7TdE9on.e07ubQFWj5AgE8lfp864YUN6LH4CUbS', 'CB-PRUEBA-003 Alumno Ficticio', 'alumno', 0, 1, '2026-11-02 00:09:32', '2026-11-01 21:09:32', '1.0', '2012-12-09');

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD CONSTRAINT `alumnos_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `alumnos_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `capsulas`
--
ALTER TABLE `capsulas`
  ADD CONSTRAINT `capsulas_ibfk_1` FOREIGN KEY (`unidad_id`) REFERENCES `unidades` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD CONSTRAINT `cursos_ibfk_1` FOREIGN KEY (`profesor_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `entregas`
--
ALTER TABLE `entregas`
  ADD CONSTRAINT `entregas_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `entregas_ibfk_2` FOREIGN KEY (`capsula_id`) REFERENCES `capsulas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `eventos_calendario`
--
ALTER TABLE `eventos_calendario`
  ADD CONSTRAINT `eventos_calendario_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `incidencias`
--
ALTER TABLE `incidencias`
  ADD CONSTRAINT `incidencias_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `logs_acceso`
--
ALTER TABLE `logs_acceso`
  ADD CONSTRAINT `logs_acceso_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL;

--
-- Filtros para la tabla `progreso_capsulas`
--
ALTER TABLE `progreso_capsulas`
  ADD CONSTRAINT `progreso_capsulas_ibfk_1` FOREIGN KEY (`alumno_id`) REFERENCES `alumnos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `progreso_capsulas_ibfk_2` FOREIGN KEY (`capsula_id`) REFERENCES `capsulas` (`id`) ON DELETE CASCADE;

--
-- Filtros para la tabla `unidades`
--
ALTER TABLE `unidades`
  ADD CONSTRAINT `unidades_ibfk_1` FOREIGN KEY (`curso_id`) REFERENCES `cursos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
