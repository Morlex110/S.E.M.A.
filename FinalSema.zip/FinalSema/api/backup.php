<?php
/**
 * API y Generador de Backup Semanal / Manual de Base de Datos
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAdmin();
$pdo = getPDO();

$action = $_GET['action'] ?? 'download';

if ($action === 'check') {
    header('Content-Type: application/json; charset=utf-8');
    $tables = ['usuarios', 'cursos', 'unidades', 'capsulas', 'alumnos', 'eventos_calendario', 'logs_acceso', 'progreso_capsulas', 'entregas', 'incidencias'];
    $counts = [];
    foreach ($tables as $t) {
        $counts[$t] = (int)$pdo->query("SELECT COUNT(*) FROM `{$t}`")->fetchColumn();
    }
    echo json_encode([
        'success' => true,
        'database' => DB_NAME,
        'counts' => $counts,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit;
}

// Acción por defecto: generar y descargar volcado .sql completo
$fechaStr = date('Y-m-d_His');
$filename = "backup_sema_db_{$fechaStr}.sql";

header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

$tables = ['usuarios', 'cursos', 'unidades', 'capsulas', 'alumnos', 'eventos_calendario', 'logs_acceso', 'progreso_capsulas', 'entregas', 'incidencias'];

echo "-- ========================================================\n";
echo "-- SISTEMA SEMA - COLEGIO DE EDUCACIÓN TÉCNICA SECUNDARIA\n";
echo "-- RESPALDO OFICIAL DE BASE DE DATOS: " . DB_NAME . "\n";
echo "-- FECHA DE EMISIÓN: " . date('Y-m-d H:i:s') . "\n";
echo "-- GENERADO POR: " . htmlspecialchars(obtenerUsuarioActual()['nombre_completo'] ?? 'Admin') . "\n";
echo "-- ========================================================\n\n";
echo "SET NAMES utf8mb4;\n";
echo "SET FOREIGN_KEY_CHECKS = 0;\n\n";

foreach ($tables as $table) {
    echo "-- --------------------------------------------------------\n";
    echo "-- Estructura de tabla: `{$table}`\n";
    echo "-- --------------------------------------------------------\n";
    echo "DROP TABLE IF EXISTS `{$table}`;\n";

    $createTableStmt = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch();
    echo $createTableStmt['Create Table'] . ";\n\n";

    echo "-- Volcado de datos para `{$table}`\n";
    $rows = $pdo->query("SELECT * FROM `{$table}`")->fetchAll();

    if (!empty($rows)) {
        foreach ($rows as $row) {
            $cols = array_keys($row);
            $colNames = implode('`, `', $cols);
            
            $vals = [];
            foreach ($row as $val) {
                if ($val === null) {
                    $vals[] = "NULL";
                } else {
                    $vals[] = $pdo->quote((string)$val);
                }
            }
            $valStr = implode(', ', $vals);
            echo "INSERT INTO `{$table}` (`{$colNames}`) VALUES ({$valStr});\n";
        }
    } else {
        echo "-- (No hay registros para la tabla `{$table}`)\n";
    }
    echo "\n";
}

echo "SET FOREIGN_KEY_CHECKS = 1;\n";
echo "-- Fin del respaldo.\n";
exit;
