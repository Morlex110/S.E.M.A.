<?php
/** Descarga de materiales con verificación de sesión y permisos del curso. */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAutenticacion();
$pdo = getPDO();
$usuario = obtenerUsuarioActual();
$nombre = (string)($_GET['nombre'] ?? '');
$extensionesPermitidas = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'jpg', 'jpeg', 'png', 'mp4', 'zip'];

if (!preg_match('/^\d+_[a-zA-Z0-9_-]*\.([a-zA-Z0-9]+)$/D', $nombre, $coincidencia)
    || !in_array(strtolower($coincidencia[1]), $extensionesPermitidas, true)) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'Nombre de archivo no válido.']);
    exit;
}

$stmt = $pdo->prepare('SELECT u.curso_id FROM capsulas cap JOIN unidades u ON u.id = cap.unidad_id WHERE cap.archivo = ? LIMIT 1');
$stmt->execute([$nombre]);
$cursoId = $stmt->fetchColumn();
if (!$cursoId) {
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'No se encontró el material.']);
    exit;
}

if (($usuario['rol'] ?? '') === 'alumno') {
    $permiso = $pdo->prepare('SELECT 1 FROM alumnos WHERE usuario_id = ? AND curso_id = ? AND activo = 1 LIMIT 1');
    $permiso->execute([(int)$usuario['id'], (string)$cursoId]);
    $autorizado = (bool)$permiso->fetchColumn();
} else {
    $autorizado = puedeGestionarCurso($pdo, (string)$cursoId, $usuario);
}
if (!$autorizado) {
    http_response_code(403);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'No tenés permiso para acceder a este material.']);
    exit;
}

$directorio = realpath(dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads');
$rutaArchivo = $directorio ? realpath($directorio . DIRECTORY_SEPARATOR . $nombre) : false;
if (!$directorio || !$rutaArchivo || !str_starts_with($rutaArchivo, $directorio . DIRECTORY_SEPARATOR) || !is_file($rutaArchivo)) {
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'No se encontró el material.']);
    exit;
}

$extension = strtolower(pathinfo($rutaArchivo, PATHINFO_EXTENSION));
$tiposMime = [
    'pdf' => 'application/pdf',
    'doc' => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'ppt' => 'application/vnd.ms-powerpoint',
    'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'xls' => 'application/vnd.ms-excel',
    'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'txt' => 'text/plain; charset=utf-8',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'mp4' => 'video/mp4',
    'zip' => 'application/zip'
];
$disposicion = in_array($extension, ['pdf', 'txt', 'jpg', 'jpeg', 'png', 'mp4'], true) ? 'inline' : 'attachment';

header('Content-Type: ' . $tiposMime[$extension]);
header('Content-Disposition: ' . $disposicion . '; filename="' . $nombre . '"');
header('Content-Length: ' . filesize($rutaArchivo));
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($rutaArchivo);