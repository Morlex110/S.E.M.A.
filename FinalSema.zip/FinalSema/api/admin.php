<?php
/**
 * API de Administración General (Logs de auditoría, gestión manual de usuarios, asignación de cursos)
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAdmin();
$pdo = getPDO();

$action = $_GET['action'] ?? ($_POST['action'] ?? 'logs');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputRaw = file_get_contents('php://input');
    $inputJson = json_decode($inputRaw, true);
    if (is_array($inputJson)) {
        $_POST = array_merge($_POST, $inputJson);
    }
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
    }
}

switch ($action) {
    case 'incidents':
        $limite = max(10, min(500, (int)($_GET['limit'] ?? 200)));
        $stmt = $pdo->query("SELECT id, usuario_nombre, usuario_email, rol, categoria, descripcion, estado, creado_en FROM incidencias ORDER BY FIELD(estado, 'abierta', 'en_revision', 'resuelta'), creado_en DESC LIMIT {$limite}");
        echo json_encode(['success' => true, 'incidencias' => $stmt->fetchAll()]);
        break;

    case 'update_incident_status':
        $incidenciaId = (int)($_POST['id'] ?? 0);
        $estado = trim((string)($_POST['estado'] ?? ''));
        if ($incidenciaId <= 0 || !in_array($estado, ['abierta', 'en_revision', 'resuelta'], true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Reporte o estado no válido.']);
            exit;
        }
        $upd = $pdo->prepare('UPDATE incidencias SET estado = ? WHERE id = ?');
        $upd->execute([$estado, $incidenciaId]);
        if ($upd->rowCount() === 0) {
            $existe = $pdo->prepare('SELECT 1 FROM incidencias WHERE id = ?');
            $existe->execute([$incidenciaId]);
            if (!$existe->fetchColumn()) {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'No se encontró el reporte.']);
                exit;
            }
        }
        echo json_encode(['success' => true, 'message' => 'Estado del reporte actualizado.']);
        break;

    case 'logs':
        $limite = (int)($_GET['limit'] ?? 100);
        $limite = max(10, min(500, $limite));

        $stmt = $pdo->query("SELECT * FROM logs_acceso ORDER BY fecha_ingreso DESC LIMIT {$limite}");
        $logs = $stmt->fetchAll();

        echo json_encode([
            'success' => true,
            'logs' => array_map(function($l) {
                return [
                    'id' => (int)$l['id'],
                    'usuario_id' => $l['usuario_id'],
                    'username' => $l['username'],
                    'rol' => $l['rol'],
                    'ip' => $l['ip'],
                    'user_agent' => $l['user_agent'],
                    'fecha_ingreso' => $l['fecha_ingreso'],
                    'exitoso' => (int)$l['exitoso']
                ];
            }, $logs)
        ]);
        break;

    case 'users':
        $stmt = $pdo->query("
            SELECT u.id, u.username, u.email, u.nombre_completo, u.rol, u.orden, u.activo, u.creado_en,
                   GROUP_CONCAT(c.id SEPARATOR ', ') AS cursos_asignados,
                   GROUP_CONCAT(c.titulo SEPARATOR ' | ') AS titulos_cursos
            FROM usuarios u
            LEFT JOIN cursos c ON c.profesor_id = u.id
            GROUP BY u.id
            ORDER BY u.orden ASC, u.id ASC
        ");
        $users = $stmt->fetchAll();

        // Obtener cursos para selector
        $cStmt = $pdo->query("SELECT id, titulo, profesor_id FROM cursos ORDER BY orden ASC");
        $cursos = $cStmt->fetchAll();

        echo json_encode([
            'success' => true,
            'users' => $users,
            'cursos' => $cursos
        ]);
        break;

    case 'create_user':
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $nombreCompleto = trim($_POST['nombre_completo'] ?? '');
        $rol = trim($_POST['rol'] ?? 'profesor');
        $cursoId = trim($_POST['curso_id'] ?? '');

        if (!in_array($rol, ['admin', 'profesor', 'alumno'], true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Rol de usuario no válido.']);
            exit;
        }

        if ($username === '' || $email === '' || $password === '' || $nombreCompleto === '') {
            echo json_encode(['success' => false, 'message' => 'Complete todos los campos obligatorios.']);
            exit;
        }
        if (strlen($password) < 12 || strlen($password) > 72) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'La contraseña debe tener entre 12 y 72 caracteres.']);
            exit;
        }

        $check = $pdo->prepare("SELECT id FROM usuarios WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            echo json_encode(['success' => false, 'message' => 'El usuario o email ya se encuentra registrado.']);
            exit;
        }

        $ordStmt = $pdo->query("SELECT COALESCE(MAX(orden), 0) + 1 FROM usuarios");
        $proxOrden = (int)$ordStmt->fetchColumn();

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $ins = $pdo->prepare("
            INSERT INTO usuarios (username, email, password_hash, nombre_completo, rol, orden, activo)
            VALUES (?, ?, ?, ?, ?, ?, 1)
        ");
        $ins->execute([$username, $email, $hash, $nombreCompleto, $rol, $proxOrden]);
        $newUserId = (int)$pdo->lastInsertId();

        // Si se seleccionó curso y el rol es profesor, asignarlo
        if ($rol === 'profesor' && $cursoId !== '') {
            $updCurso = $pdo->prepare("UPDATE cursos SET profesor_id = ? WHERE id = ?");
            $updCurso->execute([$newUserId, $cursoId]);
        }

        echo json_encode(['success' => true, 'message' => 'Usuario creado exitosamente.']);
        break;

    case 'update_user':
        $id = (int)($_POST['id'] ?? 0);
        $nombreCompleto = trim($_POST['nombre_completo'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $rol = trim($_POST['rol'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $activo = isset($_POST['activo']) ? (int)$_POST['activo'] : 1;
        $cursoId = trim($_POST['curso_id'] ?? '');

        if (!in_array($rol, ['admin', 'profesor', 'alumno'], true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Rol de usuario no válido.']);
            exit;
        }

        if ($id <= 0) {
            echo json_encode(['success' => false, 'message' => 'ID inválido.']);
            exit;
        }

        if ($password !== '') {
            if (strlen($password) < 12 || strlen($password) > 72) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'La nueva contraseña debe tener entre 12 y 72 caracteres.']);
                exit;
            }
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $upd = $pdo->prepare("UPDATE usuarios SET nombre_completo = ?, email = ?, rol = ?, password_hash = ?, activo = ? WHERE id = ?");
            $upd->execute([$nombreCompleto, $email, $rol, $hash, $activo, $id]);
        } else {
            $upd = $pdo->prepare("UPDATE usuarios SET nombre_completo = ?, email = ?, rol = ?, activo = ? WHERE id = ?");
            $upd->execute([$nombreCompleto, $email, $rol, $activo, $id]);
        }

        // Asignación de curso
        if ($rol === 'profesor') {
            // Desvincular de otros si correspondiera o vincular al nuevo
            if ($cursoId !== '') {
                $updC = $pdo->prepare("UPDATE cursos SET profesor_id = ? WHERE id = ?");
                $updC->execute([$id, $cursoId]);
            }
        }

        echo json_encode(['success' => true, 'message' => 'Usuario actualizado con éxito.']);
        break;

    case 'reorder_users':
        $ordenes = $_POST['ordenes'] ?? []; // Array de [id => orden]
        if (is_array($ordenes)) {
            $stmt = $pdo->prepare("UPDATE usuarios SET orden = ? WHERE id = ?");
            foreach ($ordenes as $uid => $ord) {
                $stmt->execute([(int)$ord, (int)$uid]);
            }
        }
        echo json_encode(['success' => true, 'message' => 'Orden de usuarios actualizado.']);
        break;

    case 'set_user_role':
        $userId = (int)($_POST['id'] ?? 0);
        $rol = trim($_POST['rol'] ?? '');
        if ($userId <= 0 || !in_array($rol, ['admin', 'profesor', 'alumno'], true)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Usuario o rol no válidos.']);
            exit;
        }
        $targetAdmin = $pdo->prepare("SELECT rol, activo FROM usuarios WHERE id = ?");
        $targetAdmin->execute([$userId]);
        $target = $targetAdmin->fetch();
        if (!$target) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'No se encontró el usuario.']);
            exit;
        }
        if ($rol !== 'admin') {
            $adminsActivos = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol = 'admin' AND activo = 1")->fetchColumn();
            if ($target['rol'] === 'admin' && (int)$target['activo'] === 1 && $adminsActivos <= 1) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'No se puede quitar el último administrador activo.']);
                exit;
            }
        }

        $pdo->beginTransaction();
        try {
            $upd = $pdo->prepare('UPDATE usuarios SET rol = ? WHERE id = ?');
            $upd->execute([$rol, $userId]);
            if ($rol !== 'profesor') {
                $pdo->prepare('UPDATE cursos SET profesor_id = NULL WHERE profesor_id = ?')->execute([$userId]);
            }
            if ($rol !== 'alumno') {
                $pdo->prepare('UPDATE alumnos SET usuario_id = NULL WHERE usuario_id = ?')->execute([$userId]);
            }
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'El rol y sus asignaciones quedaron actualizados.']);
        } catch (Throwable $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'No se pudo actualizar el rol.']);
        }
        break;

    case 'set_teacher_courses':
        $userId = (int)($_POST['id'] ?? 0);
        $courseIds = $_POST['curso_ids'] ?? [];
        if ($userId <= 0 || !is_array($courseIds) || count($courseIds) > 100) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Usuario o lista de cursos no válidos.']);
            exit;
        }
        $teacherStmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ? AND rol = 'profesor' AND activo = 1");
        $teacherStmt->execute([$userId]);
        if (!$teacherStmt->fetchColumn()) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Solo se pueden asignar cursos a docentes activos.']);
            exit;
        }
        $courseIds = array_values(array_unique(array_filter(array_map('strval', $courseIds), function($id) { return $id !== ''; })));
        foreach ($courseIds as $courseId) {
            $exists = $pdo->prepare('SELECT 1 FROM cursos WHERE id = ?');
            $exists->execute([$courseId]);
            if (!$exists->fetchColumn()) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'La lista contiene un curso inexistente.']);
                exit;
            }
        }
        $pdo->beginTransaction();
        try {
            $pdo->prepare('UPDATE cursos SET profesor_id = NULL WHERE profesor_id = ?')->execute([$userId]);
            $assign = $pdo->prepare('UPDATE cursos SET profesor_id = ? WHERE id = ?');
            foreach ($courseIds as $courseId) $assign->execute([$userId, $courseId]);
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Los cursos asignados al docente quedaron actualizados.']);
        } catch (Throwable $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'No se pudieron guardar los cursos.']);
        }
        break;

    case 'students_registry':
        // Registro global de alumnos con desglose de activos e inactivos (dados de baja)
        $stmt = $pdo->query("
            SELECT a.*, c.titulo AS nombre_curso
            FROM alumnos a
            JOIN cursos c ON a.curso_id = c.id
            ORDER BY c.orden ASC, a.activo DESC, a.n_orden ASC
        ");
        $alumnos = $stmt->fetchAll();
        $cuentasAlumno = $pdo->query("SELECT id, username, nombre_completo, email FROM usuarios WHERE rol = 'alumno' AND activo = 1 ORDER BY nombre_completo ASC")->fetchAll();

        echo json_encode([
            'success' => true,
            'cuentas_alumno' => array_map(function($u) {
                return ['id' => (int)$u['id'], 'username' => $u['username'], 'nombre_completo' => $u['nombre_completo'], 'email' => $u['email']];
            }, $cuentasAlumno),
            'alumnos' => array_map(function($al) {
                return [
                    'id' => (int)$al['id'],
                    'usuario_id' => $al['usuario_id'] === null ? null : (int)$al['usuario_id'],
                    'curso_id' => $al['curso_id'],
                    'nombre_curso' => $al['nombre_curso'],
                    'n' => (int)$al['n_orden'],
                    'corto' => $al['corto'],
                    'completo' => $al['completo'],
                    'dni' => $al['dni'] ?? '',
                    'email' => $al['email'],
                    'nota' => (float)$al['nota'],
                    'condicion' => $al['condicion'],
                    'progreso' => (int)$al['progreso'],
                    'activo' => (int)$al['activo'],
                    'fecha_baja' => $al['fecha_baja']
                ];
            }, $alumnos)
        ]);
        break;

    case 'link_student':
        $alumnoId = (int)($_POST['alumno_id'] ?? 0);
        $usuarioId = isset($_POST['usuario_id']) && $_POST['usuario_id'] !== '' ? (int)$_POST['usuario_id'] : null;
        if ($alumnoId <= 0 || ($usuarioId !== null && $usuarioId <= 0)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Alumno o cuenta no válidos.']);
            exit;
        }

        $alumnoStmt = $pdo->prepare('SELECT id FROM alumnos WHERE id = ?');
        $alumnoStmt->execute([$alumnoId]);
        if (!$alumnoStmt->fetchColumn()) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'No se encontró la ficha del alumno.']);
            exit;
        }

        if ($usuarioId !== null) {
            $cuentaStmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ? AND rol = 'alumno' AND activo = 1");
            $cuentaStmt->execute([$usuarioId]);
            if (!$cuentaStmt->fetchColumn()) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'La cuenta seleccionada no es un alumno activo.']);
                exit;
            }
            $usoStmt = $pdo->prepare('SELECT id FROM alumnos WHERE usuario_id = ? AND id <> ? LIMIT 1');
            $usoStmt->execute([$usuarioId, $alumnoId]);
            if ($usoStmt->fetchColumn()) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'Esta cuenta ya está vinculada a otra ficha.']);
                exit;
            }
        }

        $linkStmt = $pdo->prepare('UPDATE alumnos SET usuario_id = ? WHERE id = ?');
        $linkStmt->execute([$usuarioId, $alumnoId]);
        echo json_encode(['success' => true, 'message' => $usuarioId === null ? 'Se quitó la vinculación.' : 'La cuenta quedó vinculada al alumno.']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción no válida en administración.']);
        break;
}
