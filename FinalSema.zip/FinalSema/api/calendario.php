<?php
/**
 * API de Gestión del Calendario Académico y Alertas
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAutenticacion();
$pdo = getPDO();
$usuario = obtenerUsuarioActual();

$action = $_GET['action'] ?? ($_POST['action'] ?? 'list');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputRaw = file_get_contents('php://input');
    $inputJson = json_decode($inputRaw, true);
    if (is_array($inputJson)) {
        $_POST = array_merge($_POST, $inputJson);
    }
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
    }
}

switch ($action) {
    case 'list':
        $cursoId = trim($_GET['curso_id'] ?? '');
        if ($cursoId !== '' && !esAdmin()) {
            if (esAlumno()) {
                $alumnoStmt = $pdo->prepare('SELECT 1 FROM alumnos WHERE usuario_id = ? AND curso_id = ? AND activo = 1 LIMIT 1');
                $alumnoStmt->execute([(int)$usuario['id'], $cursoId]);
                if (!$alumnoStmt->fetchColumn()) {
                    http_response_code(403);
                    echo json_encode(['success' => false, 'error' => 'No tiene acceso a este curso.']);
                    exit;
                }
            } elseif (!puedeGestionarCurso($pdo, $cursoId, $usuario)) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'No tiene acceso a este curso.']);
                exit;
            }
        }
        if ($cursoId !== '') {
            $stmt = $pdo->prepare('SELECT * FROM eventos_calendario WHERE curso_id IS NULL OR curso_id = ? ORDER BY fecha ASC, curso_id IS NULL DESC');
            $stmt->execute([$cursoId]);
        } elseif (esAdmin()) {
            $stmt = $pdo->query('SELECT * FROM eventos_calendario ORDER BY fecha ASC');
        } else {
            $stmt = $pdo->query('SELECT * FROM eventos_calendario WHERE curso_id IS NULL ORDER BY fecha ASC');
        }
        $eventos = $stmt->fetchAll();

        $mapa = [];
        foreach ($eventos as $ev) {
            $mapa[$ev['fecha']] = [
                'id' => (int)$ev['id'],
                'curso_id' => $ev['curso_id'],
                'clase' => $ev['clase'],
                'titulo' => $ev['titulo'],
                'desc' => $ev['descripcion'] ?? '',
                'tipo' => $ev['tipo']
            ];
        }

        echo json_encode([
            'success' => true,
            'events' => $mapa
        ]);
        break;

    case 'save':
        requerirDocenteOAdmin();
        $fecha = trim($_POST['fecha'] ?? '');
        $cursoId = trim($_POST['curso_id'] ?? '');
        $titulo = trim($_POST['titulo'] ?? '');
        $desc = trim($_POST['desc'] ?? '');
        $tipo = trim($_POST['tipo'] ?? 'ev-repaso');
        $clase = trim($_POST['clase'] ?? 'event-12');

        if ($fecha === '' || $titulo === '' || $cursoId === '') {
            echo json_encode(['success' => false, 'message' => 'Título y fecha requeridos.']);
            exit;
        }
        if (!puedeGestionarCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'No tiene permisos para modificar el calendario de este curso.']);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO eventos_calendario (curso_id, fecha, titulo, descripcion, tipo, clase)
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE titulo = VALUES(titulo), descripcion = VALUES(descripcion), tipo = VALUES(tipo), clase = VALUES(clase)
        ");
        $stmt->execute([$cursoId, $fecha, $titulo, $desc, $tipo, $clase]);

        echo json_encode(['success' => true, 'message' => 'Evento asentado en agenda.']);
        break;

    case 'delete':
        requerirDocenteOAdmin();
        $fecha = trim($_POST['fecha'] ?? '');
        $cursoId = trim($_POST['curso_id'] ?? '');
        if ($fecha === '' || $cursoId === '') {
            echo json_encode(['success' => false, 'message' => 'Fecha requerida.']);
            exit;
        }
        if (!puedeGestionarCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'No tiene permisos para modificar el calendario de este curso.']);
            exit;
        }

        $stmt = $pdo->prepare('DELETE FROM eventos_calendario WHERE fecha = ? AND curso_id = ?');
        $stmt->execute([$fecha, $cursoId]);

        echo json_encode(['success' => $stmt->rowCount() > 0, 'message' => $stmt->rowCount() > 0 ? 'Alerta eliminada del calendario.' : 'No hay una alerta propia para eliminar en esa fecha.']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción inválida.']);
        break;
}
