<?php
/**
 * API de Gestión de Unidades y Cápsulas Didácticas (con subida real de archivos)
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAutenticacion();
$pdo = getPDO();
$usuario = obtenerUsuarioActual();

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
    $json = json_decode(file_get_contents('php://input'), true);
    if (is_array($json)) {
        $_POST = array_merge($_POST, $json);
        $action = $_POST['action'] ?? $action;
    }
}

function verificarPermisoCurso(PDO $pdo, string $cursoId, array $usuario): bool {
    return puedeGestionarCurso($pdo, $cursoId, $usuario);
}

switch ($action) {
    case 'create_unit':
        requerirDocenteOAdmin();
        $cursoId = trim($_POST['curso_id'] ?? '');
        $nombre = trim($_POST['nombre'] ?? '');

        if ($cursoId === '' || $nombre === '') {
            echo json_encode(['success' => false, 'message' => 'Complete el nombre de la unidad.']);
            exit;
        }

        if (!verificarPermisoCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para modificar este curso.']);
            exit;
        }

        $orderStmt = $pdo->prepare("SELECT COALESCE(MAX(orden), 0) + 1 FROM unidades WHERE curso_id = ?");
        $orderStmt->execute([$cursoId]);
        $orden = (int)$orderStmt->fetchColumn();

        $stmt = $pdo->prepare("INSERT INTO unidades (curso_id, nombre, orden) VALUES (?, ?, ?)");
        $stmt->execute([$cursoId, $nombre, $orden]);
        $unidadId = (int)$pdo->lastInsertId();

        // Recursos iniciales opcionales
        $recursos = [
            ['tipo' => 'T', 'nombre' => trim($_POST['teoria_nombre'] ?? ''), 'url' => trim($_POST['teoria_url'] ?? '')],
            ['tipo' => 'V', 'nombre' => trim($_POST['video_nombre'] ?? ''), 'url' => trim($_POST['video_url'] ?? '')],
            ['tipo' => 'E', 'nombre' => trim($_POST['ejercicio_nombre'] ?? ''), 'url' => trim($_POST['ejercicio_url'] ?? '')]
        ];

        $insCapsule = $pdo->prepare("INSERT INTO capsulas (unidad_id, tipo, texto, url, orden) VALUES (?, ?, ?, ?, ?)");
        $cOrden = 1;
        foreach ($recursos as $rec) {
            if ($rec['nombre'] !== '' || $rec['url'] !== '') {
                $insCapsule->execute([
                    $unidadId,
                    $rec['tipo'],
                    $rec['nombre'] ?: ("Recurso " . $rec['tipo'] . " de " . $nombre),
                    $rec['url'] ?: null,
                    $cOrden++
                ]);
            }
        }

        echo json_encode(['success' => true, 'message' => 'Unidad académica dada de alta exitosamente.']);
        break;

    case 'update_unit':
        requerirDocenteOAdmin();
        $unidadId = (int)($_POST['unidad_id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');

        if ($unidadId <= 0 || $nombre === '') {
            echo json_encode(['success' => false, 'message' => 'Nombre no válido.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT u.*, c.profesor_id FROM unidades u JOIN cursos c ON u.curso_id = c.id WHERE u.id = ?");
        $stmt->execute([$unidadId]);
        $unidad = $stmt->fetch();

        if (!$unidad || !verificarPermisoCurso($pdo, $unidad['curso_id'], $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para modificar esta unidad.']);
            exit;
        }

        $upd = $pdo->prepare("UPDATE unidades SET nombre = ? WHERE id = ?");
        $upd->execute([$nombre, $unidadId]);

        echo json_encode(['success' => true, 'message' => 'Unidad actualizada exitosamente.']);
        break;

    case 'delete_unit':
        requerirDocenteOAdmin();
        $unidadId = (int)($_POST['unidad_id'] ?? 0);

        $stmt = $pdo->prepare("SELECT u.*, c.profesor_id FROM unidades u JOIN cursos c ON u.curso_id = c.id WHERE u.id = ?");
        $stmt->execute([$unidadId]);
        $unidad = $stmt->fetch();

        if (!$unidad || !verificarPermisoCurso($pdo, $unidad['curso_id'], $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para eliminar esta unidad.']);
            exit;
        }

        $del = $pdo->prepare("DELETE FROM unidades WHERE id = ?");
        $del->execute([$unidadId]);

        echo json_encode(['success' => true, 'message' => 'Unidad eliminada correctamente.']);
        break;

    case 'add_capsule':
        requerirDocenteOAdmin();
        $unidadId = (int)($_POST['unidad_id'] ?? 0);
        $cursoId = trim($_POST['curso_id'] ?? '');
        $nombreUnidad = trim($_POST['nombre_unidad'] ?? '');
        $tipo = trim($_POST['tipo'] ?? 'T');
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $contenido = trim($_POST['contenido'] ?? '');

        // Si no vino unidad_id pero sí nombre_unidad y curso_id, buscarla
        if ($unidadId <= 0 && $nombreUnidad !== '' && $cursoId !== '') {
            $fStmt = $pdo->prepare("SELECT id FROM unidades WHERE curso_id = ? AND nombre = ? LIMIT 1");
            $fStmt->execute([$cursoId, $nombreUnidad]);
            $unidadId = (int)$fStmt->fetchColumn();
        }

        if ($unidadId <= 0) {
            echo json_encode(['success' => false, 'message' => 'Unidad no identificada.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT u.*, c.profesor_id FROM unidades u JOIN cursos c ON u.curso_id = c.id WHERE u.id = ?");
        $stmt->execute([$unidadId]);
        $unidad = $stmt->fetch();

        if (!$unidad || !verificarPermisoCurso($pdo, $unidad['curso_id'], $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para adjuntar contenido aquí.']);
            exit;
        }

        $url = null;
        if (str_starts_with($contenido, 'http://') || str_starts_with($contenido, 'https://')) {
            $url = $contenido;
        }

        $archivoGuardado = null;
        if (isset($_FILES['archivo']) && $_FILES['archivo']['error'] !== UPLOAD_ERR_NO_FILE) {
            if ($_FILES['archivo']['error'] !== UPLOAD_ERR_OK) {
                http_response_code($_FILES['archivo']['error'] === UPLOAD_ERR_INI_SIZE || $_FILES['archivo']['error'] === UPLOAD_ERR_FORM_SIZE ? 413 : 400);
                echo json_encode(['success' => false, 'message' => 'No se pudo recibir el archivo o supera el límite permitido.']);
                exit;
            }

            $fileTmp = $_FILES['archivo']['tmp_name'];
            $fileNameOriginal = $_FILES['archivo']['name'];
            $fileExt = strtolower(pathinfo($fileNameOriginal, PATHINFO_EXTENSION));
            $mimesPermitidos = [
                'pdf' => ['application/pdf'],
                'doc' => ['application/msword', 'application/x-ole-storage'],
                'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
                'ppt' => ['application/vnd.ms-powerpoint', 'application/x-ole-storage'],
                'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip'],
                'xls' => ['application/vnd.ms-excel', 'application/x-ole-storage'],
                'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
                'txt' => ['text/plain'],
                'jpg' => ['image/jpeg'],
                'jpeg' => ['image/jpeg'],
                'png' => ['image/png'],
                'mp4' => ['video/mp4'],
                'zip' => ['application/zip', 'application/x-zip-compressed']
            ];
            $maximoBytes = 25 * 1024 * 1024;
            $finfo = class_exists('finfo') ? new finfo(FILEINFO_MIME_TYPE) : null;
            $mimeArchivo = $finfo ? $finfo->file($fileTmp) : false;
            if (!isset($mimesPermitidos[$fileExt]) || (int)$_FILES['archivo']['size'] > $maximoBytes || !$mimeArchivo || !in_array($mimeArchivo, $mimesPermitidos[$fileExt], true)) {
                http_response_code((int)$_FILES['archivo']['size'] > $maximoBytes ? 413 : 415);
                echo json_encode(['success' => false, 'message' => 'El formato del archivo no está permitido o supera los 25 MB.']);
                exit;
            }

            $uploadDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
            if (!is_dir($uploadDir) && !mkdir($uploadDir, 0750, true) && !is_dir($uploadDir)) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'No se pudo preparar el almacenamiento de archivos.']);
                exit;
            }
            $nuevoNombre = bin2hex(random_bytes(16)) . '.' . $fileExt;
            $destino = $uploadDir . $nuevoNombre;
            if (!move_uploaded_file($fileTmp, $destino)) {
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'No se pudo guardar el archivo.']);
                exit;
            }
            $archivoGuardado = $nuevoNombre;
        }

        $textoFinal = $nombre !== '' ? $nombre : ($descripcion !== '' ? $descripcion : ($contenido !== '' ? $contenido : ($archivoGuardado ?: "Cápsula {$tipo}")));

        $ordStmt = $pdo->prepare("SELECT COALESCE(MAX(orden), 0) + 1 FROM capsulas WHERE unidad_id = ?");
        $ordStmt->execute([$unidadId]);
        $orden = (int)$ordStmt->fetchColumn();

        $ins = $pdo->prepare("
            INSERT INTO capsulas (unidad_id, tipo, texto, url, archivo, orden)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $ins->execute([$unidadId, $tipo, $textoFinal, $url, $archivoGuardado, $orden]);

        echo json_encode([
            'success' => true,
            'message' => 'Contenido adjuntado exitosamente a la unidad.',
            'capsule' => [
                'id' => (int)$pdo->lastInsertId(),
                'tipo' => $tipo,
                'texto' => $textoFinal,
                'url' => $url,
                'archivo' => $archivoGuardado
            ]
        ]);
        break;

    case 'toggle_delivered':
        requerirDocenteOAdmin();
        $capsulaId = (int)($_POST['capsula_id'] ?? 0);
        $dictada = !empty($_POST['dictada']) ? 1 : 0;
        $stmt = $pdo->prepare('SELECT u.curso_id FROM capsulas cap JOIN unidades u ON u.id = cap.unidad_id WHERE cap.id = ?');
        $stmt->execute([$capsulaId]);
        $cursoId = $stmt->fetchColumn();
        if (!$cursoId || !puedeGestionarCurso($pdo, (string)$cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'No tiene permisos sobre este contenido.']);
            exit;
        }
        $upd = $pdo->prepare('UPDATE capsulas SET dictada = ? WHERE id = ?');
        $upd->execute([$dictada, $capsulaId]);
        echo json_encode(['success' => true, 'dictada' => $dictada]);
        break;

    case 'toggle_complete':
        if (($usuario['rol'] ?? '') !== 'alumno') {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Esta acción es exclusiva de alumnos.']);
            exit;
        }
        $capsulaId = (int)($_POST['capsula_id'] ?? 0);
        $completada = !empty($_POST['completada']) ? 1 : 0;
        $capsulaStmt = $pdo->prepare('SELECT cap.dictada FROM capsulas cap JOIN unidades u ON u.id = cap.unidad_id JOIN alumnos a ON a.curso_id = u.curso_id WHERE cap.id = ? AND a.usuario_id = ? AND a.activo = 1 LIMIT 1');
        $capsulaStmt->execute([$capsulaId, (int)$usuario['id']]);
        $dictada = $capsulaStmt->fetchColumn();
        if ($dictada === false || ($completada && !(int)$dictada)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'El contenido no está disponible para completar.']);
            exit;
        }
        $stmt = $pdo->prepare('INSERT INTO progreso_capsulas (alumno_id, capsula_id, completada, completada_en) SELECT id, ?, ?, IF(? = 1, NOW(), NULL) FROM alumnos WHERE usuario_id = ? AND activo = 1 ON DUPLICATE KEY UPDATE completada = VALUES(completada), completada_en = VALUES(completada_en)');
        $stmt->execute([$capsulaId, $completada, $completada, (int)$usuario['id']]);
        echo json_encode(['success' => true, 'completada' => $completada]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción inválida.']);
        break;
}
