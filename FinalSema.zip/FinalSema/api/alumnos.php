<?php
/**
 * API de Gestión de Alumnos (CRUD, Soft-Delete y Reincorporación)
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAutenticacion();
$pdo = getPDO();
$usuario = obtenerUsuarioActual();
$esAdmin = esAdmin();

$action = $_GET['action'] ?? ($_POST['action'] ?? 'list');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputRaw = file_get_contents('php://input');
    $inputJson = json_decode($inputRaw, true);
    if (is_array($inputJson)) {
        $_POST = array_merge($_POST, $inputJson);
    }
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
    }
}

function verificarPermisoCurso(PDO $pdo, string $cursoId, array $usuario): bool {
    return puedeGestionarCurso($pdo, $cursoId, $usuario);
}

switch ($action) {
    case 'list':
        $cursoId = trim($_GET['curso_id'] ?? ($_POST['curso_id'] ?? ''));
        $incluirInactivos = isset($_GET['incluir_inactivos']) || isset($_POST['incluir_inactivos']) || $esAdmin;

        if (($usuario['rol'] ?? '') === 'alumno') {
            $sql = "SELECT a.*, c.titulo AS nombre_curso FROM alumnos a JOIN cursos c ON a.curso_id = c.id WHERE a.usuario_id = ? AND a.activo = 1";
            $params = [(int)$usuario['id']];
            if ($cursoId !== '') {
                $sql .= " AND a.curso_id = ?";
                $params[] = $cursoId;
            }
            $sql .= " ORDER BY a.n_orden ASC LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
        } elseif ($cursoId !== '' && !verificarPermisoCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'Acceso denegado a este curso.']);
            exit;
        } elseif ($cursoId !== '') {
            $sql = "SELECT a.*, c.titulo AS nombre_curso FROM alumnos a JOIN cursos c ON a.curso_id = c.id WHERE a.curso_id = ?";
            if (!$incluirInactivos) {
                $sql .= " AND a.activo = 1";
            }
            $sql .= " ORDER BY a.activo DESC, a.n_orden ASC, a.id ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$cursoId]);
        } else {
            // Todos los alumnos
            $sql = "SELECT a.*, c.titulo AS nombre_curso FROM alumnos a JOIN cursos c ON a.curso_id = c.id";
            if (!$esAdmin) {
                $sql .= " WHERE c.profesor_id = " . (int)($usuario['id'] ?? 0);
            }
            if (!$incluirInactivos) {
                $sql .= $esAdmin ? " WHERE a.activo = 1" : " AND a.activo = 1";
            }
            $sql .= " ORDER BY c.orden ASC, a.activo DESC, a.n_orden ASC";
            $stmt = $pdo->query($sql);
        }

        $alumnos = $stmt->fetchAll();
        $progresoAlumno = null;
        if (($usuario['rol'] ?? '') === 'alumno' && $alumnos) {
            $totalStmt = $pdo->prepare('SELECT COUNT(*) FROM capsulas cap JOIN unidades u ON u.id = cap.unidad_id JOIN alumnos a ON a.curso_id = u.curso_id WHERE a.usuario_id = ? AND a.activo = 1');
            $totalStmt->execute([(int)$usuario['id']]);
            $hechasStmt = $pdo->prepare('SELECT COUNT(*) FROM progreso_capsulas pc JOIN alumnos a ON a.id = pc.alumno_id WHERE a.usuario_id = ? AND a.activo = 1 AND pc.completada = 1');
            $hechasStmt->execute([(int)$usuario['id']]);
            $total = (int)$totalStmt->fetchColumn();
            $progresoAlumno = $total ? (int)round((int)$hechasStmt->fetchColumn() * 100 / $total) : 0;
        }
        echo json_encode([
            'success' => true,
            'alumnos' => array_map(function($al) use ($usuario, $progresoAlumno) {
                return [
                    'id' => (int)$al['id'],
                    'curso_id' => $al['curso_id'],
                    'nombre_curso' => $al['nombre_curso'] ?? '',
                    'n' => (int)$al['n_orden'],
                    'corto' => $al['corto'],
                    'completo' => $al['completo'],
                    'dni' => $al['dni'] ?? '',
                    'email' => $al['email'],
                    'nota' => (float)$al['nota'],
                    'condicion' => $al['condicion'],
                    'progreso' => ($usuario['rol'] ?? '') === 'alumno' ? $progresoAlumno : (int)$al['progreso'],
                    'activo' => (int)$al['activo'],
                    'fecha_baja' => $al['fecha_baja'],
                    'observaciones_docente' => $al['observaciones_docente'] ?? ''
                ];
            }, $alumnos)
        ]);
        break;

    case 'create':
        requerirDocenteOAdmin();
        $cursoId = trim($_POST['curso_id'] ?? '');
        $completo = trim($_POST['completo'] ?? '');
        $corto = trim($_POST['corto'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $dni = preg_replace('/\D+/', '', (string)($_POST['dni'] ?? ''));

        if ($cursoId === '' || $completo === '' || $corto === '' || !preg_match('/^\d{7,10}$/', $dni)) {
            echo json_encode(['success' => false, 'message' => 'Completá nombre, nombre corto y un DNI válido.']);
            exit;
        }

        if (!verificarPermisoCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para inscribir en este curso.']);
            exit;
        }

        $numStmt = $pdo->prepare("SELECT COALESCE(MAX(n_orden), 0) + 1 FROM alumnos WHERE curso_id = ?");
        $numStmt->execute([$cursoId]);
        $proxNum = (int)$numStmt->fetchColumn();

        if ($email === '') {
            $email = strtolower(explode(' ', $corto)[0]) . rand(100, 999) . '@sema.edu.ar';
        }

        $dniCheck = $pdo->prepare('SELECT 1 FROM alumnos WHERE dni = ? LIMIT 1');
        $dniCheck->execute([$dni]);
        if ($dniCheck->fetchColumn()) {
            http_response_code(409);
            echo json_encode(['success' => false, 'message' => 'Ese DNI ya figura en el padrón de otro curso o ficha.']);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO alumnos (curso_id, n_orden, corto, completo, dni, email, nota, condicion, progreso, activo)
            VALUES (?, ?, ?, ?, ?, ?, 0, 'Regular', 0, 1)
        ");
        $stmt->execute([$cursoId, $proxNum, $corto, $completo, $dni, $email]);

        echo json_encode([
            'success' => true,
            'message' => 'Estudiante inscrito exitosamente.',
            'id' => (int)$pdo->lastInsertId()
        ]);
        break;

    case 'import':
        requerirDocenteOAdmin();
        $cursoId = trim($_POST['curso_id'] ?? '');
        $filas = $_POST['alumnos'] ?? [];
        if ($cursoId === '' || !is_array($filas) || count($filas) === 0 || count($filas) > 500) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Elegí un curso y un archivo con hasta 500 alumnos.']);
            exit;
        }
        if (!verificarPermisoCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'No tiene permisos para inscribir en este curso.']);
            exit;
        }
        foreach ($filas as $indice => $fila) {
            if (!is_array($fila)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'El archivo contiene una fila inválida.']);
                exit;
            }
            $nombreFila = trim((string)($fila['completo'] ?? ''));
            $emailFila = trim((string)($fila['email'] ?? ''));
            $dniFila = preg_replace('/\D+/', '', (string)($fila['dni'] ?? ''));
            $largoNombre = function_exists('mb_strlen') ? mb_strlen($nombreFila, 'UTF-8') : strlen($nombreFila);
            $largoEmail = function_exists('mb_strlen') ? mb_strlen($emailFila, 'UTF-8') : strlen($emailFila);
            if ($nombreFila === '' || $largoNombre > 150 || !preg_match('/^\d{7,10}$/', $dniFila) || ($emailFila !== '' && (!filter_var($emailFila, FILTER_VALIDATE_EMAIL) || $largoEmail > 100))) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Revisá el nombre, el DNI o el email de la fila ' . ($indice + 1) . '.']);
                exit;
            }
        }
        $dnisImportados = array_map(function($fila) { return preg_replace('/\D+/', '', (string)($fila['dni'] ?? '')); }, $filas);
        if (count(array_unique($dnisImportados)) !== count($dnisImportados)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'El archivo contiene DNI repetidos.']);
            exit;
        }
        $dniExistente = $pdo->prepare('SELECT 1 FROM alumnos WHERE dni = ? LIMIT 1');
        foreach ($dnisImportados as $dniImportado) {
            $dniExistente->execute([$dniImportado]);
            if ($dniExistente->fetchColumn()) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'Uno de los DNI ya figura en el padrón. Revisá si ese alumno ya fue cargado en otro curso.']);
                exit;
            }
        }
        $numStmt = $pdo->prepare('SELECT COALESCE(MAX(n_orden), 0) + 1 FROM alumnos WHERE curso_id = ?');
        $numStmt->execute([$cursoId]);
        $proxNum = (int)$numStmt->fetchColumn();
        $insert = $pdo->prepare("INSERT INTO alumnos (curso_id, n_orden, corto, completo, dni, email, nota, condicion, progreso, activo) VALUES (?, ?, ?, ?, ?, ?, 0, 'Regular', 0, 1)");
        $pdo->beginTransaction();
        try {
            $importados = 0;
            foreach ($filas as $fila) {
                $nombre = trim((string)($fila['completo'] ?? ''));
                $corto = explode(' ', preg_replace('/\\s+/', ' ', $nombre))[0];
                $email = trim((string)($fila['email'] ?? ''));
                $dni = preg_replace('/\D+/', '', (string)($fila['dni'] ?? ''));
                if ($email === '') $email = strtolower(preg_replace('/[^a-z0-9]/i', '', $corto)) . random_int(100, 999) . '@sema.edu.ar';
                $insert->execute([$cursoId, $proxNum++, $corto, $nombre, $dni, $email]);
                $importados++;
            }
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => "Se importaron {$importados} alumnos.", 'importados' => $importados]);
        } catch (Throwable $e) {
            $pdo->rollBack();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'No se pudo completar la importación.']);
        }
        break;

    case 'update':
        requerirDocenteOAdmin();
        $id = (int)($_POST['id'] ?? 0);
        $emailOriginal = trim($_POST['email_original'] ?? '');
        $completo = trim($_POST['completo'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $dni = preg_replace('/\D+/', '', (string)($_POST['dni'] ?? ''));
        $condicion = trim($_POST['condicion'] ?? 'Regular');
        $observacionesEnviadas = array_key_exists('observaciones_docente', $_POST)
            ? trim((string)$_POST['observaciones_docente'])
            : null;
        $nota = isset($_POST['nota']) ? (float)$_POST['nota'] : null;

        // Buscar alumno por ID o por email y curso_id
        if ($id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
            $stmt->execute([$id]);
        } else {
            $cursoId = trim($_POST['curso_id'] ?? '');
            $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE email = ? AND curso_id = ?");
            $stmt->execute([$emailOriginal, $cursoId]);
        }
        $alumno = $stmt->fetch();

        if (!$alumno) {
            echo json_encode(['success' => false, 'message' => 'Estudiante no encontrado.']);
            exit;
        }

        if (!verificarPermisoCurso($pdo, $alumno['curso_id'], $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos sobre este curso.']);
            exit;
        }

        $observacionesDocente = $observacionesEnviadas ?? trim((string)($alumno['observaciones_docente'] ?? ''));
        $nuevoCompleto = $completo !== '' ? $completo : $alumno['completo'];
        $nuevoCorto = explode(' ', $nuevoCompleto)[0];
        $nuevoEmail = $email !== '' ? $email : $alumno['email'];
        $nuevoDni = $dni !== '' ? $dni : ($alumno['dni'] ?? '');
        if ($nuevoDni !== '' && !preg_match('/^\d{7,10}$/', $nuevoDni)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'El DNI debe tener entre 7 y 10 números.']);
            exit;
        }
        if ($nuevoDni !== '') {
            $dniDuplicado = $pdo->prepare('SELECT 1 FROM alumnos WHERE dni = ? AND id <> ? LIMIT 1');
            $dniDuplicado->execute([$nuevoDni, (int)$alumno['id']]);
            if ($dniDuplicado->fetchColumn()) {
                http_response_code(409);
                echo json_encode(['success' => false, 'message' => 'Ese DNI ya está asociado a otra ficha del padrón.']);
                exit;
            }
        }
        if (strlen($observacionesDocente) > 10000) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Las observaciones no pueden superar los 10.000 caracteres.']);
            exit;
        }
        $nuevaNota = $nota !== null ? max(0, min(10, $nota)) : (float)$alumno['nota'];
        $upd = $pdo->prepare("
            UPDATE alumnos 
            SET completo = ?, corto = ?, dni = ?, email = ?, condicion = ?, nota = ?, observaciones_docente = ?
            WHERE id = ?
        ");
        $upd->execute([$nuevoCompleto, $nuevoCorto, $nuevoDni ?: null, $nuevoEmail, $condicion, $nuevaNota, $observacionesDocente, $alumno['id']]);

        echo json_encode(['success' => true, 'message' => 'Ficha del estudiante actualizada.']);
        break;

    case 'soft_delete':
        requerirDocenteOAdmin();
        // Baja lógica: se marca activo = 0 y fecha_baja = NOW()
        $id = (int)($_POST['id'] ?? 0);
        $email = trim($_POST['email'] ?? '');
        $cursoId = trim($_POST['curso_id'] ?? '');

        if ($id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
            $stmt->execute([$id]);
        } else {
            $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE email = ? AND curso_id = ?");
            $stmt->execute([$email, $cursoId]);
        }
        $alumno = $stmt->fetch();

        if (!$alumno) {
            echo json_encode(['success' => false, 'message' => 'Estudiante no encontrado.']);
            exit;
        }

        if (!verificarPermisoCurso($pdo, $alumno['curso_id'], $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para dar de baja en este curso.']);
            exit;
        }

        $upd = $pdo->prepare("UPDATE alumnos SET activo = 0, fecha_baja = NOW() WHERE id = ?");
        $upd->execute([$alumno['id']]);

        echo json_encode([
            'success' => true,
            'message' => 'El estudiante fue dado de baja (archivado en el registro general).'
        ]);
        break;

    case 'restore':
        requerirDocenteOAdmin();
        // Reincorporación de estudiante dado de baja
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
        $stmt->execute([$id]);
        $alumno = $stmt->fetch();

        if (!$alumno) {
            echo json_encode(['success' => false, 'message' => 'Estudiante no encontrado.']);
            exit;
        }

        if (!verificarPermisoCurso($pdo, $alumno['curso_id'], $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para reincorporar a este alumno.']);
            exit;
        }

        $upd = $pdo->prepare("UPDATE alumnos SET activo = 1, fecha_baja = NULL WHERE id = ?");
        $upd->execute([$id]);

        echo json_encode([
            'success' => true,
            'message' => "El estudiante '{$alumno['completo']}' ha sido reincorporado exitosamente."
        ]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción inválida.']);
        break;
}
