<?php
/**
 * API de Gestión de Cursos SEMA
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAutenticacion();
$pdo = getPDO();
$usuario = obtenerUsuarioActual();
$esAdmin = esAdmin();
$alumnoVinculadoId = null;
if (($usuario['rol'] ?? '') === 'alumno') {
    $alumnoStmt = $pdo->prepare('SELECT id FROM alumnos WHERE usuario_id = ? AND activo = 1 LIMIT 1');
    $alumnoStmt->execute([(int)$usuario['id']]);
    $alumnoVinculadoId = $alumnoStmt->fetchColumn();
}

$action = $_GET['action'] ?? ($_POST['action'] ?? 'list');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputRaw = file_get_contents('php://input');
    $inputJson = json_decode($inputRaw, true);
    if (is_array($inputJson)) {
        $_POST = array_merge($_POST, $inputJson);
    }
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
    }
}

switch ($action) {
    case 'list':
        // Administradores ven todos los cursos; docentes solo los asignados.
        $sqlCursos = "
            SELECT c.*, u.nombre_completo AS nombre_profesor 
            FROM cursos c 
            LEFT JOIN usuarios u ON c.profesor_id = u.id 
        ";
        if (($usuario['rol'] ?? '') === 'profesor') {
            $sqlCursos .= " WHERE c.profesor_id = " . (int)$usuario['id'];
        } elseif (($usuario['rol'] ?? '') === 'alumno' && $alumnoVinculadoId) {
            $sqlCursos .= " JOIN alumnos a ON a.curso_id = c.id WHERE a.id = " . (int)$alumnoVinculadoId . " AND a.activo = 1";
        } elseif (($usuario['rol'] ?? '') !== 'admin') {
            $sqlCursos .= " WHERE 1 = 0";
        }
        $sqlCursos .= " ORDER BY c.orden ASC, c.id ASC";
        $stmt = $pdo->query($sqlCursos);
        $cursos = $stmt->fetchAll();

        // Estructurar respuesta compatible con el frontend existente
        $resultado = [];
        foreach ($cursos as $c) {
            $cid = $c['id'];
            
            // Cargar unidades y cápsulas
            $stmtUnidades = $pdo->prepare("SELECT * FROM unidades WHERE curso_id = ? ORDER BY orden ASC, id ASC");
            $stmtUnidades->execute([$cid]);
            $unidadesRaw = $stmtUnidades->fetchAll();

            $unidades = [];
            foreach ($unidadesRaw as $u) {
                if ($alumnoVinculadoId) {
                    $stmtCapsulas = $pdo->prepare('SELECT cap.*, COALESCE(pc.completada, 0) AS completada FROM capsulas cap LEFT JOIN progreso_capsulas pc ON pc.capsula_id = cap.id AND pc.alumno_id = ? WHERE cap.unidad_id = ? ORDER BY cap.orden ASC, cap.id ASC');
                    $stmtCapsulas->execute([(int)$alumnoVinculadoId, $u['id']]);
                } else {
                    $stmtCapsulas = $pdo->prepare('SELECT *, 0 AS completada FROM capsulas WHERE unidad_id = ? ORDER BY orden ASC, id ASC');
                    $stmtCapsulas->execute([$u['id']]);
                }
                $capsulas = $stmtCapsulas->fetchAll();
                
                $unidades[] = [
                    'id' => (int)$u['id'],
                    'nombre' => $u['nombre'],
                    'tareas' => array_map(function($cap) {
                        return [
                            'id' => (int)$cap['id'],
                            'tipo' => $cap['tipo'],
                            'texto' => $cap['texto'],
                            'url' => $cap['url'],
                            'archivo' => $cap['archivo'],
                            'dictada' => (int)$cap['dictada'],
                            'completada' => (int)($cap['completada'] ?? 0),
                        ];
                    }, $capsulas)
                ];
            }

            // Cargar alumnos activos para la visualización del curso
            // Si es admin, también puede ver los alumnos inactivos en el registro global
            if ($alumnoVinculadoId) {
                $stmtAlumnos = $pdo->prepare("SELECT * FROM alumnos WHERE id = ? AND curso_id = ? AND activo = 1");
                $stmtAlumnos->execute([(int)$alumnoVinculadoId, $cid]);
            } else {
                $stmtAlumnos = $pdo->prepare("SELECT * FROM alumnos WHERE curso_id = ? AND activo = 1 ORDER BY n_orden ASC, id ASC");
                $stmtAlumnos->execute([$cid]);
            }
            $alumnosRaw = $stmtAlumnos->fetchAll();

            $progresoAlumno = null;
            if ($alumnoVinculadoId) {
                $totalCapsulas = array_sum(array_map(function($unidad) { return count($unidad['tareas']); }, $unidades));
                $completadasCapsulas = 0;
                foreach ($unidades as $unidad) {
                    foreach ($unidad['tareas'] as $tarea) {
                        $completadasCapsulas += (int)$tarea['completada'];
                    }
                }
                $progresoAlumno = $totalCapsulas ? (int)round($completadasCapsulas * 100 / $totalCapsulas) : 0;
            }

            $alumnos = array_map(function($al) use ($usuario, $progresoAlumno) {
                return [
                    'id' => (int)$al['id'],
                    'n' => (int)$al['n_orden'],
                    'corto' => $al['corto'],
                    'completo' => $al['completo'],
                    'dni' => $al['dni'] ?? '',
                    'email' => $al['email'],
                    'nota' => (float)$al['nota'],
                    'condicion' => $al['condicion'],
                    'progreso' => ($usuario['rol'] ?? '') === 'alumno' ? $progresoAlumno : (int)$al['progreso'],
                    'activo' => (int)$al['activo'],
                    'observaciones_docente' => $al['observaciones_docente'] ?? ''
                ];
            }, $alumnosRaw);

            $resultado[$cid] = [
                'id' => $cid,
                'titulo' => $c['titulo'],
                'materias' => $c['materias'],
                'profesor_id' => $c['profesor_id'],
                'nombre_profesor' => $c['nombre_profesor'] ?? 'Sin asignar',
                'proximoExamen' => $c['proximo_examen'] ?? '',
                'temaExamen' => $c['tema_examen'] ?? '',
                'comunicadoProfesora' => $c['comunicado_profesora'] ?? '',
                'solicitudAcceso' => $c['solicitud_acceso'],
                'drive_url' => $c['drive_url'] ?? '',
                'unidades' => $unidades,
                'alumnos' => $alumnos
            ];
        }

        echo json_encode([
            'success' => true,
            'es_admin' => $esAdmin,
            'usuario' => $usuario,
            'courses' => $resultado
        ]);
        break;

    case 'update_info':
        requerirDocenteOAdmin();
        $cursoId = trim($_POST['curso_id'] ?? '');
        if (!puedeGestionarCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos para modificar este curso.']);
            exit;
        }

        $proximoExamen = trim($_POST['proximo_examen'] ?? '');
        $temaExamen = trim($_POST['tema_examen'] ?? '');
        $comunicado = trim($_POST['comunicado_profesora'] ?? '');
        $driveUrl = trim($_POST['drive_url'] ?? '');
        $parsedDriveUrl = $driveUrl !== '' && filter_var($driveUrl, FILTER_VALIDATE_URL) ? parse_url($driveUrl) : false;
        $driveHost = strtolower($parsedDriveUrl['host'] ?? '');
        if ($driveUrl !== '' && (strlen($driveUrl) > 1000 || !$parsedDriveUrl || ($parsedDriveUrl['scheme'] ?? '') !== 'https' || !in_array($driveHost, ['drive.google.com', 'docs.google.com'], true))) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Usá un enlace HTTPS válido de Google Drive.']);
            exit;
        }

        $stmt = $pdo->prepare("
            UPDATE cursos 
            SET proximo_examen = ?, tema_examen = ?, comunicado_profesora = ?, drive_url = ?
            WHERE id = ?
        ");
        $stmt->execute([$proximoExamen, $temaExamen, $comunicado, $driveUrl !== '' ? $driveUrl : null, $cursoId]);

        echo json_encode(['success' => true, 'message' => 'Información del curso actualizada.']);
        break;

    case 'accept_access':
        requerirDocenteOAdmin();
        $cursoId = trim($_POST['curso_id'] ?? '');
        if (!puedeGestionarCurso($pdo, $cursoId, $usuario)) {
            http_response_code(403);
            echo json_encode(['error' => 'No tiene permisos sobre este curso.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT solicitud_acceso FROM cursos WHERE id = ?");
        $stmt->execute([$cursoId]);
        $solicitud = $stmt->fetchColumn();

        if (!$solicitud) {
            echo json_encode(['success' => false, 'message' => 'No hay solicitud pendiente para este curso.']);
            exit;
        }

        // Obtener el próximo número de orden
        $numStmt = $pdo->prepare("SELECT COALESCE(MAX(n_orden), 0) + 1 FROM alumnos WHERE curso_id = ?");
        $numStmt->execute([$cursoId]);
        $proxNum = (int)$numStmt->fetchColumn();

        // Extraer nombre aproximado de la solicitud (Ej: "Lautaro Martínez (Petición...)")
        $nombre = preg_replace('/\s*\(.*?\)/', '', $solicitud);
        $partes = explode(' ', trim($nombre));
        $corto = $partes[0] ?? 'Estudiante';
        $email = strtolower($corto) . rand(10, 99) . '@sema.edu.ar';

        $insert = $pdo->prepare("
            INSERT INTO alumnos (curso_id, n_orden, corto, completo, email, nota, condicion, progreso, activo)
            VALUES (?, ?, ?, ?, ?, 0, 'Regular', 0, 1)
        ");
        $insert->execute([$cursoId, $proxNum, $corto, $nombre, $email]);

        // Limpiar solicitud
        $clean = $pdo->prepare("UPDATE cursos SET solicitud_acceso = NULL WHERE id = ?");
        $clean->execute([$cursoId]);

        echo json_encode(['success' => true, 'message' => 'Matrícula aceptada con éxito.']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción inválida.']);
        break;
}
