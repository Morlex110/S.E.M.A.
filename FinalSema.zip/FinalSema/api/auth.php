<?php
/**
 * API de Autenticación y Control de Sesión
 */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

iniciarSesionSegura();
$pdo = getPDO();

$action = $_GET['action'] ?? ($_POST['action'] ?? 'check');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputRaw = file_get_contents('php://input');
    $inputJson = json_decode($inputRaw, true);
    if (is_array($inputJson)) {
        $_POST = array_merge($_POST, $inputJson);
    }
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
    }
}

function normalizarIdentidadPadron(string $valor): string {
    if (function_exists('iconv')) {
        $sinAcentos = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $valor);
        if ($sinAcentos !== false) $valor = $sinAcentos;
    }
    $valor = function_exists('mb_strtolower') ? mb_strtolower($valor, 'UTF-8') : strtolower($valor);
    return preg_replace('/[^\p{L}\p{N}]/u', '', $valor) ?? '';
}

function fechaNacimientoValida(string $fecha): bool {
    $fechaParseada = DateTimeImmutable::createFromFormat('!Y-m-d', $fecha);
    $errores = DateTimeImmutable::getLastErrors();
    return $fechaParseada !== false
        && $fechaParseada->format('Y-m-d') === $fecha
        && ($errores === false || ($errores['warning_count'] === 0 && $errores['error_count'] === 0));
}

function buscarFichaAlumno(PDO $pdo, string $dni, string $nombre): ?array {
    $stmt = $pdo->prepare("SELECT a.id, a.usuario_id, a.curso_id, c.titulo AS nombre_curso, a.completo FROM alumnos a JOIN cursos c ON c.id = a.curso_id WHERE a.dni = ? AND a.activo = 1 LIMIT 2");
    $stmt->execute([$dni]);
    $fichas = $stmt->fetchAll();
    if (count($fichas) !== 1 || normalizarIdentidadPadron((string)$fichas[0]['completo']) !== normalizarIdentidadPadron($nombre)) return null;
    return $fichas[0];
}

switch ($action) {
    case 'preview_student_course':
        $dni = preg_replace('/\D+/', '', (string)($_POST['dni'] ?? ''));
        $nombre = trim((string)($_POST['nombre_completo'] ?? ''));
        if (!preg_match('/^\d{7,10}$/', $dni) || $nombre === '') {
            echo json_encode(['success' => true, 'matched' => false]);
            break;
        }
        $ficha = buscarFichaAlumno($pdo, $dni, $nombre);
        echo json_encode(['success' => true, 'matched' => (bool)$ficha, 'curso' => $ficha['nombre_curso'] ?? '']);
        break;

    case 'check':
        if (estaAutenticado()) {
            echo json_encode([
                'logged' => true,
                'user' => obtenerUsuarioActual()
            ]);
        } else {
            echo json_encode([
                'logged' => false
            ]);
        }
        break;

    case 'login':
        $identity = trim($_POST['identity'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $fechaNacimiento = trim((string)($_POST['Fecha_de_Nacimiento'] ?? ''));

        if ($identity === '' || $password === '' || !fechaNacimientoValida($fechaNacimiento)) {
            echo json_encode(['success' => false, 'message' => 'Usuario, contraseña o fecha incorrectos.']);
            exit;
        }

        $identityStmt = $pdo->prepare('SELECT username FROM usuarios WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?) LIMIT 1');
        $identityStmt->execute([$identity, $identity]);
        $usernameForLimit = $identityStmt->fetchColumn();
        $identityForLimit = strtolower((string)($usernameForLimit ?: $identity));
        $ipForLimit = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

        $userAttempts = $pdo->prepare("SELECT COUNT(*) FROM logs_acceso WHERE LOWER(username) = ? AND ip = ? AND exitoso = 0 AND fecha_ingreso >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
        $userAttempts->execute([$identityForLimit, $ipForLimit]);
        $ipAttempts = $pdo->prepare("SELECT COUNT(*) FROM logs_acceso WHERE ip = ? AND exitoso = 0 AND fecha_ingreso >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
        $ipAttempts->execute([$ipForLimit]);
        if ((int)$userAttempts->fetchColumn() >= 8 || (int)$ipAttempts->fetchColumn() >= 30) {
            http_response_code(429);
            echo json_encode(['success' => false, 'message' => 'Demasiados intentos. Esperá 15 minutos antes de volver a probar.']);
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE (LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)) AND activo = 1 LIMIT 1");
        $stmt->execute([$identity, $identity]);
        $user = $stmt->fetch();

        if (!$user) {
            registrarLogAcceso($pdo, null, $identity, 'desconocido', false);
            echo json_encode(['success' => false, 'message' => 'Usuario o contraseña incorrectos.']);
            exit;
        }

        $clavesIniciales = [
            'admin' => 'admin1234',
            'docente' => '1234',
            'docente_cstep' => '1234',
        ];
        if (SEMA_ENV === 'production'
            && isset($clavesIniciales[$user['username']])
            && hash_equals($clavesIniciales[$user['username']], $password)) {
            registrarLogAcceso($pdo, (int)$user['id'], $user['username'], $user['rol'], false);
            echo json_encode(['success' => false, 'message' => 'La cuenta conserva una clave inicial insegura. Contactá al administrador.']);
            exit;
        }

        if (!password_verify($password, $user['password_hash'])) {
            registrarLogAcceso($pdo, $user['id'], $user['username'], $user['rol'], false);
            echo json_encode(['success' => false, 'message' => 'Usuario o contraseña incorrectos.']);
            exit;
        }

        $fechaGuardada = trim((string)($user['Fecha_de_Nacimiento'] ?? ''));
        if ($fechaGuardada === '' || $fechaGuardada === '0000-00-00') {
            $setFecha = $pdo->prepare("UPDATE usuarios SET Fecha_de_Nacimiento = ? WHERE id = ? AND (Fecha_de_Nacimiento IS NULL OR Fecha_de_Nacimiento = '0000-00-00')");
            $setFecha->execute([$fechaNacimiento, (int)$user['id']]);
            $fechaStmt = $pdo->prepare('SELECT Fecha_de_Nacimiento FROM usuarios WHERE id = ?');
            $fechaStmt->execute([(int)$user['id']]);
            $fechaGuardada = (string)$fechaStmt->fetchColumn();
        }
        if (!hash_equals($fechaGuardada, $fechaNacimiento)) {
            registrarLogAcceso($pdo, (int)$user['id'], $user['username'], $user['rol'], false);
            echo json_encode(['success' => false, 'message' => 'Usuario, contraseña o fecha incorrectos.']);
            exit;
        }

        // Login exitoso: rotar el ID evita fijación de sesión.
        session_regenerate_id(true);
        $_SESSION['usuario'] = [
            'id' => (int)$user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'nombre_completo' => $user['nombre_completo'],
            'rol' => $user['rol']
        ];

        registrarLogAcceso($pdo, $user['id'], $user['username'], $user['rol'], true);

        $cursoTitulo = null;
        if (($user['rol'] ?? '') === 'alumno') {
            $cursoStmt = $pdo->prepare('SELECT c.titulo FROM alumnos a JOIN cursos c ON c.id = a.curso_id WHERE a.usuario_id = ? AND a.activo = 1 LIMIT 1');
            $cursoStmt->execute([(int)$user['id']]);
            $cursoTitulo = $cursoStmt->fetchColumn() ?: '';
        }

        echo json_encode([
            'success' => true,
            'message' => 'Inicio de sesión exitoso.',
            'user' => array_merge($_SESSION['usuario'], ['curso_titulo' => $cursoTitulo])
        ]);
        break;

    case 'signup':
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = (string)($_POST['password'] ?? '');
        $fechaNacimiento = trim((string)($_POST['Fecha_de_Nacimiento'] ?? ''));
        $nombreCompleto = trim($_POST['nombre_completo'] ?? $username);
        $dni = preg_replace('/\D+/', '', (string)($_POST['dni'] ?? ''));
        $terminosAceptados = filter_var($_POST['terms_accepted'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $versionTerminos = trim((string)($_POST['terms_version'] ?? ''));
        // El registro público nunca concede permisos docentes ni administrativos.
        $rolesPermitidos = ['admin', 'profesor', 'alumno'];
        $rol = esAdmin() && in_array($_POST['rol'] ?? '', $rolesPermitidos, true)
            ? $_POST['rol']
            : 'alumno';

        if ($username === '' || $email === '' || $password === '' || $nombreCompleto === '' || !preg_match('/^\d{7,10}$/', $dni) || !fechaNacimientoValida($fechaNacimiento)) {
            echo json_encode(['success' => false, 'message' => 'Completá usuario, correo, nombre, DNI, fecha y contraseña.']);
            exit;
        }
        if (strlen($password) < 12 || strlen($password) > 72) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'La contraseña debe tener entre 12 y 72 caracteres.']);
            exit;
        }
        if (!$terminosAceptados || $versionTerminos !== SEMA_TERMS_VERSION) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Leé y aceptá los Términos y el Aviso de Privacidad vigentes para crear la cuenta.']);
            exit;
        }

        $fichaAlumno = null;
        if ($rol === 'alumno') {
            $fichaAlumno = buscarFichaAlumno($pdo, $dni, $nombreCompleto);
            if (!$fichaAlumno) {
                echo json_encode(['success' => false, 'message' => 'No encontramos una ficha activa con ese DNI y nombre. Pedile al docente que revise el padrón del curso.']);
                exit;
            }
            if ($fichaAlumno['usuario_id'] !== null) {
                echo json_encode(['success' => false, 'message' => 'Esa ficha ya tiene una cuenta asociada. Si es tuya, contactá a la institución.']);
                exit;
            }
        }

        // Verificar duplicados
        $check = $pdo->prepare("SELECT id FROM usuarios WHERE LOWER(username) = LOWER(?) OR LOWER(email) = LOWER(?)");
        $check->execute([$username, $email]);
        if ($check->fetch()) {
            echo json_encode(['success' => false, 'message' => 'El nombre de usuario o correo ya está registrado.']);
            exit;
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        if (!esAdmin()) {
            session_regenerate_id(true);
        }
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO usuarios (username, email, password_hash, Fecha_de_Nacimiento, nombre_completo, rol, activo, terms_accepted_at, terms_version) VALUES (?, ?, ?, ?, ?, ?, 1, NOW(), ?)");
            $stmt->execute([$username, $email, $hash, $fechaNacimiento, $nombreCompleto, $rol, SEMA_TERMS_VERSION]);
            $newId = (int)$pdo->lastInsertId();
            if ($rol === 'alumno') {
                $link = $pdo->prepare('UPDATE alumnos SET usuario_id = ? WHERE id = ? AND usuario_id IS NULL AND activo = 1');
                $link->execute([$newId, (int)$fichaAlumno['id']]);
                if ($link->rowCount() !== 1) throw new RuntimeException('La ficha de alumno dejó de estar disponible.');
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('SEMA student registration failed: ' . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'No se pudo crear la cuenta. Revisá si el usuario, correo o ficha ya están registrados.']);
            exit;
        }

        // Iniciar sesión automáticamente si no es una creación manual desde el panel de admin
        $isManualByAdmin = esAdmin() && isset($_POST['manual_creation']);
        if (!$isManualByAdmin) {
            $_SESSION['usuario'] = [
                'id' => $newId,
                'username' => $username,
                'email' => $email,
                'nombre_completo' => $nombreCompleto,
                'rol' => $rol
            ];
            session_regenerate_id(true);
            registrarLogAcceso($pdo, $newId, $username, $rol, true);
        }

        echo json_encode([
            'success' => true,
            'message' => $rol === 'alumno'
                ? 'Cuenta creada y asociada al curso ' . ($fichaAlumno['nombre_curso'] ?? '') . '.'
                : 'Usuario registrado exitosamente.',
            'user' => [
                'id' => $newId,
                'username' => $username,
                'email' => $email,
                'nombre_completo' => $nombreCompleto,
                'rol' => $rol,
                'curso_titulo' => $rol === 'alumno' ? ($fichaAlumno['nombre_curso'] ?? '') : null
            ]
        ]);
        break;

    case 'logout':
        if (isset($_SESSION['usuario'])) {
            unset($_SESSION['usuario']);
        }
        session_destroy();
        echo json_encode(['success' => true, 'message' => 'Sesión cerrada.']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción inválida.']);
        break;
}
