<?php
/** Recepción de incidencias reportadas por alumnos y docentes. */

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

requerirAutenticacion();
$usuario = obtenerUsuarioActual();
if (!in_array($usuario['rol'] ?? '', ['alumno', 'profesor'], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Solo alumnos y docentes pueden reportar incidencias.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
    exit;
}

$entrada = json_decode(file_get_contents('php://input'), true);
if (!is_array($entrada)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'No se pudo leer el reporte.']);
    exit;
}

$categoriasPermitidas = ['acceso', 'contenidos', 'alumnos', 'calificaciones', 'calendario', 'otro'];
$categoria = trim((string)($entrada['categoria'] ?? ''));
$descripcion = trim((string)($entrada['descripcion'] ?? ''));
$largoDescripcion = function_exists('mb_strlen') ? mb_strlen($descripcion, 'UTF-8') : strlen($descripcion);

if (!in_array($categoria, $categoriasPermitidas, true) || $largoDescripcion < 10 || $largoDescripcion > 5000) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Elegí una categoría y describí el problema en 10 a 5.000 caracteres.']);
    exit;
}

try {
    $pdo = getPDO();
    $stmt = $pdo->prepare('INSERT INTO incidencias (usuario_id, usuario_nombre, usuario_email, rol, categoria, descripcion) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        (int)$usuario['id'],
        (string)($usuario['nombre_completo'] ?? $usuario['username']),
        (string)($usuario['email'] ?? ''),
        (string)$usuario['rol'],
        $categoria,
        $descripcion
    ]);

    echo json_encode(['success' => true, 'message' => 'El reporte llegó a administración.', 'id' => (int)$pdo->lastInsertId()]);
} catch (Throwable $error) {
    error_log('SEMA incident submission failed: ' . $error->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'No se pudo enviar el reporte. Intentá nuevamente.']);
}